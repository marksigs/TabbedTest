using System.Data.SqlClient; 

using System.Xml; 

using System.EnterpriseServices; 

using System.Data; 

using Microsoft.VisualBasic; 

using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToMSMQ
{
	public class OmigaToMessageQueue
		: System.EnterpriseServices.ServicedComponent, OmigaToMessageQueueInterface.IOmigaToMessageQueue
		{
		COMSVCSLib.ObjectControl
			//Workfile:      C:\Projects\dev\MessageQueue\omToMSMQ\OmigaToMessageQueue.cls
			//Copyright:     Copyright � 2000 Marlborough Stirling
			//
			//Description:   Omiga support for OMMQ
			//
			//Dependencies:  Add any other dependent components
			//
			//Issues:        Instancing:         MultiUse
			//               MTSTransactionMode: RequiresTransaction
			//------------------------------------------------------------------------------------------
			//History:
			//
			//Prog   Date        Description
			//LD     16/10/00    Created
			//AW     28/03/01    Changed order of last 2 parameters of ADO command to match sp signature
			//LD     11/06/01    SYS2367 SQL Server Port - Length must be specified in calls to CreateParameter
			//LD     19/06/01    SYS2386 All projects to use guidassist.bas rather than guidassist.cls
			//LD     12/10/01    SYS2705 Support for SQL Server added
			//LD     12/10/01    SYS2708 Add optional element CONNECTIONSTRING
			//DS     04/12/01    SYS3298 Add LOGICALQUEUNAME processing
			//LD     02/05/02    SYS4414 Amendments for BLOB support, and execute after date, and the threshold
			//                   of large message size for sql server
			//------------------------------------------------------------------------------------------
			
			
			private object m_objContext =  null ;
			
			
			public System.DateTime CSafeDate( string vvntExpression)
			{
					// header ----------------------------------------------------------------------------------
					// description:
					//   creates a date representation of an expression
					// pass:
					//   vvntExpression  Expression to be converted to a date
					// Returns:
					//   CSafeDate   Converted Expression
					//------------------------------------------------------------------------------------------
					try
					{
							
							string strFunctionName = String.Empty;
							strFunctionName = "CSafeDate";
							
							System.DateTime dteRetValue = DateTime.FromOADate(0);
							
							if (vvntExpression.Length > 0)
							{
								dteRetValue = DateTime.Parse(vvntExpression);
							}
							
							
							return dteRetValue;
						}
					catch (System.Exception excep)
					{
						
						
						
						//   re-raise error for business object to interpret as appropriate
						throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
						
					}
					return DateTime.FromOADate(0);
			}
			
			public string IOmigaToMessageQueue_AsyncSend( string strXMLRequest,  string strMessage)
			{
					string result = String.Empty;
					// header ----------------------------------------------------------------------------------
					// description:
					//    Sends an an asynchronous message to a component via OMMQ
					//
					// pass:         strMessage containing the message to be sent
					//               strXMLRequest containing the queuename and ProgID of the component to be called
					//   <REQUEST>
					//        <MESSAGEQUEUE>
					//               <QUEUENAME>.\Localx</QUEUNAME>
					//               <PROGID>omApp.omClass</PROGID>
					//               <PRIORITY>3</PRIORITY>
					//               <EXECUTEAFTERDATE>2001-03-02 12:55</EXECUTEAFTERDATE>
					//               <CONNECTIONSTRING>Provider=MSDAORA;Data Source=om4ltest;User ID=production;Password=production;</CONNECTIONSTRING>
					//       </MESSAGEQUEUE>
					//   </REQUEST>
					//
					//   Note that PRIORITY, EXECUTEAFTERDATE and CONNECTIONSTRING are optional elements.  If CONNECTIONSTRING
					//   is not supplied, then the Omiga 4 connection string is used (i.e. from the registry)
					//
					// return:                       xml Response data stream containing results of operation
					//                               either: TYPE="SUCCESS"
					//                               or: TYPE="SYSERR" and <ERROR> element
					//------------------------------------------------------------------------------------------
					XmlDocument objXMLRequest =  null ;
					XmlElement objXmlRequestElem =  null ;
					SqlCommand adoCommand = new SqlCommand();
					SqlConnection adoConnection =  null ;
					try
					{
							
							const string strFunctionName = "IOmigaToMessageQueue_AsyncSend";
							
							//Extract the request details
							objXMLRequest = (XmlDocument) xmlAssistEx.xmlLoad(strXMLRequest, strFunctionName);
							
							objXmlRequestElem = (XmlElement) xmlAssistEx.xmlGetMandatoryNode((XmlNode) objXMLRequest, "REQUEST/MESSAGEQUEUE");
							
							string strQueueName = String.Empty;
							string strLogicalQueueName = String.Empty;
							strLogicalQueueName = xmlAssistEx.xmlGetNodeText((XmlNode) objXmlRequestElem, "LOGICALQUEUENAME");
							
							if (strLogicalQueueName != "")
							{
								strQueueName = globalAssist.GetGlobalParamString(strLogicalQueueName);
							} else
							{
								strQueueName = xmlAssistEx.xmlGetMandatoryNodeText((XmlNode) objXmlRequestElem, "QUEUENAME");
							}
							
							string strProgId = String.Empty;
							strProgId = xmlAssistEx.xmlGetMandatoryNodeText((XmlNode) objXmlRequestElem, "PROGID");
							
							string strGuid = String.Empty;
							strGuid = guidAssistEx.CreateGUID();
							
							string szPriority = String.Empty;
							int nPriority = 0;
							
							szPriority = xmlAssistEx.xmlGetNodeText((XmlNode) objXmlRequestElem, "PRIORITY");
							
							// 3 is the default
							
							if (szPriority == "")
							{
								nPriority = 3;
							} else
							{
								nPriority = Int32.Parse(szPriority);
							}
							
							string szEXECUTEAFTERDATE = String.Empty;
							szEXECUTEAFTERDATE = xmlAssistEx.xmlGetNodeText((XmlNode) objXmlRequestElem, "EXECUTEAFTERDATE");
							
							string strConnectionString = String.Empty;
							DBPROVIDER enmDBProvider;
							strConnectionString = xmlAssistEx.xmlGetNodeText((XmlNode) objXmlRequestElem, "CONNECTIONSTRING");
							if (strConnectionString == "")
							{
								strConnectionString = adoAssistEx.adoGetDbConnectString();
								enmDBProvider = adoAssistEx.adoGetDbProvider();
							} else
							{
								if (strConnectionString.IndexOf("SQLOLEDB") >= 0)
								{
									enmDBProvider = DBPROVIDER.omiga4DBPROVIDERSQLServer;
								} else
								{
									enmDBProvider = DBPROVIDER.omiga4DBPROVIDEROracle;
								}
							}
							
							long lngMessageSize = 0;
							lngMessageSize = strMessage.Length;
							bool bLargeMessage = false;
							if (lngMessageSize > 2000)
							{ //  threshold for large message
								bLargeMessage = true;
							} else
							{
								bLargeMessage = false;
							}
							bool bMSDAORAChunking = false;
							if (enmDBProvider == DBPROVIDER.omiga4DBPROVIDEROracle && lngMessageSize > 32000)
							{ //  threshold for large message
								bMSDAORAChunking = true;
							} else
							{
								bMSDAORAChunking = false;
							}
							
							if (enmDBProvider == DBPROVIDER.omiga4DBPROVIDEROracle)
							{
								adoCommand.CommandType = CommandType.Text;
								if (bLargeMessage && ! bMSDAORAChunking)
								{
									adoCommand.CommandText = "{call sp_MQLOMMQ.SendMessageLONG(?,?,?,?,?,?)}";
								} else
								{
									adoCommand.CommandText = "{call sp_MQLOMMQ.SendMessage(?,?,?,?,?,?)}";
								}
							} else if (enmDBProvider == DBPROVIDER.omiga4DBPROVIDERSQLServer) { 
								adoCommand.CommandType = CommandType.Text;
								if (bLargeMessage)
								{
									adoCommand.CommandText = "{call USP_MQLOMMQSENDMESSAGENTEXT(?,?,?,?,?,?)}";
								} else
								{
									adoCommand.CommandText = "{call USP_MQLOMMQSENDMESSAGE(?,?,?,?,?,?)}";
								}
							}
							
							SqlParameter adoParameter =  null ;
							SqlParameter TempParameter =  null ;
							TempParameter = adoCommand.CreateParameter();
							TempParameter.DbType = DbType.Binary;
							TempParameter.Direction = ParameterDirection.Input;
							TempParameter.Size = 16;
							adoParameter = (SqlParameter) TempParameter;
							adoCommand.Parameters.Add(adoParameter);
							adoCommand.Parameters[0].Value = adoAssistEx.GuidStringToByteArray(strGuid);
							
							SqlParameter TempParameter =  null ;
							TempParameter = adoCommand.CreateParameter();
							TempParameter.DbType = DbType.String;
							TempParameter.Direction = ParameterDirection.Input;
							TempParameter.Size = strQueueName.Length;
							TempParameter.Value = strQueueName;
							adoParameter = (SqlParameter) TempParameter;
							adoCommand.Parameters.Add(adoParameter);
							
							SqlParameter TempParameter =  null ;
							TempParameter = adoCommand.CreateParameter();
							TempParameter.DbType = DbType.String;
							TempParameter.Direction = ParameterDirection.Input;
							adoParameter = (SqlParameter) TempParameter;
							adoCommand.Parameters.Add(adoParameter);
							adoParameter.Size = strProgId.Length;
							adoCommand.Parameters[2].Value = strProgId;
							
							SqlParameter TempParameter =  null ;
							TempParameter = adoCommand.CreateParameter();
							TempParameter.DbType = DbType.String;
							TempParameter.Direction = ParameterDirection.Input;
							adoParameter = (SqlParameter) TempParameter;
							adoParameter.Attributes = (int) ADODB.ParameterAttributesEnum.adParamNullable;
							adoCommand.Parameters.Add(adoParameter);
							if (bMSDAORAChunking)
							{
								//UPGRADE_WARNING:Use of Null/IsNull() detected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="2EED02CB-5C0E-4DC1-AE94-4FAA3A30F51A"'
								adoCommand.Parameters[3].Value = DBNull.Value;
							} else
							{
								adoParameter.Size = strMessage.Length;
								adoCommand.Parameters[3].Value = strMessage;
							}
							
							// new bind parameters
							SqlParameter TempParameter =  null ;
							TempParameter = adoCommand.CreateParameter();
							TempParameter.DbType = DbType.Int32;
							TempParameter.Direction = ParameterDirection.Input;
							adoParameter = (SqlParameter) TempParameter;
							adoCommand.Parameters.Add(adoParameter);
							adoCommand.Parameters[4].Value = nPriority;
							
							SqlParameter TempParameter =  null ;
							TempParameter = adoCommand.CreateParameter();
							TempParameter.DbType = DbType.Date;
							TempParameter.Direction = ParameterDirection.Input;
							adoParameter = (SqlParameter) TempParameter;
							adoParameter.Attributes = (int) ADODB.ParameterAttributesEnum.adParamNullable;
							adoCommand.Parameters.Add(adoParameter);
							if (szEXECUTEAFTERDATE == "")
							{
								// default to null (i.e. will be converted to the database date)
								//UPGRADE_WARNING:Use of Null/IsNull() detected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="2EED02CB-5C0E-4DC1-AE94-4FAA3A30F51A"'
								adoCommand.Parameters[5].Value = DBNull.Value;
							} else
							{
								adoCommand.Parameters[5].Value = CSafeDate(szEXECUTEAFTERDATE);
							}
							
							adoConnection = new SqlConnection();
							adoConnection.ConnectionString = strConnectionString;
							//UPGRADE_ISSUE:ADODB.Connection property adoConnection.CursorLocation was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
							adoConnection.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
							adoConnection.Open("", "", "", 0);
							
							DataSet adoRecordset =  null ;
							const int lngChunkSize = 32000;
							string strChunk = String.Empty;
							long lngOffset = 0;
							if (bMSDAORAChunking)
							{
								adoRecordset = new DataSet();
								//UPGRADE_ISSUE:ADODB.Recordset property adoRecordset.CursorType was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
								//adoRecordset.CursorType = ADODB.CursorTypeEnum.adOpenKeyset;
								//UPGRADE_ISSUE:ADODB.Recordset property adoRecordset.LockType was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
								//adoRecordset.LockType = ADODB.LockTypeEnum.adLockOptimistic;
								SqlCommand com = new SqlCommand();
								com.Connection = adoConnection;
								com.CommandText = "SELECT * FROM MQLOMMQLONG WHERE MESSAGEID IS NULL";
								SqlDataAdapter adap = new SqlDataAdapter(com.CommandText, com.Connection);
								adoRecordset = new DataSet("dsl");
								adap.Fill(adoRecordset);
								
								adoRecordset.AddNew( null ,  null );
								//UPGRADE_WARNING:Change the default 0 index in the Rows property with the correct one. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="00000000-0000-0000-0000-000000000000"'
								adoRecordset.Tables[0].Rows[0]["MessageId"] = strGuid;
								
								lngOffset = 0; //  Reset offset.
								
								while(lngOffset < lngMessageSize)
								{
									strChunk = strMessage.Substring(strMessage.Length - (Math.Min(strMessage.Length, lngMessageSize - lngOffset))).Substring(0, Math.Min(strMessage.Substring(strMessage.Length - (Math.Min(strMessage.Length, lngMessageSize - lngOffset))).Length, lngChunkSize));
									//UPGRADE_WARNING:Change the default 0 index in the Rows property with the correct one. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="00000000-0000-0000-0000-000000000000"'
									adoRecordset.Tables[0].Rows[0]["xml"].AppendChunk(strChunk);
									lngOffset += lngChunkSize;
								};
								adoRecordset.Update( null ,  null );
							}
							
							// send the message
							adoCommand.Connection = adoConnection;
							adoCommand.CommandType = ADODB.ExecuteOptionEnum.adExecuteNoRecords;
							adoCommand.ExecuteNonQuery();
							adoCommand.Connection =  null ;
							adoConnection.Close();
							
							result = "<RESPONSE TYPE=\"SUCCESS\"/>";
							ContextUtil.SetComplete();
							
						}
					catch 
					{
						
						
						
						// RF 11/01/02 create ERROR response block from Err object
						result = errAssistEx.errCreateErrorResponse();
						
						ContextUtil.SetAbort();
						
						//Resume CleanupOnExit
					}finally
					{
							adoCommand =  null ;
							adoConnection =  null ;
							objXMLRequest =  null ;
							objXmlRequestElem =  null ;
							
					}
					
					return result;
			}
			
			private void  ObjectControl_Activate()
			{
					m_objContext = new object();
			}
			
			private bool ObjectControl_CanBePooled()
			{
					return false;
			}
			
			private void  ObjectControl_Deactivate()
			{
					m_objContext =  null ;
					
			}
		}
}