using Microsoft.VisualBasic; 

using System.Text; 

using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToMSMQ
{
	class ConvertAssistEx
	{
	
		static public void  StringToByteArray(ref  byte[] rbytByteArray,  string vstrText)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies each character in vstrText into the relevant position of rbytByteArray
			// pass:
			//   rbytByteArray()  array of bytes into which the text characters are to be transferred
			//   strText          string containing the text to be transferred into the byte array
			// Raise Errors:
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "StringToByteArray";
					long lngTextLength = 0;
					lngTextLength = vstrText.Length;
					// Check string plus null terminator will fit into the byte array
					if (lngTextLength > rbytByteArray.GetUpperBound(0))
					{
						errAssistEx.errThrowError("ConvertAssist", Int32.Parse(strFunctionName), OMIGAERROR.oeInvalidParameter, "String: '" + vstrText + "'" + " can only be " + rbytByteArray.GetUpperBound(0).ToString() + " characters long");
					}
					
					for (long lngIndex = 1; lngIndex <= lngTextLength; lngIndex++ )
					{
						rbytByteArray[lngIndex - 1] = (byte) Encoding.ASCII.GetBytes(vstrText[(lngIndex - 1)].ToString())[0];
					}
				}
			catch (System.Exception excep)
			{
				
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
		}
		static public string ByteArrayToString(ref  byte[] rbytByteArray)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   creates a string representation of a byte array
			// pass:
			//   rbytByteArray()  array of bytes from which the string is to be formed
			// Raise Errors:
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "ByteArrayToString";
					long lngArrayLimit = 0;
					StringBuilder strString = new StringBuilder();
					strString.Append(String.Empty);
					long lngIndex = 0;
					lngArrayLimit = rbytByteArray.GetUpperBound(0);
					lngIndex = 0;
					
					while(lngIndex <= lngArrayLimit && rbytByteArray[lngIndex] != 0)
					{
						strString.Append(Strings.Chr(rbytByteArray[lngIndex]).ToString());lngIndex++ ;
					};
					return strString.ToString();
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return String.Empty;
		}
		static public System.DateTime CSafeDate( string vvntExpression)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   creates a date representation of an expression
			// pass:
			//   vvntExpression  Expression to be converted to a date
			// Returns:
			//   CSafeDate   Converted Expression
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "CSafeDate";
					System.DateTime dteRetValue = DateTime.FromOADate(0);
					if (vvntExpression.Length > 0)
					{
						dteRetValue = DateTime.Parse(vvntExpression);
					}
					return dteRetValue;
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return DateTime.FromOADate(0);
		}
		static public long CSafeLng( string vvntExpression)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   creates a long representation of an expression
			// pass:
			//   vvntExpression  Expression to be converted to a long
			// Returns:
			//   CSafeLng   Converted Expression
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "CSafeLng";
					long lngRetValue = 0;
					if (vvntExpression.Length > 0)
					{
						lngRetValue = Int64.Parse(vvntExpression);
					}
					return lngRetValue;
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return 0;
		}
		static public double CSafeDbl( string vvntExpression)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   creates a double representation of an expression
			// pass:
			//   Expression  Expression to be converted to a double
			// Returns:
			//   CSafeDbl   Converted Expression
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "CSafeDbl";
					double dblRetValue = 0;
					if (vvntExpression.Length > 0)
					{
						dblRetValue = Double.Parse(vvntExpression);
					}
					return dblRetValue;
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return 0;
		}
		static public byte CSafeByte( string vvntExpression)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   creates a byte representation of an expression
			// pass:
			//   Expression  Expression to be converted to a byte
			// Returns:
			//   CSafeByte   Converted Expression
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "CSafeByte";
					byte bytRetValue = 0;
					if (vvntExpression.Length > 0)
					{
						bytRetValue = (byte) Encoding.ASCII.GetBytes(vvntExpression)[0];
					}
					return bytRetValue;
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return 0;
		}
		static public int CSafeInt( string vvntExpression)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   creates an integer representation of an expression
			// pass:
			//   Expression  Expression to be converted to an integer
			// Returns:
			//   CSafeInt   Converted Expression
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "CSafeInt";
					int bytRetValue = 0;
					if (vvntExpression.Length > 0)
					{
						bytRetValue = Int32.Parse(vvntExpression);
					}
					return bytRetValue;
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return 0;
		}
		static public bool CSafeBool( object vvntExpression)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   creates an boolean representation of an expression
			// pass:
			//   Expression  Expression to be converted to a boolean
			// Returns:
			//   CSafeInt   Converted Expression
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "CSafeBool";
					bool bytRetValue = false;
					//UPGRADE_WARNING:Couldn't resolve default property of object vvntExpression. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					if (Strings.Len((string) vvntExpression) > 0)
					{
						//UPGRADE_WARNING:Couldn't resolve default property of object vvntExpression. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						bytRetValue = (bool) vvntExpression;
					}
					return bytRetValue;
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return false;
		}
	}
}