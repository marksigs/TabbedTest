using System.Xml; 

using System.Diagnostics; 

using System.Globalization; 

using Microsoft.VisualBasic; 

using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToOMMQ
{
	class errAssistEx
	{
	
		//header ----------------------------------------------------------------------------------
		//Workfile:      errAssist.bas
		//Copyright:     Copyright � 2001 Marlborough Stirling
		//
		//Description:   Helper functions for error handling
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		//History:
		//
		//Prog    Date        Description
		//IK      01/11/00    Initial creation
		//ASm     10/01/01    SYS1817: Rationalisation of methods following meeting with PC and IK
		//PSC     25/02/02    SYS4097: Amend errGetMessage text to default message to not found
		//------------------------------------------------------------------------------------------
		//'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		//BMIDS Specific History
		//
		//Prog   Date        Description
		//DB     21/03/2003  BM0483  Performance upgrades - generate correct omiga error numbers
		//INR    28/03/2003  BM0056  Use Omiga Error No. to get message text.
		//
		//''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		//******************************************************************************************
		//BBG Specific History
		//
		//Prog   Date        Description
		//MC     10/08/2004  E2EM00000558 - member function errAddWarningAndThrow() ADDED
		//PSC    12/08/2004  BBG1213 - Amend errThrowError to cater for extra details not being passed
		//
		//''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		//******************************************************************************************
		//Core Specific History
		//
		//Prog   Date        Description
		//AS     20/05/2005  CORE135 Added support for getting error via CRUD
		//AS     07/03/2007  CORE9 Add ExceptionType support.
		//''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		
		private const string gstrMODULEPREFIX = "errAssist.";
		// AS 07/03/2007 CORE9 START Add ExceptionType
		private const string gstrEXCEPTIONTYPEPREFIX = "ExceptionType=";
		// AS 07/03/2007 CORE9 END Add ExceptionType
		
		//UPGRADE_WARNING:ParamArray vstrAdditionalOptions was changed from ByRef to ByVal. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="93C6A0DC-8C99-429A-8696-35FC4DCEFCCC"'
		static public void  errThrowError( string vstrFunctionName,  int vintOmigaErrorNo, params  string[] vstrAdditionalOptions)
		{
			const string strFunctionName = "errThrowError";
			// header ----------------------------------------------------------------------------------
			// description:  Raise a VB error
			// pass:         Function Name of calling component
			//               Omiga Error number to throw
			//               Parameter Array of addition arguments, if the error description
			//               has subsitution parameters "%s" in it then you must specify the
			//               these additional subsituation parameters in the parameter array
			//               from 1 to n.
			//               NOTE: The FIRST element in the parameter array (element 0_ is not
			//               used in the errpor descprition subsitution but is used as
			//               final addtion error text.
			// return:       n/a
			//------------------------------------------------------------------------------------------
			
			string strLeftHandSide = String.Empty;
			string strMessage = String.Empty;
			
			long lngErrNo = Constants.vbObjectError + 512 + vintOmigaErrorNo;
			string strText = errGetMessageText(vintOmigaErrorNo);
			// Find %s and substitute it with the substitution parameters
			long lngPosition = Strings.InStr(1, strText, "%s", CompareMethod.Text);
			int intIndex = 1;
			
			while(lngPosition != 0 && intIndex <= ((object[]) vstrAdditionalOptions).GetUpperBound(0))
			{
				strLeftHandSide = strText.Substring(0, Math.Min(strText.Length, lngPosition - 1));
				strMessage = strMessage + strLeftHandSide;
				// Substitute parameter if present
				//UPGRADE_ISSUE:IsMissing function is not supported. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
				if (! IsMissing(vstrAdditionalOptions[intIndex]))
				{
					//UPGRADE_WARNING:Couldn't resolve default property of object vstrAdditionalOptions(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					strMessage = strMessage + (string) vstrAdditionalOptions[intIndex];
				} else
				{
					strMessage = strMessage + "*** MISSING PARAMETER ***";
				}
				strText = strText.Substring(lngPosition + 2 - 1);
				lngPosition = Strings.InStr(1, strText, "%s", CompareMethod.Text);intIndex++ ;
			};
			strMessage = strMessage + strText;
			// If we have additional parameters
			//UPGRADE_ISSUE:IsMissing function is not supported. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
			if (((object[]) vstrAdditionalOptions).GetUpperBound(0) >= 0 && ! IsMissing(vstrAdditionalOptions[0]))
			{
				// First parameter is the additional error text
				// PSC 12/08/2004 BBG1213 - start
				//UPGRADE_WARNING:Couldn't resolve default property of object vstrAdditionalOptions(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				strMessage = strMessage + ", Details: " + (string) vstrAdditionalOptions[0];
				// PSC 12/08/2004 BBG1213 - End
			}
			throw new System.Exception(lngErrNo.ToString() + ", " + vstrFunctionName + ", " + strMessage + ", " +  null  + ", " +  null );
		}
		static public bool errIsWarning()
		{
			// header ----------------------------------------------------------------------------------
			// description:  Check if the raised error is a warning
			// pass:         n/a
			// return:       Boolean indicating if Err.Number corresponds to an Omiga4 Warning
			//------------------------------------------------------------------------------------------
			
			string strErrorType = String.Empty;
			long lngOmigaErrorNo = 0;
			bool blnIsWarning = false;
			if (errIsApplicationError())
			{
				
				lngOmigaErrorNo = errGetOmigaErrorNumber(Information.Err().Number);
				strErrorType = errGetMessageText(lngOmigaErrorNo, MESSAGE.omMESSAGE_TYPE);
				if (Strings.StrComp(strErrorType, "Warning", CompareMethod.Text) == 0 || Strings.StrComp(strErrorType, "Prompt", CompareMethod.Text) == 0)
				{
					blnIsWarning = true;
				}
			}
			return blnIsWarning;
		}
		static public OMIGAERRORTYPE errCheckError( string vstrFunctionName,  string vstrObjectName, ref  XmlElement vxmlResponseNode)
		{
			OMIGAERRORTYPE result =  null ;
			// header ----------------------------------------------------------------------------------
			// description:  Re-raise the Application Error
			// pass:         Function Name of calling object
			//               Object Name of calling object
			//               xmlResponse node to append warning (only handles a single warning!) to
			// return:       Enumeration indicating if Err.Number corresponds to:
			//               omWARNING or omNO_ERR see OMIGAMESSAGETYPE enum
			//------------------------------------------------------------------------------------------
			
			result = OMIGAERRORTYPE.omNO_ERR;
			// AS 07/03/2007 CORE9 START Add ExceptionType
			string strExceptionType = errGetExceptionType(Information.Err());
			long intErrNumber = 0;
			string strErrDescription = String.Empty;
			string strErrSource = String.Empty;
			string strHelpFile = String.Empty; //  AS 07/03/2007 CORE9 Add ExceptionType
			if (Information.Err().Number != 0 || strExceptionType.Length > 0)
			{
				// AS 07/03/2007 CORE9 END Add ExceptionType
				// Save err information as errIsWarning call MessageBO/DO which will reset
				// the error handler
				intErrNumber = Information.Err().Number;
				strErrDescription = Information.Err().Description;
				strErrSource = Information.Err().Source;
				strHelpFile = Information.Err().HelpFile; //  AS 07/03/2007 CORE9 Add ExceptionType
				if (errIsWarning())
				{
					if (vxmlResponseNode ==  null )
					{
						errThrowError(strErrSource, (int) OMIGAERROR.oeXMLMissingElement, "Missing RESPONSE element");
					}
					errAddWarning(vxmlResponseNode); //  Add warning to the response node
					result = OMIGAERRORTYPE.omWARNING;
				} else
				{
					if (strErrSource != vstrFunctionName)
					{
						strErrSource = vstrFunctionName + "." + strErrSource;
					}
					
					if (vstrObjectName.Length != 0)
					{
						strErrSource = vstrObjectName + "." + strErrSource;
					}
					
					throw new System.Exception(intErrNumber.ToString() + ", " + strErrSource + ", " + strErrDescription + ", " + strHelpFile + ", " +  null ); //  AS 07/03/2007 CORE9 Add ExceptionType
				}
			}
			return result;
		}
		
		static public OMIGAERRORTYPE errCheckError( string vstrFunctionName,  string vstrObjectName)
		{
			XmlElement tempRefParam =  null ;
			return errCheckError(vstrFunctionName, vstrObjectName, ref tempRefParam);
		}
		
		static public OMIGAERRORTYPE errCheckError( string vstrFunctionName)
		{
			XmlElement tempRefParam2 =  null ;
			return errCheckError(vstrFunctionName, "", ref tempRefParam2);
		}
		static public OMIGAERROR errCheckXMLResponseNode( XmlElement vxmlResponseNodeToCheck,  XmlElement vxmlResponseNodeToAdd,  bool vblnRaiseError)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Re-raise the Application Error held in an IXMLDOMNode
			// pass:         xmlResponse node to check for error information
			//               xmlResponse node to add warning(s) to
			//               Raise Error boolean as to whether or not you require to re-raise the error
			// return:       n/a
			//------------------------------------------------------------------------------------------
			string strErrDesc = String.Empty;
			OMIGAERROR lngErrNo = OMIGAERROR.oeUnspecifiedError;
			string strErrSource = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
			if (vxmlResponseNodeToCheck ==  null )
			{
				errThrowError(strErrSource, (int) OMIGAERROR.oeXMLMissingElement, "Missing RESPONSE element");
			}
			if (vxmlResponseNodeToCheck.Name != "RESPONSE")
			{
				errThrowError(strErrSource, (int) OMIGAERROR.oeMissingPrimaryTag, "RESPONSE must be the top level tag");
			}
			if (vxmlResponseNodeToAdd !=  null  && vxmlResponseNodeToAdd.Name != "RESPONSE")
			{
				errThrowError(strErrSource, (int) OMIGAERROR.oeMissingPrimaryTag, "RESPONSE must be the top level tag");
			}
			XmlNode xmlResponseTypeNode = vxmlResponseNodeToCheck.Attributes.GetNamedItem("TYPE");
			XmlNodeList xmlMessageList =  null ;
			XmlElement xmlFirstChild =  null ;
			XmlNode xmlResponseErrorNumber =  null ;
			XmlNode xmlResponseErrorSource =  null ;
			XmlNode xmlResponseErrorDesc =  null ;
			if (xmlResponseTypeNode !=  null )
			{
				if (xmlResponseTypeNode.InnerText == "WARNING")
				{
					if (vxmlResponseNodeToAdd !=  null )
					{
						vxmlResponseNodeToAdd.SetAttribute("TYPE", "WARNING");
						xmlFirstChild = (XmlElement) vxmlResponseNodeToAdd.FirstChild;
						xmlMessageList = vxmlResponseNodeToCheck.SelectNodes("MESSAGE");
						// insert messages at the top of the response to add element
						foreach (XmlElement xmlMessageElem in xmlMessageList)
						{
							vxmlResponseNodeToAdd.InsertBefore(xmlMessageElem.CloneNode(true), xmlFirstChild);
						}
					}
				} else if (xmlResponseTypeNode.InnerText != "SUCCESS") { 
					
					
					xmlResponseErrorNumber = vxmlResponseNodeToCheck.SelectSingleNode("ERROR/NUMBER");
					double dbNumericTemp = 0;
					if (xmlResponseErrorNumber !=  null  && Double.TryParse(xmlResponseErrorNumber.InnerText, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out dbNumericTemp))
					{
						//UPGRADE_WARNING:Casting 'Long' to Enum may cause different behaviour. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="FF8AAC19-CE56-4016-821F-92D4B80111D8"'
						lngErrNo = (OMIGAERROR) ConvertAssistEx.CSafeLng(xmlResponseErrorNumber.InnerText);
					}
					xmlResponseErrorNumber =  null ;
					if (vblnRaiseError)
					{
						
						xmlResponseErrorSource = vxmlResponseNodeToCheck.SelectSingleNode("ERROR/SOURCE");
						if (xmlResponseErrorSource !=  null  && xmlResponseErrorSource.InnerText.Length > 0)
						{
							strErrSource = xmlResponseErrorSource.InnerText;
						}
						xmlResponseErrorSource =  null ;
						xmlResponseErrorDesc = vxmlResponseNodeToCheck.SelectSingleNode("ERROR/DESCRIPTION");
						if (xmlResponseErrorDesc !=  null  && xmlResponseErrorDesc.InnerText.Length > 0)
						{
							strErrDesc = xmlResponseErrorDesc.InnerText;
						}
						xmlResponseErrorDesc =  null ;
						if (strErrDesc.Length == 0)
						{
							strErrDesc = errGetMessageText((int) OMIGAERROR.oeUnspecifiedError);
						}
						
						// AS 07/03/2007 CORE9 START Add ExceptionType
						throw new System.Exception(((int) lngErrNo).ToString() + ", " + strErrSource + ", " + strErrDesc + ", " + errCreateHelpFileFromExceptionType(errGetExceptionTypeFromResponse(vxmlResponseNodeToCheck)) + ", " +  null );
						// AS 07/03/2007 CORE9 END Add ExceptionType
					}
				} else
				{
					lngErrNo = 0;
				}
			}
			return lngErrNo;
		}
		
		static public OMIGAERROR errCheckXMLResponseNode( XmlElement vxmlResponseNodeToCheck,  XmlElement vxmlResponseNodeToAdd)
		{
			return errCheckXMLResponseNode(vxmlResponseNodeToCheck, vxmlResponseNodeToAdd, false);
		}
		
		static public OMIGAERROR errCheckXMLResponseNode( XmlElement vxmlResponseNodeToCheck)
		{
			return errCheckXMLResponseNode(vxmlResponseNodeToCheck,  null , false);
		}
		static public XmlNode CreateErrorResponseNode( bool blnLogError)
		{
			XmlNode result =  null ;
			// header ----------------------------------------------------------------------------------
			// description:  Creates an error node from the err object
			// pass:         n/a
			// return:       xml response node holding the error information for the error raised in the format:
			//               <RESPONSE TYPE=APPERR or SYSERR>
			//                   <ERROR>
			//                       <NUMBER> </NUMBER>
			//                       <SOURCE> </SOURCE>
			//                       <DESCRIPTION> </DESCRIPTION>
			//                   </ERROR>
			//               </RESPONSE>
			// AS 07/03/2007 CORE9 Note that the ordering of ERROR child elements has changed, so that
			// SOURCE (the longest string) is last.
			//------------------------------------------------------------------------------------------
			MSXML2.FreeThreadedDOMDocument40 xmlDoc = new MSXML2.FreeThreadedDOMDocument40();
			XmlElement xmlReponseElem = xmlDoc.createElement("RESPONSE");
			xmlDoc.appendChild((XmlNode) xmlReponseElem);
			XmlElement xmlErrorElem = xmlDoc.createElement("ERROR");
			xmlReponseElem.AppendChild((XmlNode) xmlErrorElem);
			XmlElement xmlElement = xmlDoc.createElement("NUMBER");
			xmlElement.InnerText = Information.Err().Number;
			xmlErrorElem.AppendChild((XmlNode) xmlElement);
			// AS 07/03/2007 CORE9 START Add ExceptionType
			string strId = String.Empty;
			string strExceptionType = errGetExceptionType(Information.Err());
			if (strExceptionType.Length > 0)
			{
				// Only add EXCEPTIONTYPE and ID elements if Err.HelpFile contains "ExceptionType=" prefix,
				// i.e., this error has been raised by Vertex.Fsd.Omiga.Core.OmigaException.
				xmlElement = xmlDoc.createElement("EXCEPTIONTYPE");
				xmlElement.InnerText = strExceptionType;
				xmlErrorElem.AppendChild((XmlNode) xmlElement);
				strId = guidAssistEx.CreateGUID();
				xmlElement = xmlDoc.createElement("ID");
				xmlElement.InnerText = strId;
				xmlErrorElem.AppendChild((XmlNode) xmlElement);
			}
			// AS 07/03/2007 CORE9 END Add ExceptionType
			XmlElement xmlDescriptionElem = xmlDoc.createElement("DESCRIPTION");
			xmlDescriptionElem.InnerText = Information.Err().Description;
			xmlErrorElem.AppendChild((XmlNode) xmlDescriptionElem);
			xmlElement = xmlDoc.createElement("VERSION");
			xmlElement.InnerText = FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly().Location).Comments;
			xmlErrorElem.AppendChild((XmlNode) xmlElement);
			xmlElement = xmlDoc.createElement("SOURCE");
			xmlElement.InnerText = Information.Err().Source;
			xmlErrorElem.AppendChild((XmlNode) xmlElement);
			if (errIsApplicationError())
			{
				xmlReponseElem.SetAttribute("TYPE", "APPERR");
				if (xmlDescriptionElem.InnerText.Length == 0)
				{
					//INR BM0056
					//            xmlDescriptionElem.Text = errGetMessageText(Err.Number)
					xmlDescriptionElem.InnerText = errGetMessageText(errGetOmigaErrorNumber(Information.Err().Number));
				}
			} else
			{
				xmlReponseElem.SetAttribute("TYPE", "SYSERR");
			}
			
			result = xmlReponseElem.CloneNode(true);
			if (blnLogError && errIsSystemError())
			{
				// AS 07/03/2007 CORE9 START Add ExceptionType
				EventLog.WriteEntry(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name, "SYSERR: " + Information.Err().Number.ToString() + ", " + (strExceptionType.Length > 0) ? strExceptionType + ", ": "" + (strId.Length > 0) ? strId + ", ": "" + Information.Err().Description + ", " + Information.Err().Source, EventLogEntryType.Error);
				// AS 07/03/2007 CORE9 END Add ExceptionType
			}
			return result;
		}
		
		static public XmlNode CreateErrorResponseNode()
		{
			return CreateErrorResponseNode(true);
		}
		static public string errCreateErrorResponse()
		{
			// header ----------------------------------------------------------------------------------
			// description:  Creates an xml error response based on the raised error
			// pass:         n/a
			// return:       The xml response string containing an the error information in the format
			//               <RESPONSE TYPE=APPERR or SYSERR>
			//                   <ERROR>
			//                       <NUMBER> </NUMBER>
			//                       <SOURCE> </SOURCE>
			//                       <DESCRIPTION> </DESCRIPTION>
			//                   </ERROR>
			//               </RESPONSE>
			//------------------------------------------------------------------------------------------
			XmlElement xmlErrorElem = (XmlElement) CreateErrorResponseNode(false);
			string strExceptionType = String.Empty;
			string strId = String.Empty;
			if (errIsSystemError())
			{
				// AS 07/03/2007 CORE9 START Add ExceptionType
				strExceptionType = errGetExceptionType(Information.Err());
				if (strExceptionType.Length > 0)
				{
					strId = guidAssistEx.CreateGUID();
				}
				EventLog.WriteEntry(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name, "SYSERR: " + Information.Err().Number.ToString() + ", " + (strExceptionType.Length > 0) ? strExceptionType + ", ": "" + (strId.Length > 0) ? strId + ", ": "" + Information.Err().Description + ", " + Information.Err().Source, EventLogEntryType.Error);
				// AS 07/03/2007 CORE9 END Add ExceptionType
			}
			
			return xmlErrorElem.InnerXml;
		}
		static public string errGetMessageText( long vlngMessageNo,  MESSAGE vintMessageField)
		{
			string result = String.Empty;
			// header ----------------------------------------------------------------------------------
			// description:  Gets the soft coded message information, the message can be an error or warning
			// pass:         Message number to use to find message text
			//               Optional Message field to return either Text or Type see omMESSAGE enum
			// return:       Message text string in the following format:
			//------------------------------------------------------------------------------------------
			
			// AS 20/05/2005 CORE135 Added support for getting error via CRUD
#if omCRUD
			
			//UPGRADE_TODO: #If #EndIf block was not upgraded because the expression omCRUD did not evaluate to True or was not evaluated. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="27EE2C3C-05AF-4C04-B2AF-657B4FB6B5FC"'
			errGetMessageText = adoCRUDGetMessageText(vlngMessageNo, vintMessageField)
#else
			
			const string strFunctionName = "errGetMessageText";
			string strMessageText = String.Empty;
			// First see if the error is not on the database
			MSXML2.FreeThreadedDOMDocument40 xmlDoc =  null ;
			XmlElement xmlElem =  null ;
			XmlNode xmlRootNode =  null ;
			XmlNode xmlSchemaNode =  null ;
			XmlNode xmlRequestNode =  null ;
			XmlNode xmlResponseNode =  null ;
			if (! errGetDefaultMessageText(vlngMessageNo, ref strMessageText))
			{
				
				// Get the message from the database
				// create one FreeThreadedDOMDocument40 to contain schema, request & response
				xmlDoc = new MSXML2.FreeThreadedDOMDocument40();
				// create BOGUS root node
				xmlElem = xmlDoc.createElement("BOGUS");
				xmlRootNode = xmlDoc.appendChild((XmlNode) xmlElem);
				// create schema for MESSAGE table
				xmlElem = xmlDoc.createElement("SCHEMA");
				xmlSchemaNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlDoc.createElement("MESSAGE");
				xmlElem.SetAttribute("ENTITYTYPE", "PHYSICAL");
				xmlSchemaNode = xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlDoc.createElement("MESSAGENUMBER");
				xmlElem.SetAttribute("DATATYPE", "SHORT");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlDoc.createElement("MESSAGETEXT");
				xmlElem.SetAttribute("DATATYPE", "STRING");
				xmlElem.SetAttribute("LENGTH", "255");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				// create REQUEST details
				xmlElem = xmlDoc.createElement("REQUEST");
				xmlRequestNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlDoc.createElement("MESSAGE");
				xmlElem.SetAttribute("MESSAGENUMBER", vlngMessageNo.ToString());
				xmlRequestNode = xmlRequestNode.AppendChild((XmlNode) xmlElem);
				// create RESPONSE node
				xmlElem = xmlDoc.createElement("RESPONSE");
				xmlResponseNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
				adoAssistEx.adoGetRecordSetAsXML(xmlRequestNode, xmlSchemaNode, xmlResponseNode);
				if (vintMessageField == MESSAGE.omMESSAGE_TEXT)
				{
					if (xmlResponseNode.SelectSingleNode("MESSAGE/@MESSAGETEXT") !=  null )
					{
						strMessageText = xmlResponseNode.SelectSingleNode("MESSAGE/@MESSAGETEXT").InnerText;
						//            Else
						//                strMessageText = "Error Message not found"
					}
				} else
				{
					if (xmlResponseNode.SelectSingleNode("MESSAGE/@MESSAGETYPE") !=  null )
					{
						strMessageText = xmlResponseNode.SelectSingleNode("MESSAGE/@MESSAGETYPE").InnerText;
					}
				}
				xmlDoc =  null ;
				xmlElem =  null ;
				xmlRootNode =  null ;
				xmlSchemaNode =  null ;
				xmlRequestNode =  null ;
				xmlResponseNode =  null ;
			}
			result = strMessageText;
#endif
			return result;
		}
		
		static public string errGetMessageText( long vlngMessageNo)
		{
			return errGetMessageText(vlngMessageNo, MESSAGE.omMESSAGE_TEXT);
		}
		static private bool errGetDefaultMessageText( long lngMessageNo, ref  string strMsgText)
		{
			bool result = false;
			// header ----------------------------------------------------------------------------------
			// description:  Gets all messages not specifed in the message table
			// pass:         message number and empty message text string
			// returns:      Boolean indicating whether the message number was found
			//               message text if message is found
			//------------------------------------------------------------------------------------------
			
			result = true;
			switch(lngMessageNo)
			{
				
				case 556 : 
					strMsgText = "Unable to establish database connection"; 
					break;
				case 901 : 
					strMsgText = "Error message not found"; 
					//------------------------------------------------------------------------------------------ 
					// catch all 
					//------------------------------------------------------------------------------------------ 
					break;
				default:
					result = false; 
					break;
			}
			return result;
		}
		static public bool errIsApplicationError()
		{
			// header ----------------------------------------------------------------------------------
			// description:  Check if error is an omiga 4 application error.
			//               NOTE: Warnings are application errors!
			// pass:         n/a
			// return:       boolean indicating if the error is an applicaton error
			//------------------------------------------------------------------------------------------
			long lngOmigaErrorNo = 0;
			bool blnIsApplicationError = false;
			long lngErrNo = Information.Err().Number;
			
			//    If lngErrNo <> 0 Then
			//        lngOmigaErrorNo = errGetOmigaErrorNumber(lngErrNo)
			//
			//        ' AS 23/11/99 For the error to be an Omiga4 Application error it must also
			//        ' not be in the ADO error number range see ADODB.ErrorValueEnum
			//        If (lngOmigaErrorNo > 0 And _
			//'            lngOmigaErrorNo <= clngMAX_ERROR_NO And _
			//'            (lngOmigaErrorNo < clngADO_START_ERROR_NO Or _
			//'            lngOmigaErrorNo > clngADO_END_ERROR_NO)) Then
			//
			//            blnIsApplicationError = True
			//
			//        End If
			//    End If
			
			//DB BM0483 - Re-worked to subtract 512 from the error number.
			if (lngErrNo != 0)
			{
				lngOmigaErrorNo = errGetOmigaErrorNumber(lngErrNo);
				if (lngOmigaErrorNo > 0 && lngOmigaErrorNo <= errConstants.clngMAX_ERROR_NO)
				{
					lngErrNo -= Constants.vbObjectError;
					if (lngErrNo < errConstants.clngADO_START_ERROR_NO || lngOmigaErrorNo > errConstants.clngADO_END_ERROR_NO)
					{
						blnIsApplicationError = true;
					}
				}
			}
			//DB End
			return blnIsApplicationError;
		}
		static public bool errIsSystemError()
		{
			// header ----------------------------------------------------------------------------------
			// description:  Determines if the error is a system error
			// pass:         n/a
			// return:       boolean indicating a system error
			//------------------------------------------------------------------------------------------
			return ! errIsApplicationError();
		}
		static public string errFormatMessageNode()
		{
			// header ----------------------------------------------------------------------------------
			// description:
			// pass:
			//------------------------------------------------------------------------------------------
			
			MSXML2.FreeThreadedDOMDocument40 xmlMessageDoc = new MSXML2.FreeThreadedDOMDocument40();
			
			XmlElement xmlMessageElement = xmlMessageDoc.createElement("MESSAGE");
			xmlMessageDoc.appendChild((XmlNode) xmlMessageElement);
			XmlElement xmlElement = xmlMessageDoc.createElement("TEXT");
			xmlElement.InnerText = Information.Err().Description;
			xmlMessageElement.AppendChild((XmlNode) xmlElement);
			long lngOmigaErrorNo = errGetOmigaErrorNumber(Information.Err().Number);
			xmlElement = xmlMessageDoc.createElement("TYPE");
			xmlElement.InnerText = "Warning";
			xmlMessageElement.AppendChild((XmlNode) xmlElement);
			return xmlMessageDoc.xml;
			
		}
		static public void  errAddWarning( XmlElement xmlResponse)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Adds the warning into the xmlResponse
			// pass:         xmlResponse to add the warning to
			// return:       n/a
			//------------------------------------------------------------------------------------------
			if (xmlResponse.Name != "RESPONSE")
			{
				errThrowError(Information.Err().Source, (int) OMIGAERROR.oeMissingPrimaryTag, "RESPONSE must be the top level tag");
			}
			xmlResponse.SetAttribute("TYPE", "WARNING");
			XmlNode xmlFirstChild = xmlResponse.FirstChild;
			XmlElement xmlMessageElement = xmlResponse.OwnerDocument.CreateElement("MESSAGE");
			xmlResponse.InsertBefore((XmlNode) xmlMessageElement, xmlFirstChild);
			
			XmlElement xmlElement = xmlResponse.OwnerDocument.CreateElement("MESSAGETEXT");
			xmlElement.InnerText = Information.Err().Description;
			xmlMessageElement.AppendChild((XmlNode) xmlElement);
			long lngOmigaErrorNo = errGetOmigaErrorNumber(Information.Err().Number);
			xmlElement = xmlResponse.OwnerDocument.CreateElement("MESSAGETYPE");
			xmlElement.InnerText = errGetMessageText(lngOmigaErrorNo, MESSAGE.omMESSAGE_TYPE);
			xmlMessageElement.AppendChild((XmlNode) xmlElement);
		}
		
		//[MC]E2EM00000558 - WARNING MESSAGE WITHOUT APPERROR
		static public void  errAddOmigaWarning( XmlElement xmlResponse,  int vintOmigaErrorNo)
		{
			
			
			if (xmlResponse.Name != "RESPONSE")
			{
				errThrowError(Information.Err().Source, (int) OMIGAERROR.oeMissingPrimaryTag, "RESPONSE must be the top level tag");
			}
			
			long lngErrNo = Constants.vbObjectError + 512 + vintOmigaErrorNo;
			string strText = errGetMessageText(vintOmigaErrorNo);
			
			
			xmlResponse.SetAttribute("TYPE", "WARNING");
			XmlNode xmlFirstChild = xmlResponse.FirstChild;
			XmlElement xmlMessageElement = xmlResponse.OwnerDocument.CreateElement("MESSAGE");
			xmlResponse.InsertBefore((XmlNode) xmlMessageElement, xmlFirstChild);
			
			XmlElement xmlElement = xmlResponse.OwnerDocument.CreateElement("MESSAGETEXT");
			xmlElement.InnerText = strText;
			xmlMessageElement.AppendChild((XmlNode) xmlElement);
			long lngOmigaErrorNo = vintOmigaErrorNo;
			xmlElement = xmlResponse.OwnerDocument.CreateElement("MESSAGETYPE");
			xmlElement.InnerText = vintOmigaErrorNo.ToString();
			xmlMessageElement.AppendChild((XmlNode) xmlElement);
			
		}
		//*=[MC]E2EM00000558 - END
		
		static public long errGetOmigaErrorNumber( long vlngErrorNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Converts an  error number to an omiga number. When errors are raised by VB
			//               they get added to them the VB constant 'vbObjectError + 512' so to get the
			//               Omiga4 error number orginally raised we need to subtract them from the err
			//               number.
			//               NOTE: System error numbers will end up much larger than Omiga4 error numbers
			// pass:         Error number to calculate
			// return:       Calculated Omiga4 error number
			//------------------------------------------------------------------------------------------
			return vlngErrorNo - Constants.vbObjectError - 512;
		}
		static public OMIGAERROR errCheckXMLResponse( string vstrXmlReponse,  bool vblnRaiseError,  XmlElement vxmlInResponseElement)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Checks the xml response, this method expects the xml response as a string
			//               and designed to called when calling across component methods and then intergrating
			//               the returned xml
			// pass:         xmlResponse containing xml data to be checked
			//               boolean as to whether to re-raise the error
			//               xmlResponseElement to copy the warnings to
			//------------------------------------------------------------------------------------------
			string strFunctionName = "CheckXMLResponse";
			MSXML2.FreeThreadedDOMDocument40 xmlXmlIn = xmlAssistEx.xmlLoad(vstrXmlReponse, strFunctionName);
			XmlElement xmlResponseElement = (XmlElement) xmlXmlIn.selectSingleNode("RESPONSE");
			if (xmlResponseElement ==  null )
			{
				errThrowError(strFunctionName, (int) OMIGAERROR.oeXMLMissingElement, "Missing RESPONSE element");
			}
			return errCheckXMLResponseNode(xmlResponseElement, vxmlInResponseElement, vblnRaiseError);
		}
		
		static public OMIGAERROR errCheckXMLResponse( string vstrXmlReponse,  bool vblnRaiseError)
		{
			return errCheckXMLResponse(vstrXmlReponse, vblnRaiseError,  null );
		}
		
		static public OMIGAERROR errCheckXMLResponse( string vstrXmlReponse)
		{
			return errCheckXMLResponse(vstrXmlReponse, false,  null );
		}
		static public void  errRaiseXMLResponse( string vstrXmlResponse)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Checks the XML response for error information and raises the error
			// pass:         xmlResponse containing xml data to be checked for an error
			// return:       n/a
			//------------------------------------------------------------------------------------------
			string strFunctionName = "RaiseXMLResponseError";
			MSXML2.FreeThreadedDOMDocument40 xmlXmlIn = xmlAssistEx.xmlLoad(vstrXmlResponse, strFunctionName);
			errRaiseXMLResponseNode(xmlXmlIn.documentElement);
		}
		static public void  errRaiseXMLResponseNode( XmlElement vxmlResponseNode)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Checks the XML response node for error information and raises the error
			// pass:         vxmlResponseNode containing xml data to be checked for an error
			// return:       n/a
			//------------------------------------------------------------------------------------------
			
			XmlNode xmlResponseErrorSource =  null ;
			XmlNode xmlResponseErrorDesc =  null ;
			XmlNode xmlResponseErrorExceptionType =  null ; //  AS 07/03/2007 CORE9 Add ExceptionType
			
			long lngErrNo = 0;
			XmlNode xmlResponseErrorNumber = vxmlResponseNode.SelectSingleNode("ERROR/NUMBER");
			double dbNumericTemp = 0;
			if (xmlResponseErrorNumber !=  null  && Double.TryParse(xmlResponseErrorNumber.InnerText, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out dbNumericTemp))
			{
				lngErrNo = ConvertAssistEx.CSafeLng(xmlResponseErrorNumber.InnerText);
			}
			xmlResponseErrorNumber =  null ;
			
			// AS 07/03/2007 CORE9 START Add ExceptionType
			string strExceptionType = errGetExceptionTypeFromResponse(vxmlResponseNode);
			
			string strHelpFile = String.Empty;
			string strErrSource = String.Empty;
			string strErrDesc = String.Empty;
			if (lngErrNo != 0 || strExceptionType.Length > 0)
			{
				strHelpFile = errCreateHelpFileFromExceptionType(strExceptionType);
				// AS 07/03/2007 CORE9 END Add ExceptionType
				
				xmlResponseErrorSource = vxmlResponseNode.SelectSingleNode("ERROR/SOURCE");
				if (xmlResponseErrorSource !=  null  && xmlResponseErrorSource.InnerText.Length > 0)
				{
					strErrSource = xmlResponseErrorSource.InnerText;
				}
				xmlResponseErrorSource =  null ;
				xmlResponseErrorDesc = vxmlResponseNode.SelectSingleNode("ERROR/DESCRIPTION");
				if (xmlResponseErrorDesc !=  null  && xmlResponseErrorDesc.InnerText.Length > 0)
				{
					strErrDesc = xmlResponseErrorDesc.InnerText;
				}
				xmlResponseErrorDesc =  null ;
				if (strErrDesc.Length == 0)
				{
					strErrDesc = errGetMessageText((int) OMIGAERROR.oeUnspecifiedError);
				}
				
				throw new System.Exception(lngErrNo.ToString() + ", " + strErrSource + ", " + strErrDesc + ", " + strHelpFile + ", " +  null ); //  AS 07/03/2007 CORE9 Add ExceptionType
			}
		}
		
		// AS 07/03/2007 CORE9 START Add ExceptionType
		static public string errGetExceptionType( ErrObject objErr)
		{
			string result = String.Empty;
			// header ----------------------------------------------------------------------------------
			// description:  Gets any exception type from a VB error object.
			// pass:         An optional VB error object (if not supplied then Err is used).
			// return:       The exception type, as a string.
			// Exception type information is held in the Err.HelpFile property, in the format, e.g.,
			// "ExceptionType=Vertex.Fsd.Omiga.Core.OmigaException".
			//------------------------------------------------------------------------------------------
			
			string strHelpFile = String.Empty;
			if (objErr ==  null )
			{
				strHelpFile = Information.Err().HelpFile;
			} else
			{
				strHelpFile = objErr.HelpFile;
			}
			
			if (strHelpFile.Length >= gstrEXCEPTIONTYPEPREFIX.Length && strHelpFile.Substring(0, Math.Min(strHelpFile.Length, gstrEXCEPTIONTYPEPREFIX.Length)).ToLower() == gstrEXCEPTIONTYPEPREFIX.ToLower())
			{
				result = strHelpFile.Substring(strHelpFile.Length - (Math.Min(strHelpFile.Length, strHelpFile.Length - gstrEXCEPTIONTYPEPREFIX.Length)));
			}
			return result;
		}
		
		static public string errGetExceptionType()
		{
			return errGetExceptionType( null );
		}
		
		static public string errGetExceptionTypeFromResponse( XmlElement vxmlResponseNode)
		{
			string result = String.Empty;
			XmlNode xmlResponseErrorExceptionType = vxmlResponseNode.SelectSingleNode("ERROR/EXCEPTIONTYPE");
			if (xmlResponseErrorExceptionType !=  null  && xmlResponseErrorExceptionType.InnerText.Length > 0)
			{
				result = xmlResponseErrorExceptionType.InnerText;
			}
			return result;
		}
		
		static public bool errIsExceptionType( string strCheckExceptionType,  ErrObject objErr)
		{
			bool result = false;
			// header ----------------------------------------------------------------------------------
			// description:  Checks whether an error is of a specified type.
			// pass:         The exception type to check, and an optional VB error object
			//               (if not supplied then Err is used).
			// return:       True if the exception type matches.
			//------------------------------------------------------------------------------------------
			string strExceptionType = errGetExceptionType(objErr);
			if (strExceptionType.Length >= strCheckExceptionType.Length && strExceptionType.Substring(strExceptionType.Length - (Math.Min(strExceptionType.Length, strCheckExceptionType.Length))) == strCheckExceptionType)
			{
				// Must be case sensitive as exception types names are case sensitive, i.e.,
				// TESTException is a different type to TestException.
				// Note: avoid type names that differ only by case.
				result = true;
			}
			return result;
		}
		
		static public bool errIsExceptionType( string strCheckExceptionType)
		{
			return errIsExceptionType(strCheckExceptionType,  null );
		}
		
		static private string errCreateHelpFileFromExceptionType( string strExceptionType)
		{
			return (strExceptionType.Length > 0) ? gstrEXCEPTIONTYPEPREFIX + strExceptionType: "";
		}
		// AS 07/03/2007 CORE9 END Add ExceptionType
	}
}