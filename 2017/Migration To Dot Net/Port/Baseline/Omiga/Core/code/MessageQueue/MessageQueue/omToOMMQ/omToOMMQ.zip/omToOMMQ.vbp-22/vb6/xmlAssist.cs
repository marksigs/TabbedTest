using Microsoft.VisualBasic; 

using System.Xml; 

using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToOMMQ
{
	class xmlAssistEx
	{
	
		//header ----------------------------------------------------------------------------------
		//Workfile:      xmlAssist.bas
		//Copyright:     Copyright � 2001 Marlborough Stirling
		//
		//Description:   Helper functions for XML handling
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		//History:
		//
		//Prog    Date        Description
		//IK      01/11/00    Initial creation
		//ASm     15/01/01    SYS1824: Rationalisation of methods following meeting with PC and IK
		//LD      30/01/01    Add optional default value to xmlGetAttribute*
		//PSC     22/02/01    Add xmlGetRequestNode
		//SR      05/03/01    New methods 'xmlSetSysDateToNodeAttrib' and 'xmlSetSysDateToNodeListAttribs'
		//PSC     10/04/01    Add extra parameter to the Check/Get mandatory attribut/node methods to
		//                    enable the default message to be overridden
		//SR      13/06/01    SYS2362 - modified method 'xmlMakeNodeElementBased'. Create attrib for
		//                    combo descriptions
		//SR      12/07/01    SYS2412 : new method 'xmlChangeNodeName'
		//AW      02/02/04    Made 'xmlParserError' Public in line with Baseline changes
		//
		//------------------------------------------------------------------------------------------
		//------------------------------------------------------------------------------------------
		//BMIDS Specific History:
		//
		// Prog  Date        AQR         Description
		// MV    12/08/2002  BMIDS00323  Core AQR: SYS4754 - Performance. Replace all For...Each...Next with For...Next
		//                               Modified AttachResponseData(),xmlCreateChildRequest(),xmlCreateAttributeBasedResponse(),
		//                               xmlMakeNodeElementBased(),xmlCreateElementRequestFromNode(),
		//                               xmlChangeNodeName(),xmlSetSysDateToNodeListAttribs()
		//------------------------------------------------------------------------------------------
		//------------------------------------------------------------------------------------------
		//BBG Specific History:
		//
		//Prog   Date        AQR         Description
		//MV     23/02/2004  BBG74       Created a new method xmlCreateDOMObject
		//TK     14/01/2005  BBG1891     Commented out all unused objects and set to nothing after using objects.
		//------------------------------------------------------------------------------------------
		private const long NO_MESSAGE_NUMBER = -1;
		static public void  xmlSetSysDateToNodeAttrib( XmlNode vxmlNode,  string strDateAttribName,  bool blnOverWrite)
		{
			//----------------------------------------------------------------------------------
			//Description :
			//Set system date to the attrib. Overwrite the existing value based on the optional
			//parameter passed in
			//Pass:
			//vxmlNode           : Node to which the required attrib is attached
			//strDateAttribName  : Name of the attribute to which the value is to be set
			//blnOverWrite       : if Yes, OverWrite the existing value(if any), else no.
			//----------------------------------------------------------------------------------
			if (xmlGetAttributeText(vxmlNode, strDateAttribName).Length > 0)
			{
				if (blnOverWrite)
				{
					xmlSetAttributeValue(vxmlNode, strDateAttribName, DateTime.Now.ToString("dd/MM/yyyy HH:MM:ss"));
				}
			} else
			{
				xmlSetAttributeValue(vxmlNode, strDateAttribName, DateTime.Now.ToString("dd/MM/yyyy HH:MM:ss"));
			}
		}
		
		static public void  xmlSetSysDateToNodeAttrib( XmlNode vxmlNode,  string strDateAttribName)
		{
			xmlSetSysDateToNodeAttrib(vxmlNode, strDateAttribName, false);
		}
		static public void  xmlSetSysDateToNodeListAttribs( XmlNodeList vxmlNodeList,  string strDateAttribName,  bool blnOverWrite)
		{
			//----------------------------------------------------------------------------------
			//Description :
			//Set system date to the attrib. Overwrite the existing value based on the optional
			//parameter passed in
			//Pass:
			//vxmlNode           : Node to which the required attrib is attached
			//strDateAttribName  : Name of the attribute to which the value is to be set
			//blnOverWrite       : if Yes, OverWrite the existing value(if any), else no.
			//----------------------------------------------------------------------------------
			
			for (long lngNodeCount = 0; lngNodeCount <= vxmlNodeList.Count - 1; lngNodeCount++ )
			{
				xmlSetSysDateToNodeAttrib(vxmlNodeList.Item(lngNodeCount), strDateAttribName, false);
			}
		}
		
		static public void  xmlSetSysDateToNodeListAttribs( XmlNodeList vxmlNodeList,  string strDateAttribName)
		{
			xmlSetSysDateToNodeListAttribs(vxmlNodeList, strDateAttribName, false);
		}
		static public void  xmlParserError( Exception vobjParseError,  string vstrCallingFunction)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Raise XML parser error
			// pass:         vobjParseError parser error
			//               vstrCallingFunction name of the original calling function
			// return:       n/a
			//------------------------------------------------------------------------------------------
			
			string strParserError = FormatParserError(vobjParseError);
			errAssistEx.errThrowError(vstrCallingFunction, (int) OMIGAERROR.oeXMLParserError);
			
		}
		static private string FormatParserError( Exception objParseError)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Format parser error into user friendly error information
			// pass:         vobjParseError parser error
			// return:       Parser error converted to a string
			//------------------------------------------------------------------------------------------
			//UPGRADE_ISSUE:MSXML2.IXMLDOMParseError property objParseError.srcText was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
			//UPGRADE_ISSUE:MSXML2.IXMLDOMParseError property objParseError.errorCode was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
			string strErrDesc = "XML parser error - " + "\r" + "Reason: " + objParseError.Message + "\r" + "Error code: " + objParseError.errorCode.ToString() + "\r" + "Line no.: " + ((System.Xml.XmlException) objParseError).LineNumber.ToString() + "\r" + "Character: " + ((System.Xml.XmlException) objParseError).LinePosition.ToString() + "\r" + "Source text: " + objParseError.srcText; //  formatted parser error
			return strErrDesc;
		}
		static public MSXML2.FreeThreadedDOMDocument40 xmlLoad( string vstrXMLData,  string vstrCallingFunction)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Creates and loads an XML Document from a string
			// pass:         vstrXMLData as xml data stream to be loaded
			//               vstrCallingFunction which is the name of the calling function
			// return:       XML DOM Document of the vstrXMLData string
			//------------------------------------------------------------------------------------------
			
			string strFunctionName = "xmlLoad";
			MSXML2.FreeThreadedDOMDocument40 objXmlDoc = new MSXML2.FreeThreadedDOMDocument40();
			objXmlDoc.async = false; //  wait until XML is fully loaded
			objXmlDoc.setProperty("NewParser", true);
			objXmlDoc.validateOnParse = false;
			objXmlDoc.loadXML(vstrXMLData);
			//UPGRADE_ISSUE:MSXML2.IXMLDOMParseError property parseError.errorCode was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
			if (objXmlDoc.parseError.errorCode != 0)
			{
				xmlParserError(objXmlDoc.parseError, vstrCallingFunction);
			}
			return objXmlDoc;
		}
		static private XmlNode GetNode( XmlNode vxmlParentNode,  string vstrMatchPattern,  bool vblnMandatoryNode,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vblnMandatoryNode   Optional -
			//                                   if true, an error is raised if the pattern is not met.
			//                                   If false, nothing is returned.
			// return:       IXMLDOMNode         The node which matches the search pattern
			//------------------------------------------------------------------------------------------
			const string cstrFunctionName = "xmlGetNode";
			if (vxmlParentNode ==  null )
			{
				errAssistEx.errThrowError(cstrFunctionName, (int) OMIGAERROR.oeMissingElement, "Missing parent node");
			}
			XmlNode xmlNode = vxmlParentNode.SelectSingleNode(vstrMatchPattern);
			if (vblnMandatoryNode && xmlNode ==  null )
			{
				if (vlngMessageNo == NO_MESSAGE_NUMBER)
				{
					errAssistEx.errThrowError(cstrFunctionName, (int) OMIGAERROR.oeMissingElement, "Match pattern:- " + vstrMatchPattern);
				} else
				{
					errAssistEx.errThrowError(cstrFunctionName, (int) vlngMessageNo);
				}
			}
			return xmlNode;
		}
		
		static private XmlNode GetNode( XmlNode vxmlParentNode,  string vstrMatchPattern,  bool vblnMandatoryNode)
		{
			return GetNode(vxmlParentNode, vstrMatchPattern, vblnMandatoryNode, NO_MESSAGE_NUMBER);
		}
		
		static private XmlNode GetNode( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return GetNode(vxmlParentNode, vstrMatchPattern, false, NO_MESSAGE_NUMBER);
		}
		static public XmlNode xmlGetNode( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			// header ----------------------------------------------------------------------------------
			// description:      Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:             vxmlParentNode      Node to be searched
			// return:           The node which matches the search pattern
			//                   Nothing if the node is not found
			//------------------------------------------------------------------------------------------
			
			return GetNode(vxmlParentNode, vstrMatchPattern);
		}
		static public string xmlGetNodeText( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			string result = String.Empty;
			// header ----------------------------------------------------------------------------------
			// description:      Gets the node text
			// pass:             vxmlParentNode      xml Node to search for child node
			//                   vstrMatchPattern    XSL pattern match
			// return:           Node text of child node
			//                   empty string if node not found
			//------------------------------------------------------------------------------------------
			XmlNode xmlNode = xmlGetNode(vxmlParentNode, vstrMatchPattern);
			if (xmlNode !=  null )
			{
				result = xmlNode.InnerText;
				xmlNode =  null ;
			}
			return result;
		}
		static public bool xmlGetNodeAsBoolean( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			bool result = false;
			// header ----------------------------------------------------------------------------------
			// description:  Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			// return:       True if node text = "1" or "Y" or "YES" else False
			//               False if node not found
			//------------------------------------------------------------------------------------------
			string strValue = xmlGetNodeText(vxmlParentNode, vstrMatchPattern);
			strValue = strValue.ToUpper();
			if (strValue == "1" || strValue == "Y" || strValue == "YES")
			{
				result = true;
			}
			return result;
		}
		static public System.DateTime xmlGetNodeAsDate( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			// return:       The text value of the found node as a Date
			//               empty Date if node not found
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeDate(xmlGetNodeText(vxmlParentNode, vstrMatchPattern));
		}
		static public double xmlGetNodeAsDouble( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			// return:       The text value of the found node as a Double
			//               0 if node not found
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeDbl(xmlGetNodeText(vxmlParentNode, vstrMatchPattern));
		}
		static public int xmlGetNodeAsInteger( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			// return:       The text value of the found node as a Integer
			//               0 if node not found
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeInt(xmlGetNodeText(vxmlParentNode, vstrMatchPattern));
		}
		static public long xmlGetNodeAsLong( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			// return:       The text value of the found node as a Long
			//               0 if node not found
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeLng(xmlGetNodeText(vxmlParentNode, vstrMatchPattern));
		}
		static public void  xmlCheckMandatoryNode( XmlNode vxmlParentNode,  string vstrMatchPattern,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  calls GetNode to check that specified node exists
			//               GetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			//------------------------------------------------------------------------------------------
			GetNode(vxmlParentNode, vstrMatchPattern, true, vlngMessageNo);
		}
		
		static public void  xmlCheckMandatoryNode( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			xmlCheckMandatoryNode(vxmlParentNode, vstrMatchPattern, NO_MESSAGE_NUMBER);
		}
		static public XmlNode xmlGetMandatoryNode( XmlNode vxmlParentNode,  string vstrMatchPattern,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetNode to check that specified node exists and return node
			//               xmlGetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			// return:       IXMLDOMNode         The node which matches the search pattern or
			//------------------------------------------------------------------------------------------
			return GetNode(vxmlParentNode, vstrMatchPattern, true, vlngMessageNo);
		}
		
		static public XmlNode xmlGetMandatoryNode( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return xmlGetMandatoryNode(vxmlParentNode, vstrMatchPattern, NO_MESSAGE_NUMBER);
		}
		static public XmlNodeList xmlGetMandatoryNodeList( XmlNode vxmlParentNode,  string vstrMatchPattern,  long vlngMessageNo)
		{
			XmlNodeList result =  null ;
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetNode to check that specified node exists and return node
			//               xmlGetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			// return:       IXMLDOMNode         The node which matches the search pattern or
			//------------------------------------------------------------------------------------------
			
			const string cstrFunctionName = "xmlGetMandatoryNodeList";
			result = vxmlParentNode.SelectNodes(vstrMatchPattern);
			if (result.Count == 0)
			{
				if (vlngMessageNo == NO_MESSAGE_NUMBER)
				{
					errAssistEx.errThrowError(cstrFunctionName, (int) OMIGAERROR.oeMissingElement, "Match pattern:- " + vstrMatchPattern);
				} else
				{
					errAssistEx.errThrowError(cstrFunctionName, (int) vlngMessageNo);
				}
			}
			return result;
		}
		
		static public XmlNodeList xmlGetMandatoryNodeList( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return xmlGetMandatoryNodeList(vxmlParentNode, vstrMatchPattern, NO_MESSAGE_NUMBER);
		}
		static public string xmlGetMandatoryNodeText( XmlNode vxmlParentNode,  string vstrMatchPattern, ref  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetNode to check that specified node exists and return node
			//               xmlGetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			// return:       String              Node text of child node
			//------------------------------------------------------------------------------------------
			XmlNode xmlNode = xmlGetMandatoryNode(vxmlParentNode, vstrMatchPattern, vlngMessageNo);
			string strValue = xmlNode.InnerText;
			xmlNode =  null ;
			if (strValue.Length == 0)
			{
				if (vlngMessageNo == NO_MESSAGE_NUMBER)
				{
					errAssistEx.errThrowError("xmlGetMandatoryNodeText", (int) OMIGAERROR.oeMissingElementValue, "Match pattern:- " + vstrMatchPattern);
				} else
				{
					errAssistEx.errThrowError("xmlGetMandatoryNodeText", (int) vlngMessageNo);
				}
			}
			return strValue;
		}
		
		static public string xmlGetMandatoryNodeText( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return xmlGetMandatoryNodeText(vxmlParentNode, vstrMatchPattern, ref NO_MESSAGE_NUMBER);
		}
		static public bool xmlGetMandatoryNodeAsBoolean( XmlNode vxmlParentNode,  string vstrMatchPattern,  long vlngMessageNo)
		{
			bool result = false;
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetNode to check that specified node exists and return node
			//               xmlGetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			// return:       True if node text = "1" or "Y" or "YES" else False
			//------------------------------------------------------------------------------------------
			string strValue = xmlGetMandatoryNodeText(vxmlParentNode, vstrMatchPattern, ref vlngMessageNo);
			if (strValue == "1" || strValue == "Y" || strValue == "YES")
			{
				result = true;
			}
			return result;
		}
		
		static public bool xmlGetMandatoryNodeAsBoolean( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return xmlGetMandatoryNodeAsBoolean(vxmlParentNode, vstrMatchPattern, NO_MESSAGE_NUMBER);
		}
		static public System.DateTime xmlGetMandatoryNodeAsDate( XmlNode vxmlParentNode,  string vstrMatchPattern,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetNode to check that specified node exists and return node
			//               xmlGetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			// return:       The text value of the found node as a Date
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeDate(xmlGetMandatoryNodeText(vxmlParentNode, vstrMatchPattern, ref vlngMessageNo));
		}
		
		static public System.DateTime xmlGetMandatoryNodeAsDate( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return xmlGetMandatoryNodeAsDate(vxmlParentNode, vstrMatchPattern, NO_MESSAGE_NUMBER);
		}
		static public double xmlGetMandatoryNodeAsDouble( XmlNode vxmlParentNode,  string vstrMatchPattern,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetNode to check that specified node exists and return node
			//               xmlGetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			// return:       The text value of the found node as a Double
			//------------------------------------------------------------------------------------------
			return ConvertAssistEx.CSafeDbl(xmlGetMandatoryNodeText(vxmlParentNode, vstrMatchPattern, ref vlngMessageNo));
		}
		
		static public double xmlGetMandatoryNodeAsDouble( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return xmlGetMandatoryNodeAsDouble(vxmlParentNode, vstrMatchPattern, NO_MESSAGE_NUMBER);
		}
		static public int xmlGetMandatoryNodeAsInteger( XmlNode vxmlParentNode,  string vstrMatchPattern,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetNode to check that specified node exists and return node
			//               xmlGetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			// return:       The text value of the found node as a Integer
			//------------------------------------------------------------------------------------------
			return ConvertAssistEx.CSafeInt(xmlGetMandatoryNodeText(vxmlParentNode, vstrMatchPattern, ref vlngMessageNo));
		}
		
		static public int xmlGetMandatoryNodeAsInteger( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return xmlGetMandatoryNodeAsInteger(vxmlParentNode, vstrMatchPattern, NO_MESSAGE_NUMBER);
		}
		static public long xmlGetMandatoryNodeAsLong( XmlNode vxmlParentNode,  string vstrMatchPattern,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetNode to check that specified node exists and return node
			//               xmlGetNode will raise an error if this condition is not met
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			// return:       The text value of the found node as a Long
			//------------------------------------------------------------------------------------------
			return ConvertAssistEx.CSafeLng(xmlGetMandatoryNodeText(vxmlParentNode, vstrMatchPattern, ref vlngMessageNo));
		}
		
		static public long xmlGetMandatoryNodeAsLong( XmlNode vxmlParentNode,  string vstrMatchPattern)
		{
			return xmlGetMandatoryNodeAsLong(vxmlParentNode, vstrMatchPattern, NO_MESSAGE_NUMBER);
		}
		static public XmlNode xmlGetAttributeNode( XmlNode vxmlNode,  string vstrAttributeName)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Finds the attribute node specified by vstrAttributeName
			//               in the XML node vxmlNode
			// pass:         vxmlNode            Node to be searched
			//               vstrAttributeName   Attribute to be found in the node
			// return:       IXMLDOMNode         The attribute node
			//------------------------------------------------------------------------------------------
			
			return vxmlNode.Attributes.GetNamedItem(vstrAttributeName);
		}
		static public bool xmlAttributeValueExists( XmlNode vobjNode,  string vstrAttribName)
		{
			bool result = false;
			// header ----------------------------------------------------------------------------------
			// description:  Finds the attribute node specified by vstrAttributeName
			//               in the XML node vxmlNode
			// pass:         vxmlNode            Node to be searched
			//               vstrAttributeName   Attribute to be found in the node
			// return:       True if attribute (with value) exists on node
			//------------------------------------------------------------------------------------------
			
			XmlNode xmlNode = xmlGetAttributeNode(vobjNode, vstrAttribName);
			if (xmlNode !=  null  && xmlNode.InnerText.Length > 0)
			{
				result = true;
			}
			return result;
		}
		static public string xmlGetAttributeText( XmlNode vobjNode,  string vstrAttribName,  string vstrDefault)
		{
			string result = String.Empty;
			// header ----------------------------------------------------------------------------------
			// description:      Gets the attribute node text
			// pass:             vobjNode - xml Node to search for attribute
			//                   vstrAttribName - attribute name to search for
			// return:           Node text of attribute
			//                   empty string if attribute does not exist on Node
			//------------------------------------------------------------------------------------------
			
			XmlNode xmlNode = xmlGetAttributeNode(vobjNode, vstrAttribName);
			if (xmlNode !=  null )
			{
				result = xmlNode.InnerText;
				xmlNode =  null ;
			} else
			{
				result = vstrDefault;
			}
			return result;
		}
		
		static public string xmlGetAttributeText( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetAttributeText(vobjNode, vstrAttribName, "");
		}
		static public bool xmlGetAttributeAsBoolean( XmlNode vobjNode,  string vstrAttribName,  string vstrDefault)
		{
			bool result = false;
			// header ----------------------------------------------------------------------------------
			// description:  Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			// return:       True if attribute value is "1" or "Y" or "YES"
			//               otherwise False
			//------------------------------------------------------------------------------------------
			string strValue = xmlGetAttributeText(vobjNode, vstrAttribName, vstrDefault).ToUpper();
			if (strValue == "1" || strValue == "Y" || strValue == "YES")
			{
				result = true;
			}
			return result;
		}
		
		static public bool xmlGetAttributeAsBoolean( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetAttributeAsBoolean(vobjNode, vstrAttribName, "");
		}
		static public System.DateTime xmlGetAttributeAsDate( XmlNode vobjNode,  string vstrAttribName,  string vstrDefault)
		{
			// header ----------------------------------------------------------------------------------
			// description:      Gets the attribute node as a date
			// pass:             vobjNode - xml Node to search for attribute
			//                   vstrAttribName - attribute name to search for
			// return:           Date - Node text as a date
			//                   empty date if attribute value not found
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeDate(xmlGetAttributeText(vobjNode, vstrAttribName, vstrDefault));
		}
		
		static public System.DateTime xmlGetAttributeAsDate( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetAttributeAsDate(vobjNode, vstrAttribName, "");
		}
		static public double xmlGetAttributeAsDouble( XmlNode vobjNode,  string vstrAttribName,  string vstrDefault)
		{
			// header ----------------------------------------------------------------------------------
			// description:      Gets the attribute node as a double
			// pass:             vobjNode - xml Node to search for attribute
			//                   vstrAttribName - attribute name to search for
			// return:           Double - Node text as a double
			//                   0 if attribute value not found
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeDbl(xmlGetAttributeText(vobjNode, vstrAttribName, vstrDefault));
		}
		
		static public double xmlGetAttributeAsDouble( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetAttributeAsDouble(vobjNode, vstrAttribName, "");
		}
		static public int xmlGetAttributeAsInteger( XmlNode vobjNode,  string vstrAttribName,  string vstrDefault)
		{
			// header ----------------------------------------------------------------------------------
			// description:      Gets the attribute node as a integer
			// pass:             vobjNode - xml Node to search for attribute
			//                   vstrAttribName - attribute name to search for
			// return:           Integer - Node text as a integer
			//                   0 if attribute value not found
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeInt(xmlGetAttributeText(vobjNode, vstrAttribName, vstrDefault));
		}
		
		static public int xmlGetAttributeAsInteger( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetAttributeAsInteger(vobjNode, vstrAttribName, "");
		}
		static public long xmlGetAttributeAsLong( XmlNode vobjNode,  string vstrAttribName,  string vstrDefault)
		{
			// header ----------------------------------------------------------------------------------
			// description:      Gets the attribute node as a long
			// pass:             vobjNode - xml Node to search for attribute
			//                   vstrAttribName - attribute name to search for
			// return:           Long - Node text as a long
			//                   0 if attribute value not found
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeLng(xmlGetAttributeText(vobjNode, vstrAttribName, vstrDefault));
		}
		
		static public long xmlGetAttributeAsLong( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetAttributeAsLong(vobjNode, vstrAttribName, "");
		}
		static public XmlNode xmlGetMandatoryAttribute( XmlNode vobjNode,  string vstrAttribName,  long vlngMessageNo)
		{
			XmlNode result =  null ;
			// header ----------------------------------------------------------------------------------
			// description:  Finds the attribute node specified by vstrAttributeName
			//               in the XML node vxmlNode
			// pass:         vxmlNode            Node to be searched
			//               vstrAttributeName   Attribute to be found in the node
			//               vlngMessageNo       Optional message number to override default message
			// return:       IXMLDOMNode         The attribute node
			// exceptions:
			//               raises error oeXMLMissingAttribute if attribute not found
			//------------------------------------------------------------------------------------------
			
			XmlNode xmlAttrib = vobjNode.Attributes.GetNamedItem(vstrAttribName);
			if (xmlAttrib ==  null )
			{
				if (vlngMessageNo == NO_MESSAGE_NUMBER)
				{
					errAssistEx.errThrowError("xmlGetMandatoryAttribute", (int) OMIGAERROR.oeXMLMissingAttribute, "[@" + vstrAttribName + "]");
				} else
				{
					errAssistEx.errThrowError("xmlGetMandatoryAttribute", (int) vlngMessageNo);
				}
			} else
			{
				
				result = xmlAttrib;
				xmlAttrib =  null ;
			}
			return result;
		}
		
		static public XmlNode xmlGetMandatoryAttribute( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetMandatoryAttribute(vobjNode, vstrAttribName, NO_MESSAGE_NUMBER);
		}
		static public string xmlGetMandatoryAttributeText( XmlNode vobjNode,  string vstrAttribName,  long vlngMessageNo)
		{
			string result = String.Empty;
			// header ----------------------------------------------------------------------------------
			// description:      Gets the attribute node text
			// pass:             vobjNode - xml Node to search for attribute
			//                   vstrAttribName - attribute name to search for
			//                   vlngMessageNo - Optional message number to override default message
			// return:           String - Node text of attribute
			// exceptions:
			//               raises error oeXMLMissingAttribute if attribute not found
			//               raises error oeXMLInvalidAttributeValue if attribute has no value
			//------------------------------------------------------------------------------------------
			XmlNode xmlAttrib = xmlGetMandatoryAttribute(vobjNode, vstrAttribName, vlngMessageNo);
			if (xmlAttrib.InnerText.Length == 0)
			{
				if (vlngMessageNo == NO_MESSAGE_NUMBER)
				{
					errAssistEx.errThrowError("xmlGetMandatoryAttributeText", (int) OMIGAERROR.oeXMLInvalidAttributeValue, "[@" + vstrAttribName + "]");
				} else
				{
					errAssistEx.errThrowError("xmlGetMandatoryAttributeText", (int) vlngMessageNo);
				}
			} else
			{
				
				result = xmlAttrib.InnerText;
			}
			return result;
		}
		
		static public string xmlGetMandatoryAttributeText( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetMandatoryAttributeText(vobjNode, vstrAttribName, NO_MESSAGE_NUMBER);
		}
		static public bool xmlGetMandatoryAttributeAsBoolean( XmlNode vobjNode,  string vstrAttribName,  long vlngMessageNo)
		{
			bool result = false;
			// header ----------------------------------------------------------------------------------
			// description:  Finds the node specified by vstrMatchPattern in the XML node vxmlParentNode
			// pass:         vxmlParentNode      Node to be searched
			//               vstrMatchPattern    XSL search pattern
			//               vlngMessageNo       Optional message number to override default message
			// return:       True if attribute value is "1" or "Y" or "YES"
			//               otherwise False
			// exceptions:
			//               raises error oeXMLMissingAttribute if attribute not found
			//               raises error oeXMLInvalidAttributeValue if attribute has no value
			//------------------------------------------------------------------------------------------
			string strValue = xmlGetMandatoryAttributeText(vobjNode, vstrAttribName, vlngMessageNo).ToUpper();
			if (strValue == "1" || strValue == "Y" || strValue == "YES")
			{
				result = true;
			}
			return result;
		}
		
		static public bool xmlGetMandatoryAttributeAsBoolean( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetMandatoryAttributeAsBoolean(vobjNode, vstrAttribName, NO_MESSAGE_NUMBER);
		}
		static public System.DateTime xmlGetMandatoryAttributeAsDate( XmlNode vobjNode,  string vstrAttribName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Gets the attribute node as a date
			// pass:         vobjNode - xml Node to search for attribute
			//               vstrAttribName - attribute name to search for
			//               vlngMessageNo - Optional message number to override default message
			// return:       Date - Node text as a date
			// exceptions:
			//               raises error oeXMLMissingAttribute if attribute not found
			//               raises error oeXMLInvalidAttributeValue if attribute has no value
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeDate(xmlGetMandatoryAttributeText(vobjNode, vstrAttribName, vlngMessageNo));
		}
		
		static public System.DateTime xmlGetMandatoryAttributeAsDate( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetMandatoryAttributeAsDate(vobjNode, vstrAttribName, NO_MESSAGE_NUMBER);
		}
		static public double xmlGetMandatoryAttributeAsDouble( XmlNode vobjNode,  string vstrAttribName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Gets the attribute node as a double
			// pass:         vobjNode - xml Node to search for attribute
			//               vstrAttribName - attribute name to search for
			//               vlngMessageNo - Optional message number to override default message
			// return:       Double - Node text as a double
			// exceptions:
			//               raises error oeXMLMissingAttribute if attribute not found
			//               raises error oeXMLInvalidAttributeValue if attribute has no value
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeDbl(xmlGetMandatoryAttributeText(vobjNode, vstrAttribName, vlngMessageNo));
		}
		
		static public double xmlGetMandatoryAttributeAsDouble( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetMandatoryAttributeAsDouble(vobjNode, vstrAttribName, NO_MESSAGE_NUMBER);
		}
		static public int xmlMandatoryGetAttributeAsInteger( XmlNode vobjNode,  string vstrAttribName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Gets the attribute node as a integer
			// pass:         vobjNode - xml Node to search for attribute
			//               vstrAttribName - attribute name to search for
			//               vlngMessageNo - Optional message number to override default message
			// return:       Integer - Node text as a integer
			// exceptions:
			//               raises error oeXMLMissingAttribute if attribute not found
			//               raises error oeXMLInvalidAttributeValue if attribute has no value
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeInt(xmlGetMandatoryAttributeText(vobjNode, vstrAttribName, vlngMessageNo));
		}
		
		static public int xmlMandatoryGetAttributeAsInteger( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlMandatoryGetAttributeAsInteger(vobjNode, vstrAttribName, NO_MESSAGE_NUMBER);
		}
		static public long xmlGetMandatoryAttributeAsLong( XmlNode vobjNode,  string vstrAttribName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Gets the attribute node as a long
			// pass:         vobjNode - xml Node to search for attribute
			//               vstrAttribName - attribute name to search for
			//               vlngMessageNo - Optional message number to override default message
			// return:       Long - Node text as a long
			// exceptions:
			//               raises error oeXMLMissingAttribute if attribute not found
			//               raises error oeXMLInvalidAttributeValue if attribute has no value
			//------------------------------------------------------------------------------------------
			
			return ConvertAssistEx.CSafeLng(xmlGetMandatoryAttributeText(vobjNode, vstrAttribName, vlngMessageNo));
		}
		
		static public long xmlGetMandatoryAttributeAsLong( XmlNode vobjNode,  string vstrAttribName)
		{
			return xmlGetMandatoryAttributeAsLong(vobjNode, vstrAttribName, NO_MESSAGE_NUMBER);
		}
		static public void  xmlCheckMandatoryAttribute( XmlNode vxmlNode,  string vstrAttributeName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:  calls xmlGetMandatoryAttributeText to check that specified attribute exists
			//               and has value,
			//               xmlGetMandatoryAttributeText will raise an error if these conditions
			//               are not met
			// pass:         vxmlNode          Node to be searched
			//               vstrAttributeName Attribute to be found in the node
			//               vlngMessageNo     Optional message number to override default message
			// exceptions:
			//               raises error oeXMLMissingAttribute if attribute not found
			//               raises error oeXMLInvalidAttributeValue if attribute has no value
			//------------------------------------------------------------------------------------------
			xmlGetMandatoryAttributeText(vxmlNode, vstrAttributeName, vlngMessageNo);
		}
		
		static public void  xmlCheckMandatoryAttribute( XmlNode vxmlNode,  string vstrAttributeName)
		{
			xmlCheckMandatoryAttribute(vxmlNode, vstrAttributeName, NO_MESSAGE_NUMBER);
		}
		static public void  xmlCopyAttribute( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies attribute named as vstrSrceAttribName, from vxmlSrceNode to vxmlDestNode
			//   will overwrite existing attribute value on vxmlDestNode
			//   will do nothing if source attribute not present or has no value
			// pass:
			//   vxmlSrceNode: source node for attribute
			//   vxmlDestNode: destination node for attribute
			//   vstrSrceAttribName: name of attribute to be copied
			//------------------------------------------------------------------------------------------
			
			if (xmlAttributeValueExists(vxmlSrceNode, vstrSrceAttribName))
			{
				vxmlDestNode.Attributes.SetNamedItem(vxmlSrceNode.Attributes.GetNamedItem(vstrSrceAttribName).CloneNode(true));
			}
		}
		static public void  xmlCopyMandatoryAttribute( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies attribute named as vstrSrceAttribName, from vxmlSrceNode to vxmlDestNode
			//   will overwrite existing attribute value on vxmlDestNode
			//   will do nothing if source attribute not present or has no value
			// pass:
			//   vxmlSrceNode: source node for attribute
			//   vxmlDestNode: destination node for attribute
			//   vstrSrceAttribName: name of attribute to be copied
			//   vlngMessageNo: Optional message number to override default message
			// exceptions:
			//   raises error oeXMLMissingAttribute if source attribute not found
			//   raises error oeXMLInvalidAttributeValue if source attribute has no value
			//------------------------------------------------------------------------------------------
			
			xmlCheckMandatoryAttribute(vxmlSrceNode, vstrSrceAttribName, vlngMessageNo);
			xmlCopyAttribute(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName);
		}
		
		static public void  xmlCopyMandatoryAttribute( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName)
		{
			xmlCopyMandatoryAttribute(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName, NO_MESSAGE_NUMBER);
		}
		static public void  xmlCopyAttributeValue( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName,  string vstrDestAttribName)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies value from attribute named as vstrSrceAttribName on vxmlSrceNode
			//   to attribute named as vstrDestAttribName on vxmlDestNode
			//   will overwrite existing attribute value on vxmlDestNode
			//   will do nothing if source attribute not present or has no value
			// pass:
			//   vxmlSrceNode: source node for attribute
			//   vxmlDestNode: destination node for attribute
			//   vstrSrceAttribName: name of attribute to be copied
			//------------------------------------------------------------------------------------------
			
			XmlAttribute xmlAttrib =  null ;
			if (xmlAttributeValueExists(vxmlSrceNode, vstrSrceAttribName))
			{
				
				xmlAttrib = vxmlDestNode.OwnerDocument.CreateAttribute(vstrDestAttribName);
				xmlAttrib.InnerText = vxmlSrceNode.Attributes.GetNamedItem(vstrSrceAttribName).InnerText;
				vxmlDestNode.Attributes.SetNamedItem((XmlNode) xmlAttrib);
				xmlAttrib =  null ;
			}
		}
		static public void  xmlCopyMandatoryAttributeValue( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName,  string vstrDestAttribName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies value from attribute named as vstrSrceAttribName on vxmlSrceNode
			//   to attribute named as vstrDestAttribName on vxmlDestNode
			//   will overwrite existing attribute value on vxmlDestNode
			//   will do nothing if source attribute not present or has no value
			// pass:
			//   vxmlSrceNode: source node for attribute
			//   vxmlDestNode: destination node for attribute
			//   vstrSrceAttribName: name of attribute to be copied
			//   vlngMessageNo: Optional message number to override default message
			// exceptions:
			//   raises error oeXMLMissingAttribute if source attribute not found
			//   raises error oeXMLInvalidAttributeValue if source attribute has no value
			//------------------------------------------------------------------------------------------
			
			xmlCheckMandatoryAttribute(vxmlSrceNode, vstrSrceAttribName, vlngMessageNo);
			XmlAttribute xmlAttrib = vxmlDestNode.OwnerDocument.CreateAttribute(vstrDestAttribName);
			
			xmlAttrib.InnerText = vxmlSrceNode.Attributes.GetNamedItem(vstrSrceAttribName).InnerText;
			vxmlDestNode.Attributes.SetNamedItem((XmlNode) xmlAttrib);
		}
		
		static public void  xmlCopyMandatoryAttributeValue( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName,  string vstrDestAttribName)
		{
			xmlCopyMandatoryAttributeValue(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName, vstrDestAttribName, NO_MESSAGE_NUMBER);
		}
		static public void  xmlCopyAttribIfMissingFromDest( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies attribute named as vstrSrceAttribName, from vxmlSrceNode to vxmlDestNode
			//   will not overwrite existing attribute value on vxmlDestNode
			//   will do nothing if source attribute not present or has no value
			// pass:
			//   vxmlSrceNode: source node for attribute
			//   vxmlDestNode: destination node for attribute
			//   vstrSrceAttribName: name of attribute to be copied
			//------------------------------------------------------------------------------------------
			
			if (! xmlAttributeValueExists(vxmlDestNode, vstrSrceAttribName))
			{
				xmlCopyAttribute(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName);
			}
		}
		//
		static public MSXML2.FreeThreadedDOMDocument40 xmlCreateDOMObject()
		{
			
			MSXML2.FreeThreadedDOMDocument40 vxmlDOMDocument = new MSXML2.FreeThreadedDOMDocument40();
			vxmlDOMDocument.setProperty("NewParser", true);
			vxmlDOMDocument.validateOnParse = false;
			vxmlDOMDocument.async = false;
			return vxmlDOMDocument;
		}
		
		static public void  xmlCopyMandatoryAttribIfMissingFromDest( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies attribute named as vstrSrceAttribName, from vxmlSrceNode to vxmlDestNode
			//   will not overwrite existing attribute value on vxmlDestNode
			//   will do nothing if source attribute not present or has no value
			// pass:
			//   vxmlSrceNode: source node for attribute
			//   vxmlDestNode: destination node for attribute
			//   vstrSrceAttribName: name of attribute to be copied
			//   vlngMessageNo: Optional message number to override default message
			// exceptions:
			//   raises error oeXMLMissingAttribute if source attribute not found
			//   raises error oeXMLInvalidAttributeValue if source attribute has no value
			//------------------------------------------------------------------------------------------
			
			xmlCheckMandatoryAttribute(vxmlSrceNode, vstrSrceAttribName, vlngMessageNo);
			xmlCopyAttribIfMissingFromDest(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName);
		}
		
		static public void  xmlCopyMandatoryAttribIfMissingFromDest( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName)
		{
			xmlCopyMandatoryAttribIfMissingFromDest(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName, NO_MESSAGE_NUMBER);
		}
		static public void  xmlChangeNodeName(ref  XmlNode rxmlNode,  string vstrOldName,  string vstrNewName)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   Changes all nodes present in rxmlNode that have a node name
			//   of vstrOldName to vstrNewName
			//
			// pass:
			//       rxmlNode    Xml Node
			//       vstrOldName Name of nodes to be changed
			//       vstrNewName Name nodes are to be changed to
			// return:   n/a
			// Raise Errors:
			//------------------------------------------------------------------------------------------
			XmlNode objNewNode =  null ;
			try
			{
					
					string strFunctionName = String.Empty;
					strFunctionName = "xmlChangeNodeName";
					
					int intListLength = 0;
					int intChildNodesLength = 0;
					
					// If this node is to be renamed create a new node with the new name
					// and copy all the attributes across
					XmlElement objElement =  null ;
					if (rxmlNode.Name == vstrOldName)
					{
						objNewNode = rxmlNode.OwnerDocument.CreateNode(rxmlNode.NodeType, vstrNewName, rxmlNode.NamespaceURI);
						// Copy attributes if this is an element node
						if (objNewNode.NodeType == XmlNodeType.Element)
						{
							
							objElement = (XmlElement) objNewNode;
							for (int intAttribIndex = 0; intAttribIndex <= ((int) (rxmlNode.Attributes.Count - 1)); intAttribIndex++ )
							{
								objElement.SetAttributeNode((XmlAttribute) rxmlNode.Attributes.Item(intAttribIndex).CloneNode(true));
							}
						}
					}
					
					// For all children of this node change their name if it is vstrOldName and
					// append them to the new node
					for (int intChildIndex = 0; intChildIndex <= ((int) (rxmlNode.ChildNodes.Count - 1)); intChildIndex++ )
					{
						XmlNode tempRefParam = rxmlNode.ChildNodes.Item(intChildIndex);
						xmlChangeNodeName(ref tempRefParam, vstrOldName, vstrNewName);
						if (objNewNode !=  null )
						{
							objNewNode.AppendChild(rxmlNode.ChildNodes.Item(intChildIndex).CloneNode(true));
						}
					}
					// Replace the original node with the new node
					if (objNewNode !=  null )
					{
						if (rxmlNode.ParentNode !=  null )
						{
							rxmlNode.ParentNode.ReplaceChild(objNewNode, rxmlNode);
						}
						rxmlNode = objNewNode;
					}
					objNewNode =  null ;
					objElement =  null ;
				}
			catch (System.Exception excep)
			{
				
				
				objNewNode =  null ;
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
		}
		static public void  xmlCopyAttribValueIfMissingFromDest( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName,  string vstrDestAttribName)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies value from attribute named as vstrSrceAttribName on vxmlSrceNode
			//   to attribute named as vstrDestAttribName on vxmlDestNode
			//   will not overwrite existing attribute value on vxmlDestNode
			//   will do nothing if source attribute not present or has no value
			// pass:
			//   vxmlSrceNode: source node for attribute
			//   vxmlDestNode: destination node for attribute
			//   vstrSrceAttribName: name of attribute to be copied
			//------------------------------------------------------------------------------------------
			
			if (! xmlAttributeValueExists(vxmlDestNode, vstrSrceAttribName))
			{
				xmlCopyAttributeValue(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName, vstrDestAttribName);
			}
		}
		static public void  xmlCopyMandatoryAttribValueIfMissingFromDest( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName,  string vstrDestAttribName,  long vlngMessageNo)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   copies value from attribute named as vstrSrceAttribName on vxmlSrceNode
			//   to attribute named as vstrDestAttribName on vxmlDestNode
			//   will not overwrite existing attribute value on vxmlDestNode
			//   will do nothing if source attribute not present or has no value
			// pass:
			//   vxmlSrceNode: source node for attribute
			//   vxmlDestNode: destination node for attribute
			//   vstrSrceAttribName: name of attribute to be copied
			//   vlngMessageNo: Optional message number to override default message
			// exceptions:
			//   raises error oeXMLMissingAttribute if source attribute not found
			//   raises error oeXMLInvalidAttributeValue if source attribute has no value
			//------------------------------------------------------------------------------------------
			
			xmlCheckMandatoryAttribute(vxmlSrceNode, vstrSrceAttribName, vlngMessageNo);
			if (! xmlAttributeValueExists(vxmlDestNode, vstrSrceAttribName))
			{
				xmlCopyAttribValueIfMissingFromDest(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName, vstrDestAttribName);
			}
		}
		
		static public void  xmlCopyMandatoryAttribValueIfMissingFromDest( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode,  string vstrSrceAttribName,  string vstrDestAttribName)
		{
			xmlCopyMandatoryAttribValueIfMissingFromDest(vxmlSrceNode, vxmlDestNode, vstrSrceAttribName, vstrDestAttribName, NO_MESSAGE_NUMBER);
		}
		static public void  xmlSetAttributeValue( XmlNode vxmlDestNode,  string vstrAttribName,  string vstrAttribValue)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   Creates a xml attribute on vxmlDestNode,
			//   will overwrite existing attribute value
			// pass:
			//   vxmlDestNode - Destination Node for new attribute to be placed on
			//   vstrAttribName - Attrbiute name of the new attribute
			//   vstrAttribValue - Attribute value for new attribute on vxmlDestNode
			//------------------------------------------------------------------------------------------
			
			XmlAttribute xmlAttrib = vxmlDestNode.OwnerDocument.CreateAttribute(vstrAttribName);
			xmlAttrib.Value = vstrAttribValue;
			
			vxmlDestNode.Attributes.SetNamedItem(xmlAttrib.CloneNode(true));
		}
		static public void  xmlSetAttributeValueIfMissingFromDest( XmlNode vxmlDestNode,  string vstrAttribName,  string vstrAttribValue)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   Creates a xml attribute on vxmlDestNode,
			//   will not overwrite existing attribute value
			// pass:
			//   vxmlDestNode - Destination Node for new attribute to be placed on
			//   vstrAttribName - Attrbiute name of the new attribute
			//   vstrAttribValue - Attribute value for new attribute on vxmlDestNode
			//------------------------------------------------------------------------------------------
			
			XmlAttribute xmlAttrib =  null ;
			if (! xmlAttributeValueExists(vxmlDestNode, vstrAttribName))
			{
				xmlAttrib = vxmlDestNode.OwnerDocument.CreateAttribute(vstrAttribName);
				xmlAttrib.Value = vstrAttribValue;
				
				vxmlDestNode.Attributes.SetNamedItem(xmlAttrib.CloneNode(true));
				xmlAttrib =  null ;
			}
		}
		static public MSXML2.FreeThreadedDOMDocument40 xmlCreateElementRequestFromNode( XmlNode vxmlNode,  string vstrMasterTagName,  bool blnConvertChildren,  string vstrNewTagName)
		{
			MSXML2.FreeThreadedDOMDocument40 result =  null ;
			// header ----------------------------------------------------------------------------------
			// description:
			//   Convert a Request node from a attribute based to element based.
			// pass:
			//   vxmlNode            xml Request node to be converted
			//   vstrMasterTagName   name of parent tag (can be pattern match)
			//   bInConvertChildren  True/False - Convert all children of "MasterTagName" node
			//   vstrNewTagName      New name for "Master Tag" (optional)
			// return:
			//   FreeThreadedDOMDocument40         Converted Request
			// Raise Errors:
			//------------------------------------------------------------------------------------------
			MSXML2.FreeThreadedDOMDocument40 xmlDOMDocument =  null ;
			XmlNode xmlRequestNode =  null ;
			XmlNode xmlDestParentNode =  null ;
			XmlNode xmlNode =  null ;
			XmlNodeList xmlNodeList =  null ;
			string strFunctionName = "xmlCreateElementRequestFromNode";
			if (vxmlNode !=  null )
			{
				xmlDOMDocument = new MSXML2.FreeThreadedDOMDocument40();
				// create a new request node
				xmlNode = (XmlNode) xmlDOMDocument.createElement("REQUEST");
				if (xmlNode !=  null )
				{
					xmlRequestNode = xmlDOMDocument.appendChild(xmlNode);
				}
				// clone the request attributes of the passed in request node
				xmlNode = vxmlNode.OwnerDocument.SelectSingleNode("REQUEST");
				for (int intNodeCount = 0; intNodeCount <= ((int) (vxmlNode.Attributes.Count - 1)); intNodeCount++ )
				{
					xmlCopyAttribute(vxmlNode, xmlRequestNode, vxmlNode.Attributes.Item(intNodeCount).Name);
				}
				//Extract the node to convert
				xmlNodeList = vxmlNode.SelectNodes(vstrMasterTagName);
				if (xmlNodeList.Count == 0)
				{
					errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeXMLMissingElementText, "No matching nodes found for: " + vstrMasterTagName);
				}
				foreach (XmlNode xmlNode2 in xmlNodeList)
				{
					xmlNode2 = xmlMakeNodeElementBased(xmlNode2, blnConvertChildren, vstrNewTagName);
					xmlDestParentNode = xmlRequestNode.AppendChild(xmlNode2);
				}
				xmlNode =  null ;
				result = xmlDOMDocument;
			}
			
			return result;
		}
		
		static public MSXML2.FreeThreadedDOMDocument40 xmlCreateElementRequestFromNode( XmlNode vxmlNode,  string vstrMasterTagName,  bool blnConvertChildren)
		{
			return xmlCreateElementRequestFromNode(vxmlNode, vstrMasterTagName, blnConvertChildren, "");
		}
		//UPGRADE_WARNING:ParamArray vstrAttributes was changed from ByRef to ByVal. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="93C6A0DC-8C99-429A-8696-35FC4DCEFCCC"'
		static public XmlNode xmlMakeNodeElementBased( XmlNode vxmlNode,  bool blnConvertChildren,  string vstrNewTagName, params  string[] vstrAttributes)
		{
			XmlNode result =  null ;
			// header ----------------------------------------------------------------------------------
			// description:
			//   Convert a single node from a attribute based to element based.
			// pass:
			//   vxmlNode            xml Request node to be converted
			//   bInConvertChildren  True/False - Convert all children of "MasterTagName" node
			//   vstrNewTagName      New name for "Master Tag" (optional)
			//   vstrAttributes      ParamArray can be used to name individual attributes to be
			//                       converted. If not used all attributes are converted.
			// return:
			//   Node                Converted Node
			// Raise Errors:
			//------------------------------------------------------------------------------------------
			MSXML2.FreeThreadedDOMDocument40 xmlDOMDocument =  null ;
			XmlNode xmlDestParentNode =  null ;
			XmlNode xmlNode, xmlNode2 =  null ;
			string strComboValueNodeName, strNodeName, strAttribName = String.Empty;
			string strNodeText = String.Empty;
			int intNoOfSpecifiedTags = 0;
			string strFunctionName = "xmlMakeNodeElementBased";
			if (vxmlNode !=  null )
			{
				xmlDOMDocument = new MSXML2.FreeThreadedDOMDocument40();
				//Determine the name of the new node
				if (vstrNewTagName.Trim().Length > 0)
				{
					strNodeName = vstrNewTagName;
				} else
				{
					strNodeName = vxmlNode.Name;
				}
				// create the new node
				xmlNode = (XmlNode) xmlDOMDocument.createElement(strNodeName);
				if (xmlNode !=  null )
				{
					xmlDestParentNode = xmlDOMDocument.appendChild(xmlNode);
				}
				//Process each attribute
				// have specified a subset of the attributes to clone?
				// if we have not specified and specific tags the UBound = -1
				intNoOfSpecifiedTags = (int) ((object[]) vstrAttributes).GetUpperBound(0);
				if (intNoOfSpecifiedTags >= 0)
				{
					for (int intIndex = 0; intIndex <= ((intIndex > intNoOfSpecifiedTags) ? -1: 0); intIndex++ )
					{
						//UPGRADE_WARNING:Couldn't resolve default property of object vstrAttributes(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						strNodeText = xmlGetAttributeText(vxmlNode, (string) vstrAttributes[intIndex]);
						if (strNodeText.Length > 0)
						{
							//SR 12/06/01 : if node name is description of any combo value, create a new attribute
							//              to the respective node
							//UPGRADE_WARNING:Couldn't resolve default property of object vstrAttributes(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
							strAttribName = vstrAttributes[intIndex];
							if (strAttribName.EndsWith("_TEXT"))
							{
								strComboValueNodeName = strAttribName.Substring(0, Math.Min(strAttribName.Length, strAttribName.Length - 5));
								xmlNode2 = xmlDestParentNode.SelectSingleNode("./" + strComboValueNodeName);
								if (xmlNode2 !=  null )
								{
									xmlSetAttributeValue(xmlNode2, "TEXT", strNodeText);
								} else
								{
									//UPGRADE_WARNING:Couldn't resolve default property of object vstrAttributes(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
									xmlNode = (XmlNode) xmlDOMDocument.createElement((string) vstrAttributes[intIndex]);
									xmlNode.InnerText = strNodeText;
									xmlDestParentNode.AppendChild(xmlNode);
								}
							} else
							{
								//UPGRADE_WARNING:Couldn't resolve default property of object vstrAttributes(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
								xmlNode = (XmlNode) xmlDOMDocument.createElement((string) vstrAttributes[intIndex]);
								xmlNode.InnerText = strNodeText;
								xmlDestParentNode.AppendChild(xmlNode);
							}
						} else
						{
							//UPGRADE_WARNING:Couldn't resolve default property of object vstrAttributes(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
							errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeXMLMissingAttribute, ": " + (string) vstrAttributes[intIndex]);
						}
					}
				} else
				{ // ++ SA SYS4754
					for (int intAttribsCount = 0; intAttribsCount <= ((int) (vxmlNode.Attributes.Count - 1)); intAttribsCount++ )
					{ // ++ SA SYS4754
						//SR 12/06/01 : if node name is description of any combo value, create a new attribute
						//              to the respective node
						strAttribName = vxmlNode.Attributes.Item(intAttribsCount).Name;
						if (strAttribName.EndsWith("_TEXT"))
						{
							strComboValueNodeName = strAttribName.Substring(0, Math.Min(strAttribName.Length, strAttribName.Length - 5));
							xmlNode2 = xmlDestParentNode.SelectSingleNode("./" + strComboValueNodeName);
							if (xmlNode2 !=  null )
							{
								xmlSetAttributeValue(xmlNode2, "TEXT", vxmlNode.Attributes.Item(intAttribsCount).InnerText);
							} else
							{
								xmlNode = (XmlNode) xmlDOMDocument.createElement(vxmlNode.Attributes.Item(intAttribsCount).Name); // ++ SA SYS4754
								if (xmlNode !=  null )
								{
									xmlNode.InnerText = vxmlNode.Attributes.Item(intAttribsCount).InnerText;
									xmlDestParentNode.AppendChild(xmlNode);
								}
							}
						} else
						{
							xmlNode = (XmlNode) xmlDOMDocument.createElement(vxmlNode.Attributes.Item(intAttribsCount).Name);
							if (xmlNode !=  null )
							{
								xmlNode.InnerText = vxmlNode.Attributes.Item(intAttribsCount).InnerText;
								xmlDestParentNode.AppendChild(xmlNode);
							}
						}
					}
				}
				//If required, process each child element recursively (converting all attributes)
				if (blnConvertChildren && vxmlNode.HasChildNodes())
				{
					foreach (XmlNode xmlNode3 in vxmlNode.ChildNodes)
					{
						xmlNode3 = xmlMakeNodeElementBased(xmlNode3, blnConvertChildren, "");
						xmlDOMDocument.createElement(xmlNode3.Name);
						xmlDestParentNode.AppendChild(xmlNode3);
					}
				}
				result = xmlDestParentNode;
			}
			
			xmlDOMDocument =  null ;
			xmlDestParentNode =  null ;
			xmlNode =  null ;
			xmlNode2 =  null ;
			return result;
		}
		static public XmlNode xmlCreateAttributeBasedResponse( XmlNode vxmlNode,  bool blnConvertChild)
		{
			XmlNode result =  null ;
			// header ----------------------------------------------------------------------------------
			// description:
			//   Convert a Response node from element based to attribute based.
			// pass:
			//   vxmlNode            xml Response node to be converted
			//   bInConvertChildren  True/False - Convert all children of parent node also
			// return:
			//   Node                Converted Request
			// Raise Errors:
			//------------------------------------------------------------------------------------------
			XmlElement xmlParent =  null ;
			XmlNode xmlNode =  null ;
			bool blnNoChildren = false;
			if (vxmlNode !=  null )
			{
				//Clone the parent node (without child nodes) as a basis for the returned node
				xmlParent = (XmlElement) vxmlNode.CloneNode(false);
				//Iterate through each child node
				for (int intChildCount = 0; intChildCount <= ((int) (vxmlNode.ChildNodes.Count - 1)); intChildCount++ )
				{
					
					//Check if it is a 'text' node or genuinely has child elements
					if (vxmlNode.ChildNodes.Item(intChildCount).HasChildNodes())
					{
						if (vxmlNode.ChildNodes.Item(intChildCount).ChildNodes.Item(0).Name == "#text")
						{
							blnNoChildren = true;
						}
					} else
					{
						blnNoChildren = true;
					}
					if (blnNoChildren && vxmlNode.ChildNodes.Item(intChildCount).InnerText.Trim().Length > 0)
					{
						
						//Create as an attribute of parent
						xmlParent.SetAttribute(vxmlNode.ChildNodes.Item(intChildCount).Name, vxmlNode.ChildNodes.Item(intChildCount).InnerText);
						//Check if combo item with TEXT attribute
						for (int intAttribsCount = 0; intAttribsCount <= ((int) (vxmlNode.ChildNodes.Item(intChildCount).Attributes.Count - 1)); intAttribsCount++ )
						{
							if (vxmlNode.ChildNodes.Item(intChildCount).Attributes.Item(intAttribsCount).Name.ToUpper() == "TEXT")
							{
								
								//Create a text attribute also for the combo text
								xmlParent.SetAttribute(vxmlNode.ChildNodes.Item(intChildCount).Name + "_TEXT", vxmlNode.ChildNodes.Item(intChildCount).Attributes.Item(intAttribsCount).InnerText);
							}
						}
					} else if (blnConvertChild && ! blnNoChildren) { 
						
						//Process child node recursively
						xmlNode = xmlCreateAttributeBasedResponse(vxmlNode.ChildNodes.Item(intChildCount), blnConvertChild);
						xmlParent.AppendChild(xmlNode);
					}
					blnNoChildren = false;
				}
				result = (XmlNode) xmlParent;
			}
			
			return result;
		}
		static public XmlNode xmlCreateChildRequest( XmlElement vxmlDataNode,  XmlNode vxmlSchemaNode,  string vstrNewName,  bool blnComboLookup)
		{
			XmlNode result =  null ;
			// header ----------------------------------------------------------------------------------
			// description:
			//   Create a Request node that can be used to find all matching records in a child table
			// pass:
			//   vxmlDataNode        xml element to be converted
			//   vxmlSchemaNode      Schema entry for the parent table
			//   vstrNewName         Name of the child node to be created
			// return:
			//   Node                Converted Request
			// Raise Errors:
			//------------------------------------------------------------------------------------------
			string strFunctionName = "xmlCreateChildRequest";
			MSXML2.FreeThreadedDOMDocument40 xmlDoc =  null ;
			XmlElement xmlNewNode =  null ;
			XmlAttribute xmlAttrib =  null ;
			string strValue = String.Empty;
			if ((vxmlDataNode !=  null ) && (vxmlSchemaNode !=  null ) && vstrNewName.Trim().Length > 0)
			{
				//Create a new root node
				xmlDoc = new MSXML2.FreeThreadedDOMDocument40();
				xmlNewNode = xmlDoc.createElement(vstrNewName);
				if (blnComboLookup)
				{
					xmlNewNode.SetAttribute("_COMBOLOOKUP_", "1");
				}
				//Iterate through the schema node to get the primary key items
				for (int intSchemaCount = 0; intSchemaCount <= ((int) (vxmlSchemaNode.ChildNodes.Count - 1)); intSchemaCount++ )
				{
					if (vxmlSchemaNode.ChildNodes.Item(intSchemaCount).Attributes.GetNamedItem("KEYTYPE") !=  null )
					{
						strValue = vxmlSchemaNode.ChildNodes.Item(intSchemaCount).Attributes.GetNamedItem("KEYTYPE").InnerText;
						if (strValue == "PRIMARY")
						{
							//Get this attribute from the data element and add it to the new node
							xmlAttrib = (XmlAttribute) vxmlDataNode.Attributes.GetNamedItem(vxmlSchemaNode.ChildNodes.Item(intSchemaCount).Name);
							if (xmlAttrib !=  null )
							{
								xmlNewNode.SetAttribute(vxmlSchemaNode.ChildNodes.Item(intSchemaCount).Name, xmlAttrib.InnerText);
							}
						}
					}
				}
				result = (XmlNode) xmlNewNode;
			} else
			{
				errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeInvalidParameter);
			}
			
			return result;
		}
		
		static public XmlNode xmlCreateChildRequest( XmlElement vxmlDataNode,  XmlNode vxmlSchemaNode,  string vstrNewName)
		{
			return xmlCreateChildRequest(vxmlDataNode, vxmlSchemaNode, vstrNewName, false);
		}
		static public void  xmlElemFromAttrib( XmlNode vxmlDestParentNode,  XmlNode vxmlSrceNode,  string vstrAttribName)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   Create a Element node from an attribute
			//   with node name = attribute name and node value = attribute value
			// pass:
			//   vxmlDestParentNode  parent node for element to be created
			//   vxmlSrceNode        node that contains attribute that is source of new element
			//   vstrAttribName      Name of attribute to be located on vxmlSrceNode
			//------------------------------------------------------------------------------------------
			
			XmlElement xmlElem = vxmlDestParentNode.OwnerDocument.CreateElement(vstrAttribName);
			if (vxmlSrceNode.Attributes.GetNamedItem(vstrAttribName) !=  null )
			{
				xmlElem.InnerText = vxmlSrceNode.Attributes.GetNamedItem(vstrAttribName).InnerText;
			}
			vxmlDestParentNode.AppendChild((XmlNode) xmlElem);
		}
		static public XmlNode xmlGetRequestNode( XmlElement vxmlElement)
		{
			// header ----------------------------------------------------------------------------------
			// description:
			//   Get the <REQUEST> node from an xml element, without any children. T
			// pass:
			//   vxmlElement The element from which to get the request node
			// return:
			//   Request node
			// Raise Errors:
			//------------------------------------------------------------------------------------------
			
			const string cstrFunctionName = "xmlGetRequestNode";
			XmlNode xmlRequestNode =  null ;
			XmlNode xmlNode =  null ;
			if (vxmlElement ==  null )
			{
				errAssistEx.errThrowError(cstrFunctionName, (int) OMIGAERROR.oeMissingElement);
			}
			// If the top most tag of the node is 'REQUEST', just return the node, else
			// search for 'REQUEST'
			if (vxmlElement.Name == "REQUEST")
			{
				xmlRequestNode = vxmlElement.CloneNode(false);
			} else
			{
				xmlNode = vxmlElement.SelectSingleNode("//REQUEST");
				if (xmlNode ==  null )
				{
					errAssistEx.errThrowError(cstrFunctionName, (int) OMIGAERROR.oeMissingPrimaryTag, "Expected REQUEST tag");
				}
				xmlRequestNode = xmlNode.CloneNode(false);
			}
			// Attach the cloned node to a new dom document to ensure safety of using selectsinglenode
			// with something like this: "/REQUEST/SOMETHING"
			MSXML2.FreeThreadedDOMDocument40 xmlDocument = new MSXML2.FreeThreadedDOMDocument40();
			//UPGRADE_WARNING:Couldn't resolve default property of object xmlRequestNode. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			xmlDocument.documentElement = xmlRequestNode;
			return xmlRequestNode;
			
		}
		static public void  AttachResponseData( XmlNode vxmlNodeToAttachTo,  XmlElement vxmlResponse)
		{
			// Header ----------------------------------------------------------------------------------
			// Description:
			//   Gets the data nodes out of vxmlResponse and appends them to vxmlNodeToAttachTo
			// Pass:
			//       vxmlNodeToAttachTo  xml node to attach the data to
			//       vxmlResponse        xml element containing the response whos data is to be
			//                            extracted
			//------------------------------------------------------------------------------------------
			string strFunctionName = "AttachResponseData";
			
			if (vxmlNodeToAttachTo ==  null  || vxmlResponse ==  null )
			{
				errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeInvalidParameter, "Node to attach to or Response missing");
			}
			if (vxmlResponse.Name != "RESPONSE")
			{
				errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeInvalidParameter, "RESPONSE must be top level tag");
			}
			
			XmlNodeList xmlChildList = vxmlResponse.ChildNodes;
			for (int intChildCount = 0; intChildCount <= ((int) (xmlChildList.Count - 1)); intChildCount++ )
			{
				if (xmlChildList.Item(intChildCount).Name != "MESSAGE")
				{
					vxmlNodeToAttachTo.AppendChild(xmlChildList.Item(intChildCount).CloneNode(true));
				}
			}
		}
	}
}