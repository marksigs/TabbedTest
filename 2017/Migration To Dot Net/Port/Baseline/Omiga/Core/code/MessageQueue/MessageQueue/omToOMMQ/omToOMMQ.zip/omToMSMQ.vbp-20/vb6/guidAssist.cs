using System.Runtime.InteropServices; 

using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToMSMQ
{
	class guidAssistEx
	{
	
		
		private struct Guid
		{
			public long D1;
			public int D2;
			public int D3;
			public byte[] D4 = new byte[ + 1];
				
				public void  Initialize()
				{
						D4 = new byte[9];
				}
		}
		//UPGRADE_WARNING:Structure Guid may require marshalling attributes to be passed as an argument in this Declare statement. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"'
		[DllImport("OLE32.DLL")]
		 extern private static int WinCoCreateGuid( Guid guidNewGuid);
		static public string CreateGUID()
		{
			// -----------------------------------------------------------------------------------------
			// description:  Creates a Global Unique Identifier
			// return:
			//------------------------------------------------------------------------------------------
			//UPGRADE_WARNING:Arrays in structure guidNewGuid may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			Guid guidNewGuid =  null ;
			guidNewGuid.Initialize();
			WinCoCreateGuid(guidNewGuid);
			string strBuffer = PadRight0(strBuffer, guidNewGuid.D1.ToString("X"), 8);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D2.ToString("X"), 4);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D3.ToString("X"), 4);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D4[0].ToString("X"), 2);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D4[1].ToString("X"), 2);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D4[2].ToString("X"), 2);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D4[3].ToString("X"), 2);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D4[4].ToString("X"), 2);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D4[5].ToString("X"), 2);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D4[6].ToString("X"), 2);
			strBuffer = PadRight0(strBuffer, guidNewGuid.D4[7].ToString("X"), 2);
			return strBuffer;
		}
		static private string PadRight0( string vstrBuffer,  string vstrBit,  int intLenRequired,  bool bHyp)
		{
			// -----------------------------------------------------------------------------------------
			// description:
			// return:
			//------------------------------------------------------------------------------------------
			return vstrBuffer + vstrBit + new String('0', (long) Math.Abs(intLenRequired - vstrBit.Length));
		}
		
		static private string PadRight0( string vstrBuffer,  string vstrBit,  int intLenRequired)
		{
			return PadRight0(vstrBuffer, vstrBit, intLenRequired, false);
		}
	}
}