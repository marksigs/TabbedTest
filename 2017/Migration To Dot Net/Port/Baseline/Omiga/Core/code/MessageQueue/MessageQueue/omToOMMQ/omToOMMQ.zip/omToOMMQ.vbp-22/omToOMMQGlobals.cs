using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToOMMQ
{
	class omToOMMQGlobals
	{
	
		
		//UPGRADE_WARNING:Sub Main in a DLL won't get called. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A90BF69E-29C2-4F6F-9E44-92CFC7FAA399"'
		static public void  Main()
		{
			// adoAssist
			adoAssistEx.adoBuildDbConnectionString();
			adoAssistEx.adoLoadSchema();
		}
	}
}