using System.Xml; 

using Microsoft.VisualBasic; 

using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToMSMQ
{
	class comboAssistEx
	{
	
		//-------------------------------------------------------------------------------
		//BBG Specific History:
		//
		//Prog   Date        AQR     Description
		//TK     22/11/2004  BBG1821 Performance related fixes
		//-------------------------------------------------------------------------------
		static private MSXML2.FreeThreadedDOMDocument40 gxmldocCombos =  null ;
		//----------------------------------------------------------------------
		//BMIDS Change History
		//Prog       Date            Ref
		//GD         10/07/2002      BMIDS00165 - New Function IsValidationTypeInValidationList
		//BS         13/05/2003      BM0310 Amended test for nothing found in IsValidationTypeInValidationList
		//----------------------------------------------------------------------
		static public string GetComboText( string vstrGroupName,  int vIntValueID)
		{
			string result = String.Empty;
			
			LoadComboGroup(vstrGroupName);
			string strPattern = "COMBOLIST/COMBO[@GROUPNAME='" + vstrGroupName + "'  and  @VALUEID='" + vIntValueID.ToString() + "']";
			if (gxmldocCombos.selectSingleNode(strPattern) !=  null )
			{
				result = xmlAssistEx.xmlGetAttributeText(gxmldocCombos.selectSingleNode(strPattern), "VALUENAME");
			}
			return result;
		}
		static public bool IsValidationType( string vstrGroupName,  int vIntValueID,  string vstrValidationType)
		{
			
			LoadComboGroup(vstrGroupName);
			string strPattern = "COMBOLIST/COMBO[@GROUPNAME='" + vstrGroupName + "'  and  @VALUEID='" + vIntValueID.ToString() + "'  and  @VALIDATIONTYPE='" + vstrValidationType + "']";
			if (gxmldocCombos.selectSingleNode(strPattern) !=  null )
			{
				return true;
			} else
			{
				return false;
			}
		}
		static public void  GetValueIdsForValidationType( string vstrGroupName,  string vstrValidationType,  Collection vcolValueIds)
		{
			
			LoadComboGroup(vstrGroupName);
			string strPattern = "COMBOLIST/COMBO[@GROUPNAME='" + vstrGroupName + "'  and  @VALIDATIONTYPE='" + vstrValidationType + "']";
			XmlNodeList xmlNodeList = gxmldocCombos.selectNodes(strPattern);
			foreach (XmlNode xmlNode in xmlNodeList)
			{
				vcolValueIds.Add(xmlAssistEx.xmlGetAttributeText(xmlNode, "VALUEID"), null, null, null);
			}
		}
		static public string GetValidationTypeForValueID( string vstrGroupName,  int vIntValueID)
		{
			string result = String.Empty;
			
			
			LoadComboGroup(vstrGroupName);
			string strPattern = "COMBOLIST/COMBO[@GROUPNAME='" + vstrGroupName + "'  and  @VALUEID= " + vIntValueID.ToString() + "]";
			if (gxmldocCombos.selectSingleNode(strPattern) !=  null )
			{
				result = xmlAssistEx.xmlGetAttributeText(gxmldocCombos.selectSingleNode(strPattern), "VALIDATIONTYPE");
			}
			return result;
		}
		static private void  LoadComboValidationGroup( string vstrGroupName)
		{
			XmlElement xmlElem =  null ;
			//Dim xmlComboNode As IXMLDOMNode
			XmlNode xmlComboListNode =  null ;
			MSXML2.FreeThreadedDOMDocument40 xmlRequestDoc =  null ;
			XmlNode xmlRootNode =  null ;
			XmlNode xmlRequestNode =  null ;
			XmlNode xmlSchemaNode =  null ;
			if (gxmldocCombos ==  null )
			{
				gxmldocCombos = new MSXML2.FreeThreadedDOMDocument40();
				xmlElem = gxmldocCombos.createElement("COMBOVALIDATIONLIST");
				xmlComboListNode = gxmldocCombos.appendChild((XmlNode) xmlElem);
			}
			if (gxmldocCombos.selectSingleNode("COMBOLIST/COMBO[@GROUPNAME='" + vstrGroupName + "']") ==  null )
			{
				// create one FreeThreadedDOMDocument40 to contain schema & request
				xmlRequestDoc = new MSXML2.FreeThreadedDOMDocument40();
				// create BOGUS root node
				xmlElem = xmlRequestDoc.createElement("BOGUS");
				xmlRootNode = xmlRequestDoc.appendChild((XmlNode) xmlElem);
				// create schema for TM_COMBOS view
				xmlElem = xmlRequestDoc.createElement("SCHEMA");
				xmlSchemaNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("COMBOVALIDATION");
				xmlElem.SetAttribute("ENTITYTYPE", "LOGICAL");
				xmlElem.SetAttribute("DATASRCE", "TM_COMBOVALIDATION");
				xmlSchemaNode = xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("GROUPNAME");
				xmlElem.SetAttribute("DATATYPE", "STRING");
				xmlElem.SetAttribute("LENGTH", "30");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("VALUEID");
				xmlElem.SetAttribute("DATATYPE", "SHORT");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("VALIDATIONTYPE");
				xmlElem.SetAttribute("DATATYPE", "STRING");
				xmlElem.SetAttribute("LENGTH", "20");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				// create COMBOLIST request
				xmlElem = xmlRequestDoc.createElement("COMBOVALIDATIONLIST");
				xmlElem.SetAttribute("GROUPNAME", vstrGroupName);
				xmlRequestNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
				if (xmlComboListNode ==  null )
				{
					xmlComboListNode = gxmldocCombos.selectSingleNode("COMBOVALIDATIONLIST");
				}
				adoAssistEx.adoGetRecordSetAsXML(xmlRequestNode, xmlSchemaNode, xmlComboListNode);
			}
			
			
		}
		static private void  LoadComboGroup( string vstrGroupName)
		{
			XmlElement xmlElem =  null ;
			//Dim xmlComboNode As IXMLDOMNode
			XmlNode xmlComboListNode =  null ;
			MSXML2.FreeThreadedDOMDocument40 xmlRequestDoc =  null ;
			XmlNode xmlRootNode =  null ;
			XmlNode xmlRequestNode =  null ;
			XmlNode xmlSchemaNode =  null ;
			if (gxmldocCombos ==  null )
			{
				gxmldocCombos = new MSXML2.FreeThreadedDOMDocument40();
				xmlElem = gxmldocCombos.createElement("COMBOLIST");
				xmlComboListNode = gxmldocCombos.appendChild((XmlNode) xmlElem);
			}
			if (gxmldocCombos.selectSingleNode("COMBOLIST/COMBO[@GROUPNAME='" + vstrGroupName + "']") ==  null )
			{
				// create one FreeThreadedDOMDocument40 to contain schema & request
				xmlRequestDoc = new MSXML2.FreeThreadedDOMDocument40();
				// create BOGUS root node
				xmlElem = xmlRequestDoc.createElement("BOGUS");
				xmlRootNode = xmlRequestDoc.appendChild((XmlNode) xmlElem);
				// create schema for TM_COMBOS view
				xmlElem = xmlRequestDoc.createElement("SCHEMA");
				xmlSchemaNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("COMBO");
				xmlElem.SetAttribute("ENTITYTYPE", "LOGICAL");
				xmlElem.SetAttribute("DATASRCE", "TM_COMBOS");
				xmlSchemaNode = xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("GROUPNAME");
				xmlElem.SetAttribute("DATATYPE", "STRING");
				xmlElem.SetAttribute("LENGTH", "30");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("VALUEID");
				xmlElem.SetAttribute("DATATYPE", "SHORT");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("VALUENAME");
				xmlElem.SetAttribute("DATATYPE", "STRING");
				xmlElem.SetAttribute("LENGTH", "50");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				xmlElem = xmlRequestDoc.createElement("VALIDATIONTYPE");
				xmlElem.SetAttribute("DATATYPE", "STRING");
				xmlElem.SetAttribute("LENGTH", "20");
				xmlSchemaNode.AppendChild((XmlNode) xmlElem);
				// create COMBOLIST request
				xmlElem = xmlRequestDoc.createElement("COMBOLIST");
				xmlElem.SetAttribute("GROUPNAME", vstrGroupName);
				xmlRequestNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
				if (xmlComboListNode ==  null )
				{
					xmlComboListNode = gxmldocCombos.selectSingleNode("COMBOLIST");
				}
				adoAssistEx.adoGetRecordSetAsXML(xmlRequestNode, xmlSchemaNode, xmlComboListNode);
			}
			
			
		}
		static public string GetFirstComboValueId( string strComboGroup,  string strValidationType)
		{
			string result = String.Empty;
			Collection colValueId = new Collection();
			GetValueIdsForValidationType(strComboGroup, strValidationType, colValueId);
			if (colValueId.Count > 0)
			{
				//UPGRADE_WARNING:Couldn't resolve default property of object colValueId.Item(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				result = (string) colValueId[0];
			} else
			{
				errAssistEx.errThrowError("GetFirstComboValueId", (int) OMIGAERROR.oeRecordNotFound);
			}
			return result;
		}
		static public void  GetValueIdsForValueName( string vstrGroupName,  string vstrValueName,  Collection vcolValueIds)
		{
			
			LoadComboGroup(vstrGroupName);
			string strPattern = "COMBOLIST/COMBO[@GROUPNAME='" + vstrGroupName + "'  and  @VALUENAME='" + vstrValueName + "']";
			XmlNodeList xmlNodeList = gxmldocCombos.selectNodes(strPattern);
			foreach (XmlNode xmlNode in xmlNodeList)
			{
				vcolValueIds.Add(xmlAssistEx.xmlGetAttributeText(xmlNode, "VALUEID"), null, null, null);
			}
		}
		static public string GetFirstComboTextId( string strComboGroup,  string strValueName)
		{
			Collection colValueId = new Collection();
			GetValueIdsForValueName(strComboGroup, strValueName, colValueId);
			if (colValueId.Count > 0)
			{
				//UPGRADE_WARNING:Couldn't resolve default property of object colValueId.Item(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				return (string) colValueId[0];
			} else
			{
				return "";
			}
		}
		static public bool IsValidationTypeInValidationList( string vstrGroupName,  string vstrValidationType,  int vIntValueID)
		{
			//GD added 09/07/02
			bool blnResult = false;
			LoadComboGroup(vstrGroupName);
			string strPattern = "COMBOLIST/COMBO[@GROUPNAME='" + vstrGroupName + "'  and  @VALUEID= " + vIntValueID.ToString() + "  and  @VALIDATIONTYPE = '" + vstrValidationType + "']";
			XmlNodeList xmlValidationList = gxmldocCombos.selectNodes(strPattern);
			//BS BM0310 13/05/03
			//If Not xmlValidationList Is Nothing Then
			blnResult = xmlValidationList.Count > 0;
			return blnResult;
		}
	}
}