using System.Text; 

using System.Data.SqlClient; 

using System.Xml; 

using System.Windows.Forms; 

using System.IO; 

using Microsoft.VisualBasic; 

using System.Data; 

using System.Diagnostics; 

using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToOMMQ
{
	 
	//============================================= 
	//Enumeration Declaration Section 
	//============================================= 
	public enum DBPROVIDER
	 {
		omiga4DBPROVIDERUnknown ,
		omiga4DBPROVIDEROracle ,
		omiga4DBPROVIDERMSOracle , // SDS LIVE00009659  22/01/2004 Support for MS and Oracle OLEDB Drivers
		omiga4DBPROVIDERSQLServer
	} 
	class adoAssistEx
	{
	
		//-----------------------------------------------------------------------------
		//Prog   Date        Description
		//SR     05/03/2001  New public function 'adoGetOmigaNumberForDatabaseError'
		//AW     20/03/2001  Added 'PARAMMODE' check to adoConvertRecordSetToXML
		//AS     31/05/2001  Added adoGetValidRecordset for SQL Server Port
		//AS     11/06/2001  Fixed compile error with GENERIC_SQL=1
		//LD     12/06/2001  SYS2368 Modify code to get the connection string for Oracle and SQLServer
		//LD     11/06/2001  SYS2367 SQL Server Port - Length must be specified in calls to CreateParameter
		//LD     15/06/2001  SYS2368 SQL Server Port - Guids to be generated as type adBinary in function getParam
		//LD     19/09/2001  SYS2722 SQL Server Port - Make function adoGuidToString public
		//IK     12/10/2001  SYS2803 Work Arounds for MSXML3 IXMLDOMNodeList bug
		//PSC    17/10/01    SYS2815 Allow integrated security with SQL Server
		//SG     18/06/02    SYS4889 Code error in executeGetRecordSet
		//SDS    22/01/2004   LIVE00009659  Added pieces of code to support both Microsoft and Oracle OLEDB Drivers
		//-------------------------------------------------------------------------------
		//BBG Specific History:
		//
		//Prog   Date        AQR     Description
		//TK     22/11/2004  BBG1821 Performance related fixes
		//-------------------------------------------------------------------------------
		
		static private MSXML2.FreeThreadedDOMDocument40 gxmldocSchemas =  null ;
		static private string gstrDbConnectionString = String.Empty;
		static private int gintDbRetries = 0;
		static private DBPROVIDER genumDbProvider;
		// application name
		private const string gstrAppName = "Omiga4";
		// registry section for database connection info
		private const string gstrREGISTRY_SECTION = "Database Connection";
		// registry keys for database connection info
		private const string gstrPROVIDER_KEY = "Provider";
		private const string gstrSERVER_KEY = "Server";
		private const string gstrDATABASE_KEY = "Database Name";
		private const string gstrUID_KEY = "User ID";
		private const string gstrPASSWORD_KEY = "Password";
		private const string gstrDATA_SOURCE_KEY = "Data Source";
		// registry keys for other database info
		private const string gstrRETRIES_KEY = "Retries";
		private enum GUIDSTYLE
		 {
			guidBinary = 0 ,
			guidHyphen = 1 ,
			guidLiteral = 2
		}
		
		public const string gstrSchemaNameId = "_SCHEMA_";
		public const string gstrExtractTypeId = "_EXTRACTTYPE_";
		public const string gstrOutNodeId = "_OUTNODENAME_";
		public const string gstrOrderById = "_ORDERBY_";
		public const string gstrWhereId = "_WHERE_";
		public const string gstrDataTypeId = "DATATYPE";
		public const string gstrDataTypeDerivedId = "DERIVED";
		public const string gstrDataSourceId = "DATASRCE";
		private const string gstrMODULEPREFIX = "adoAssist.";
		private const long glngENTRYNOTFOUND = -2147024894;
		//-------------------------------------------------------------------------------
		//BMIDS History
		//RF     18/11/02    BMIDS00935 Applied Core Change SYS4752 (SYSMCP0734)
		//-------------------------------------------------------------------------------
		static public void  adoCreateFromNodeList( XmlNodeList vxmlRequestNodeList,  string vstrSchemaName)
		{
			string strFunctionName = "adoCreateFromNodeList";
			XmlNode xmlSchemaNode =  null ;
			XmlNode xmlDataNode =  null ;
			try
			{
					
					const ;
					;
					;
					xmlSchemaNode = adoGetSchema(vstrSchemaName);
					// IK AQR SYS2803
					// fix for MSXML bug
					for (int intIndex = 1; intIndex <= vxmlRequestNodeList.Count; intIndex++ )
					{
						adoCreate(vxmlRequestNodeList.Item(intIndex - 1), xmlSchemaNode);
					}
					//    For Each xmlDataNode In vxmlRequestNodeList
					//        adoCreate xmlDataNode, xmlSchemaNode
					//    Next
					
				}
			catch 
			{
			}
			
			
			xmlSchemaNode =  null ;
			xmlDataNode =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		static public void  adoCreateFromNode( XmlNode vxmlRequestNode,  string vstrSchemaName)
		{
			string strFunctionName = "adoCreateFromNode";
			XmlNode xmlSchemaNode =  null ;
			try
			{
					
					const ;
					;
					xmlSchemaNode = adoGetSchema(vstrSchemaName);
					adoCreate(vxmlRequestNode, xmlSchemaNode);
				}
			catch 
			{
			}
			
			
			xmlSchemaNode =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		static public void  adoUpdateFromNodeList( XmlNodeList vxmlRequestNodeList,  string vstrSchemaName)
		{
			string strFunctionName = "adoUpdateFromNodeList";
			XmlNode xmlSchemaNode =  null ;
			try
			{
					
					const ;
					;
					//Dim xmlDataNode As IXMLDOMNode
					xmlSchemaNode = adoGetSchema(vstrSchemaName);
					// IK AQR SYS2803
					// fix for MSXML bug
					for (int intIndex = 1; intIndex <= vxmlRequestNodeList.Count; intIndex++ )
					{
						adoUpdate(vxmlRequestNodeList.Item(intIndex - 1), xmlSchemaNode);
					}
					//    For Each xmlDataNode In vxmlRequestNodeList
					//        adoUpdate xmlDataNode, xmlSchemaNode
					//    Next
					
				}
			catch 
			{
			}
			
			
			xmlSchemaNode =  null ;
			//Set xmlDataNode = Nothing
			errAssistEx.errCheckError(strFunctionName);
		}
		static public void  adoUpdateFromNode( XmlNode vxmlRequestNode,  string vstrSchemaName)
		{
			string strFunctionName = "adoUpdateFromNode";
			XmlNode xmlSchemaNode =  null ;
			try
			{
					
					const ;
					;
					xmlSchemaNode = adoGetSchema(vstrSchemaName);
					adoUpdate(vxmlRequestNode, xmlSchemaNode);
				}
			catch 
			{
			}
			
			
			xmlSchemaNode =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		static public void  adoUpdateMultipleInstancesFromNode( XmlNode vxmlRequestNode,  string vstrSchemaName)
		{
			string strFunctionName = "adoUpdateMultipleInstancesFromNode";
			XmlNode xmlSchemaNode =  null ;
			try
			{
					
					const ;
					;
					xmlSchemaNode = adoGetSchema(vstrSchemaName);
					adoUpdate(vxmlRequestNode, xmlSchemaNode, true);
				}
			catch 
			{
			}
			
			
			xmlSchemaNode =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		static public void  adoGetAsXML( XmlNode vxmlRequestNode,  XmlNode vxmlResponseNode,  string vstrSchemaName, ref  string vstrFilter,  string vstrOrderBy)
		{
			string strFunctionName = "adoGetAsXML";
			XmlNode xmlSchemaNode =  null ;
			try
			{
					const ;
					string strOrderBy = String.Empty;
					strOrderBy = vstrOrderBy;
					if (xmlAssistEx.xmlAttributeValueExists(vxmlRequestNode, gstrOrderById))
					{
						if (strOrderBy.Length > 0)
						{
							strOrderBy = strOrderBy + ",";
						}
						strOrderBy = strOrderBy + xmlAssistEx.xmlGetAttributeText(vxmlRequestNode, gstrOrderById);
					}
					;
					xmlSchemaNode = adoGetSchema(vstrSchemaName);
					adoCloneBaseEntityRefs(xmlSchemaNode);
					if (xmlAssistEx.xmlGetAttributeText(xmlSchemaNode, "ENTITYTYPE") == "PROCEDURE")
					{
						adoGetStoredProcAsXML(vxmlRequestNode, xmlSchemaNode, vxmlResponseNode);
					} else
					{
						adoGetRecordSetAsXML(vxmlRequestNode, xmlSchemaNode, vxmlResponseNode, ref vstrFilter, ref strOrderBy);
					}
					
				}
			catch 
			{
			}
			
			
			xmlSchemaNode =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		
		static public void  adoGetAsXML( XmlNode vxmlRequestNode,  XmlNode vxmlResponseNode,  string vstrSchemaName, ref  string vstrFilter)
		{
			adoGetAsXML(vxmlRequestNode, vxmlResponseNode, vstrSchemaName, vstrFilter, "");
		}
		
		static public void  adoGetAsXML( XmlNode vxmlRequestNode,  XmlNode vxmlResponseNode,  string vstrSchemaName)
		{
			string tempRefParam = "";
			adoGetAsXML(vxmlRequestNode, vxmlResponseNode, vstrSchemaName, ref tempRefParam, "");
		}
		static public void  adoCreate( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode)
		{
			string strFunctionName = "adoCreate";
			try
			{
					
					const ;
					XmlNode xmlSchemaFieldNode =  null ;
					XmlAttribute xmlDataAttrib, xmlAttrib =  null ;
					SqlCommand cmd =  null ;
					SqlParameter param =  null ;
					string strColumns, strDataType, strSQL, strDataSource, strValues = String.Empty;
					int intRetryCount, intRetryMax = 0;
					long lngRecordsAffected = 0;
					bool blnDbCmdOk = false;
					strDataSource = xmlAssistEx.xmlGetAttributeText(vxmlSchemaNode, "DATASRCE");
					if (strDataSource.Length == 0)
					{
						strDataSource = vxmlSchemaNode.Name;
					}
					// get any generated keys & default values
					foreach (XmlNode xmlSchemaFieldNode2 in vxmlSchemaNode.ChildNodes)
					{
						if (vxmlDataNode.Attributes.GetNamedItem(xmlSchemaFieldNode2.Name) ==  null )
						{
							if (xmlSchemaFieldNode2.Attributes.GetNamedItem("DEFAULT") !=  null )
							{
								xmlAttrib = vxmlDataNode.OwnerDocument.CreateAttribute(xmlSchemaFieldNode2.Name);
								xmlAttrib.InnerText = xmlSchemaFieldNode2.Attributes.GetNamedItem("DEFAULT").InnerText;
								vxmlDataNode.Attributes.SetNamedItem((XmlNode) xmlAttrib);
							}
							if (xmlSchemaFieldNode2.Attributes.GetNamedItem("KEYTYPE") !=  null  && ((xmlSchemaFieldNode2.Attributes.GetNamedItem("KEYTYPE").InnerText == "PRIMARY") || (xmlSchemaFieldNode2.Attributes.GetNamedItem("KEYTYPE").InnerText == "SECONDARY")) && xmlSchemaFieldNode2.Attributes.GetNamedItem("KEYSOURCE") !=  null  && xmlSchemaFieldNode2.Attributes.GetNamedItem("KEYSOURCE").InnerText == "GENERATED")
							{
								GetGeneratedKey(vxmlDataNode, xmlSchemaFieldNode2);
							}
						}
					}
					xmlSchemaFieldNode =  null ;
					intRetryMax = adoGetDbRetries();
					cmd = new SqlCommand();
					foreach (XmlAttribute xmlDataAttrib2 in vxmlDataNode.Attributes)
					{
						
						xmlSchemaFieldNode = vxmlSchemaNode.SelectSingleNode(xmlDataAttrib2.Name);
						if (xmlSchemaFieldNode !=  null )
						{
							if (strColumns.Length > 0)
							{
								strColumns = strColumns + ",";
							}
							strColumns = strColumns + xmlDataAttrib2.Name;
							if (strValues.Length > 0)
							{
								strValues = strValues + ",";
							}
							strValues = strValues + "?";
							param = getParam(xmlSchemaFieldNode, xmlDataAttrib2, true);
							cmd.Parameters.Add(param);
						}
					}
					xmlDataAttrib =  null ;
					strSQL = "INSERT INTO " + strDataSource + " (" + strColumns + ") VALUES (" + strValues + ")";
					Debug.WriteLine("adoCreate strSQL: " + strSQL);
					if (strValues.Length > 0)
					{
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = strSQL;
						lngRecordsAffected = executeSQLCommand(cmd);
					}
					//    If Len(strValues) > 0 Then
					//
					//        cmd.CommandType = adCmdText
					//        cmd.CommandText = strSQL
					//
					//        On Error Resume Next
					//
					//        Do While blnDbCmdOk = False
					//
					//            lngRecordsAffected = executeSQLCommand(cmd)
					//
					//            If Err.Number = 0 Then
					//
					//                blnDbCmdOk = True
					//
					//            Else
					//
					//                If IsRetryError() = False Then
					//
					//                    On Error GoTo adoCreateExit
					//
					//                Else
					//
					//                    intRetryCount = intRetryCount + 1
					//
					//                    Dim nTimer1 As Single, _
					//'                        nTimer2 As Single
					//
					//                    ' DEBUG
					//                    App.LogEvent "adoCreate - retry [" & intRetryCount & "]: " & strSQL
					//
					//                    If (intRetryCount = intRetryMax) Then
					//
					//                        On Error GoTo adoCreateExit
					//
					//                    End If
					//
					//                End If
					//
					//            End If
					//
					//        Loop
					//
					//    End If
					
					cmd =  null ;
					xmlSchemaFieldNode =  null ;
					xmlDataAttrib =  null ;
					xmlAttrib =  null ;
					param =  null ;
					
					Debug.WriteLine("adoCreate records created: " + lngRecordsAffected.ToString());
				}
			catch 
			{
			}
			
			
			
			errAssistEx.errCheckError(strFunctionName);
		}
		static public void  adoUpdate( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode,  bool blnNonUniqueInstanceAllowed)
		{
			string strFunctionName = "adoUpdate";
			XmlNode xmlSchemaNode =  null ;
			XmlNodeList xmlSchemaNodeList =  null ;
			XmlAttribute xmlSchemaAttrib =  null ;
			XmlAttribute xmlDataAttrib =  null ;
			SqlCommand cmd =  null ;
			SqlParameter param =  null ;
			try
			{
					
					const ;
					;
					;
					;
					;
					;
					;
					string strDataType, strSQLSet, strSQL, strSQLWhere, strDataSource = String.Empty;
					int intKeys, intLoop, intSetCount, intKeyCount = 0;
					int intRetryCount, intRetryMax = 0;
					long lngRecordsAffected = 0;
					bool blnDbCmdOk = false;
					strDataSource = xmlAssistEx.xmlGetAttributeText(vxmlSchemaNode, "DATASRCE");
					if (strDataSource.Length == 0)
					{
						strDataSource = vxmlSchemaNode.Name;
					}
					intRetryMax = adoGetDbRetries();
					bool blnDoSet = false;
					cmd = new SqlCommand();
					strSQL = "UPDATE " + strDataSource;
					xmlSchemaNodeList = vxmlSchemaNode.SelectNodes("*[@DATATYPE]");
					foreach (XmlNode xmlSchemaNode2 in xmlSchemaNodeList)
					{
						blnDoSet = true;
						xmlSchemaAttrib = (XmlAttribute) xmlSchemaNode2.Attributes.GetNamedItem("KEYTYPE");
						if (xmlSchemaAttrib !=  null  && ((((string) xmlSchemaAttrib.Value) == "PRIMARY") || (((string) xmlSchemaAttrib.Value) == "SECONDARY")))
						{
							
							blnDoSet = false;
						}
						if (blnDoSet)
						{
							xmlDataAttrib = (XmlAttribute) vxmlDataNode.Attributes.GetNamedItem(xmlSchemaNode2.Name);
							if (xmlDataAttrib !=  null )
							{
								if (strSQLSet.Length != 0)
								{
									strSQLSet = strSQLSet + ", ";
								}
								strSQLSet = strSQLSet + xmlSchemaNode2.Name + "=?";
								param = getParam(xmlSchemaNode2, xmlDataAttrib);
								cmd.Parameters.Add(param);intSetCount++ ;
							}
						}
					}
					xmlSchemaNode =  null ;
					xmlSchemaNodeList = vxmlSchemaNode.SelectNodes("*[@KEYTYPE='PRIMARY']");
					intKeys = (int) xmlSchemaNodeList.Count;
					foreach (xmlSchemaNode in xmlSchemaNodeList)
					{
						
						xmlDataAttrib = (XmlAttribute) vxmlDataNode.Attributes.GetNamedItem(xmlSchemaNode.Name);
						if (xmlDataAttrib !=  null  && ((string) xmlDataAttrib.Value) != "")
						{
							if (strSQLWhere.Length != 0)
							{
								strSQLWhere = strSQLWhere + " AND ";
							}
							strSQLWhere = strSQLWhere + xmlSchemaNode.Name + "=?";
							param = getParam(xmlSchemaNode, xmlDataAttrib);
							cmd.Parameters.Add(param);intKeyCount++ ;
						}
					}
					strSQL = strSQL + " SET " + strSQLSet;
					strSQL = strSQL + " WHERE " + strSQLWhere;
					Debug.WriteLine("adoUpdate strSQL: " + strSQL);
					if ((! blnNonUniqueInstanceAllowed) && (intKeys != intKeyCount))
					{
						errAssistEx.errThrowError("adoUpdate", (int) OMIGAERROR.oeXMLMissingAttribute);
					}
					if (intSetCount > 0)
					{
						
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = strSQL;
						lngRecordsAffected = executeSQLCommand(cmd);
					}
					//On Error Resume Next
					//
					//    Do While blnDbCmdOk = False
					//
					//        cmd.CommandType = adCmdText
					//        cmd.CommandText = strSQL
					//
					//        lngRecordsAffected = executeSQLCommand(cmd)
					//
					//        If Err.Number = 0 Then
					//
					//            blnDbCmdOk = True
					//
					//        Else
					//
					//            If IsRetryError() = False Then
					//
					//                On Error GoTo adoUpdateExit
					//
					//            Else
					//
					//                intRetryCount = intRetryCount + 1
					//
					//                ' DEBUG
					//                App.LogEvent "adoUpdate - retry [" & intRetryCount & "]: " & strSQL
					//
					//                If (intRetryCount = intRetryMax) Then
					//
					//                    On Error GoTo adoUpdateExit
					//
					//                End If
					//
					//            End If
					//
					//        End If
					//
					//    Loop
					//
					//    Set cmd = Nothing
					
					Debug.WriteLine("adoUpdate records updated: " + lngRecordsAffected.ToString());
				}
			catch 
			{
			}
			
			
			cmd =  null ;
			xmlSchemaNode =  null ;
			xmlSchemaNodeList =  null ;
			xmlSchemaAttrib =  null ;
			xmlDataAttrib =  null ;
			param =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		
		static public void  adoUpdate( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode)
		{
			adoUpdate(vxmlDataNode, vxmlSchemaNode, false);
		}
		static public void  adoGetStoredProcAsXML( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode,  XmlNode vxmlResponseNode)
		{
			string strFunctionName = "adoGetRecordSetAsXML";
			XmlNodeList xmlSchemaKeyNodeList =  null ;
			XmlNode xmlSchemaKeyNode =  null ;
			SqlCommand cmd =  null ;
			DataSet rst =  null ;
			try
			{
					const ;
					;
					;
					;
					;
					string strSQLParamClause = String.Empty;
					cmd = new SqlCommand();
					xmlSchemaKeyNodeList = vxmlSchemaNode.SelectNodes("*[@KEYTYPE='PRIMARY']");
					foreach (XmlNode xmlSchemaKeyNode2 in xmlSchemaKeyNodeList)
					{
						adoAddParam(xmlSchemaKeyNode2, (XmlAttribute) xmlAssistEx.xmlGetAttributeNode(vxmlDataNode, xmlSchemaKeyNode2.Name), cmd);
						if (strSQLParamClause.Length == 0)
						{
							strSQLParamClause = "?";
						} else
						{
							strSQLParamClause = strSQLParamClause + ",?";
						}
						
					}
					xmlSchemaKeyNode =  null ;
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = "{CALL " + vxmlSchemaNode.Attributes.GetNamedItem("DATASRCE").InnerText + "(" + strSQLParamClause + ")}";
					rst = executeGetRecordSet(cmd);
					if (rst !=  null )
					{
						
						adoConvertRecordSetToXML(vxmlSchemaNode, vxmlResponseNode, rst, IsComboLookUpRequired(vxmlDataNode));
					}
				}
			catch 
			{
			}
			
			rst =  null ;
			cmd =  null ;
			xmlSchemaKeyNodeList =  null ;
			xmlSchemaKeyNode =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		static public void  adoGetRecordSetAsXML( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode,  XmlNode vxmlResponseNode, ref  string vstrFilter, ref  string vstrOrderBy)
		{
			string strFunctionName = "adoGetRecordSetAsXML";
			DataSet rst =  null ;
			try
			{
					const ;
					;
					rst = adoGetRecordSet(vxmlDataNode, vxmlSchemaNode, ref vstrFilter, ref vstrOrderBy);
					if (rst !=  null )
					{
						
						adoConvertRecordSetToXML(vxmlSchemaNode, vxmlResponseNode, rst, IsComboLookUpRequired(vxmlDataNode));
					}
				}
			catch 
			{
			}
			
			
			rst =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		
		static public void  adoGetRecordSetAsXML( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode,  XmlNode vxmlResponseNode, ref  string vstrFilter)
		{
			string tempRefParam2 = "";
			adoGetRecordSetAsXML(vxmlDataNode, vxmlSchemaNode, vxmlResponseNode, vstrFilter, ref tempRefParam2);
		}
		
		static public void  adoGetRecordSetAsXML( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode,  XmlNode vxmlResponseNode)
		{
			string tempRefParam3 = "";
			string tempRefParam4 = "";
			adoGetRecordSetAsXML(vxmlDataNode, vxmlSchemaNode, vxmlResponseNode, ref tempRefParam3, ref tempRefParam4);
		}
		static public void  adoCloneBaseEntityRefs( XmlNode vxmlSchemaNode)
		{
			
			XmlNode xmlBaseSchemaEntityNode =  null ;
			XmlNode xmlBaseSchemaNode =  null ;
			string strEntityRef = String.Empty;
			foreach (XmlNode xmlSchemaElement in vxmlSchemaNode.ChildNodes)
			{
				if ((xmlSchemaElement.Attributes.GetNamedItem("DATASRCE") ==  null ) && (xmlSchemaElement.Attributes.GetNamedItem("ENTITYREF") !=  null ))
				{
					strEntityRef = xmlSchemaElement.Attributes.GetNamedItem("ENTITYREF").InnerText;
					if (xmlBaseSchemaEntityNode ==  null )
					{
						xmlBaseSchemaEntityNode = adoGetSchema(strEntityRef);
					} else
					{
						if (xmlBaseSchemaEntityNode.Name != strEntityRef)
						{
							xmlBaseSchemaEntityNode = adoGetSchema(strEntityRef);
						}
					}
					if (xmlBaseSchemaEntityNode !=  null )
					{
						xmlBaseSchemaNode = xmlBaseSchemaEntityNode.SelectSingleNode(xmlSchemaElement.Name);
						if (xmlBaseSchemaNode !=  null )
						{
							foreach (XmlAttribute xmlAttrib in xmlBaseSchemaNode.Attributes)
							{
								if (! xmlAttrib.Name.StartsWith("KEY") && xmlSchemaElement.Attributes.GetNamedItem(xmlAttrib.Name) ==  null )
								{
									xmlSchemaElement.Attributes.SetNamedItem(xmlAttrib.CloneNode(true));
								}
							}
							xmlSchemaElement.Attributes.RemoveNamedItem("ENTITYREF");
							//                    vxmlSchemaNode.replaceChild _
							//'                        xmlBaseSchemaNode.cloneNode(False), _
							//'                        xmlSchemaElement
							
						}
					}
				}
			}
		}
		static public DataSet adoGetRecordSet( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode, ref  string vstrFilter, ref  string vstrOrderBy)
		{
			DataSet result =  null ;
			string strFunctionName = "adoGetRecordSet";
			XmlNode xmlSchemaNode =  null ;
			XmlAttribute xmlDataAttrib =  null ;
			SqlCommand cmd =  null ;
			SqlParameter param =  null ;
			try
			{
					
					const ;
					;
					;
					;
					;
					string strPattern, strSQL, strSQLWhere, strDataSource = String.Empty;
					int intLoop = 0;
					
					int intRetryCount, intRetryMax = 0;
					bool blnDbCmdOk = false;
					string strSQLNoLock = String.Empty; // RF BMIDS00935 (SYS4752)
					strDataSource = xmlAssistEx.xmlGetAttributeText(vxmlSchemaNode, "DATASRCE");
					if (strDataSource.Length == 0)
					{
						strDataSource = vxmlSchemaNode.Name;
					}
					//RF BMIDS00935 Start
					//SYS4752 - If SQL Server and SQLNOLOCK is specified in the schema then set the NOLOCK SQL hint.
					//This will stop SQL-Server issuing shared locks on the table/page/row/key/etc.
					if ((genumDbProvider == DBPROVIDER.omiga4DBPROVIDERSQLServer) && (xmlAssistEx.xmlGetAttributeText(vxmlSchemaNode, "SQLNOLOCK") == "TRUE"))
					{
						strSQLNoLock = " WITH (NOLOCK)";
					}
					//RF BMIDS00935 End
					intRetryMax = adoGetDbRetries();
					cmd = new SqlCommand();
					if (vxmlDataNode !=  null )
					{
						
						foreach (XmlAttribute xmlDataAttrib2 in vxmlDataNode.Attributes)
						{
							strPattern = xmlDataAttrib2.Name + "[@DATATYPE]";
							xmlSchemaNode = vxmlSchemaNode.SelectSingleNode(strPattern);
							if (xmlSchemaNode !=  null )
							{
								if (strSQLWhere.Length != 0)
								{
									strSQLWhere = strSQLWhere + " AND ";
								}
								strSQLWhere = strSQLWhere + xmlSchemaNode.Name + "=?";
								param = getParam(xmlSchemaNode, xmlDataAttrib2);
								cmd.Parameters.Add(param);
							}
						}
					}
					// used by comboAssist
					if (vstrFilter.Length > 0 && vstrFilter.ToUpper().StartsWith("SELECT"))
					{
						
						strSQL = vstrFilter;
					} else
					{
						
						if (vstrFilter.Length > 0)
						{
							if (strSQLWhere.Length != 0)
							{
								strSQLWhere = strSQLWhere + " AND ";
							}
							strSQLWhere = strSQLWhere + vstrFilter;
						}
						if (cmd.Parameters.Count != 0)
						{
							//RF BMIDS00935 Start
							//SYS4752 - allow schema to specify the SQL-Server (NOLOCK) hint.
							strSQL = "SELECT * FROM " + strDataSource + strSQLNoLock + " WHERE (" + strSQLWhere + ")";
							//RF BMIDS00935 End
						} else
						{
							//RF BMIDS00935 Start
							//SYS4752 - allow schema to specify the SQL-Server (NOLOCK) hint.
							strSQL = "SELECT * FROM " + strDataSource + strSQLNoLock;
							//RF BMIDS00935 End
							if (strSQLWhere.Length != 0)
							{
								strSQL = strSQL + " WHERE (" + strSQLWhere + ")"; // JLD SYS1774
							}
						}
						if (vstrOrderBy.Length > 0)
						{
							strSQL = strSQL + " ORDER BY " + vstrOrderBy;
						}
					}
					Debug.WriteLine("adoGetRecordSet strSQL: " + strSQL);
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = strSQL;
					result = executeGetRecordSet(cmd);
					// retries never work !!!
					//On Error Resume Next
					//
					//    Do While blnDbCmdOk = False
					//
					//        Set adoGetRecordSet = executeGetRecordSet(cmd)
					//
					//        If Err.Number = 0 Then
					//
					//            blnDbCmdOk = True
					//
					//        Else
					//
					//            If IsRetryError() = False Then
					//
					//                On Error GoTo adoGetRecordSetExit
					//
					//            Else
					//
					//                intRetryCount = intRetryCount + 1
					//
					//                ' DEBUG
					//                App.LogEvent "adoGetRecordSet - retry [" & intRetryCount & "]: " & strSQL
					//
					//                If (intRetryCount = intRetryMax) Then
					//
					//                    On Error GoTo adoGetRecordSetExit
					//
					//                End If
					//
					//            End If
					//
					//        End If
					//
					//    Loop
					
					if (result ==  null )
					{
						Debug.WriteLine("adoGetRecordSet records retrieved: 0");
					} else
					{
						Debug.WriteLine("adoGetRecordSet records retrieved: " & result.Tables[0].Rows.Count);
					}
				}
			catch 
			{
			}
			
			
			cmd =  null ;
			xmlSchemaNode =  null ;
			xmlDataAttrib =  null ;
			param =  null ;
			errAssistEx.errCheckError(strFunctionName);
			return result;
		}
		
		static public DataSet adoGetRecordSet( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode, ref  string vstrFilter)
		{
			string tempRefParam5 = "";
			return adoGetRecordSet(vxmlDataNode, vxmlSchemaNode, vstrFilter, ref tempRefParam5);
		}
		
		static public DataSet adoGetRecordSet( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode)
		{
			string tempRefParam6 = "";
			string tempRefParam7 = "";
			return adoGetRecordSet(vxmlDataNode, vxmlSchemaNode, ref tempRefParam6, ref tempRefParam7);
		}
		static public void  adoConvertRecordSetToXML( XmlNode vxmlSchemaNode,  XmlNode vxmlResponseNode,  DataSet vrst,  bool vblnDoComboLookUp)
		{
			XmlElement xmlElem =  null ;
			ADODB.Field fld =  null ;
			string strNodeName = String.Empty;
			
			if (vxmlSchemaNode.Attributes.GetNamedItem("OUTNAME") !=  null )
			{
				strNodeName = vxmlSchemaNode.Attributes.GetNamedItem("OUTNAME").InnerText;
			} else
			{
				strNodeName = vxmlSchemaNode.Name;
			}
			foreach (DataRow iteration_row in vrst.Tables[0].Rows)
			{
				if (vxmlResponseNode.Name == strNodeName)
				{
					xmlElem = (XmlElement) vxmlResponseNode;
				} else
				{
					xmlElem = vxmlResponseNode.OwnerDocument.CreateElement(strNodeName);
				}
				foreach (XmlNode xmlThisSchemaNode in vxmlSchemaNode.ChildNodes)
				{
					fld =  null ;
					if (xmlAssistEx.xmlGetAttributeText(vxmlSchemaNode, "ENTITYTYPE") == "PROCEDURE")
					{
						if (xmlAssistEx.xmlGetAttributeText(xmlThisSchemaNode, "PARAMMODE") != "IN")
						{
							fld = iteration_row.Item[xmlThisSchemaNode.Name];
						}
					} else
					{
						fld = iteration_row.Item[xmlThisSchemaNode.Name];
					}
					//UPGRADE_WARNING:Use of Null/IsNull() detected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="2EED02CB-5C0E-4DC1-AE94-4FAA3A30F51A"'
					if (fld !=  null  && ! Convert.IsDBNull(fld) && ! Convert.IsDBNull(fld))
					{
						FieldToXml(fld, xmlElem, xmlThisSchemaNode, vblnDoComboLookUp);
					}
				}
				if (xmlElem.Attributes.Count > 0)
				{
					vxmlResponseNode.AppendChild((XmlNode) xmlElem);
				}
				
			}
		}
		static public DataSet executeGetRecordSet( SqlCommand cmd)
		{
			DataSet result =  null ;
			string strFunctionName = "executeGetRecordSet";
			SqlConnection conn =  null ;
			DataSet rst =  null ;
			try
			{
					
					const ;
					;
					;
					conn = new SqlConnection();
					rst = new DataSet();
					conn.ConnectionString = adoGetDbConnectString();
					conn.Open("", "", "", 0);
					cmd.Connection = conn;
					//UPGRADE_ISSUE:ADODB.Recordset property rst.CursorLocation was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
					//rst.cursorLocation = ADODB.CursorLocationEnum.adUseClient;
					//UPGRADE_ISSUE:ADODB.Recordset property rst.CursorType was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
					//rst.CursorType = ADODB.CursorTypeEnum.adOpenStatic;
					//UPGRADE_ISSUE:ADODB.Recordset property rst.LockType was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
					//rst.LockType = ADODB.LockTypeEnum.adLockReadOnly;
					//UPGRADE_ISSUE:ADODB.Recordset method rst.Open was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
					rst.Open(cmd);
					//SG 18/06/02 SYS4889
					//adoGetValidRecordset rst
					// disconnect RecordSet
					//UPGRADE_ISSUE:ADODB.Recordset property rst.ActiveConnection was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
					//rst.ActiveConnection =  null ;
					conn.Close();
					if (rst.Tables[0].Rows.Count != 0)
					{
						//UPGRADE_ISSUE:ADODB.Recordset method rst.MoveFirst was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
						rst.MoveFirst();
						result = rst;
					}
				}
			catch 
			{
			}
			
			
			rst =  null ;
			cmd =  null ;
			conn =  null ;
			errAssistEx.errCheckError(strFunctionName);
			return result;
		}
		static private long executeSQLCommand( SqlCommand cmd)
		{
			long result = 0;
			string strFunctionName = "executeSQLCommand";
			try
			{
					
					const ;
					
					long lngRecordsAffected = 0;
					SqlConnection conn =  null ;
					conn = new SqlConnection();
					conn.ConnectionString = adoGetDbConnectString();
					conn.Open("", "", "", 0);
					cmd.Connection = conn;
					cmd.CommandType = ADODB.ExecuteOptionEnum.adExecuteNoRecords;
					lngRecordsAffected = cmd.ExecuteNonQuery();
					conn.Close();
					cmd =  null ;
					conn =  null ;
					result = lngRecordsAffected;
				}
			catch 
			{
			}
			
			
			
			errAssistEx.errCheckError(strFunctionName);
			return result;
		}
		static public void  adoAddParam( XmlNode vxmlSchemaNode,  XmlAttribute vxmlAttrib,  SqlCommand vcmd)
		{
			SqlParameter param = getParam(vxmlSchemaNode, vxmlAttrib);
			vcmd.Parameters.Add(param);
		}
		static private SqlParameter getParam( XmlNode vxmlSchemaNode,  XmlAttribute vxmlAttrib,  bool blnIsCreate)
		{
			string strDataValue = String.Empty;
			SqlParameter param = new SqlParameter();
			
			string strDataType = vxmlSchemaNode.Attributes.GetNamedItem("DATATYPE").InnerText;
			switch(strDataType)
			{
				case "STRING" : 
					param.Type = DbType.String; 
					param.Size = vxmlAttrib.InnerText.Length; 
					break;
				case "GUID" : 
					param.Type = DbType.Binary; 
					param.Size = 16; 
					break;
				case "SHORT" : case "BOOLEAN" : case "COMBO" : case "LONG" : 
					param.Type = DbType.Int32; 
					break;
				case "DOUBLE" : case "CURRENCY" : 
					param.Type = DbType.Double; 
					break;
				case "DATE" : case "DATETIME" : 
					param.Type = DbType.DateTime; 
					break;
			}
			param.Direction = ParameterDirection.Input;
			//UPGRADE_WARNING:Use of Null/IsNull() detected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="2EED02CB-5C0E-4DC1-AE94-4FAA3A30F51A"'
			param.Value = DBNull.Value;
			if (vxmlAttrib !=  null  && vxmlAttrib.InnerText.Length > 0)
			{
				if (strDataType != "GUID")
				{
					param.Value = vxmlAttrib.InnerText;
				} else
				{
					param.Value = GuidStringToByteArray(vxmlAttrib.InnerText);
				}
			}
			return param;
		}
		
		static private SqlParameter getParam( XmlNode vxmlSchemaNode,  XmlAttribute vxmlAttrib)
		{
			return getParam(vxmlSchemaNode, vxmlAttrib, false);
		}
		static private void  GetGeneratedKey( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode)
		{
			XmlAttribute xmlAttrib =  null ;
			string strGuid = String.Empty;
			string strDataType = xmlAssistEx.xmlGetAttributeText(vxmlSchemaNode, "DATATYPE");
			switch(strDataType)
			{
				case "GUID" : 
					 
					xmlAttrib = vxmlDataNode.OwnerDocument.CreateAttribute(vxmlSchemaNode.Name); 
					xmlAttrib.Value = guidAssistEx.CreateGUID(); 
					vxmlDataNode.Attributes.SetNamedItem((XmlNode) xmlAttrib); 
					xmlAttrib =  null ; 
					break;
				case "SHORT" : 
					 
					xmlAttrib = vxmlDataNode.OwnerDocument.CreateAttribute(vxmlSchemaNode.Name); 
					xmlAttrib.Value = GetNextKeySequence(vxmlDataNode, vxmlSchemaNode, vxmlSchemaNode.ParentNode); 
					vxmlDataNode.Attributes.SetNamedItem((XmlNode) xmlAttrib); 
					xmlAttrib =  null ; 
					break;
			}
		}
		static private int GetNextKeySequence( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode,  XmlNode vxmlSchemaParentNode)
		{
			int result = 0;
			XmlNode xmlNode =  null ;
			SqlCommand cmd =  null ;
			DataSet rst =  null ;
			SqlParameter param =  null ;
			try
			{
					
					;
					;
					;
					;
					string strSequenceFieldName = String.Empty;
					string strPattern, strSQL, strSQLWhere, strDataSource = String.Empty;
					int intThisSequence = 0;
					
					bool blnDbCmdOk = false;
					string strSQLNoLock = String.Empty; // RF BMIDS00935 (SYS4572)
					strDataSource = xmlAssistEx.xmlGetAttributeText(vxmlSchemaParentNode, "DATASRCE");
					if (strDataSource.Length == 0)
					{
						strDataSource = vxmlSchemaParentNode.Name;
					}
					strSequenceFieldName = vxmlSchemaNode.Name;
					//RF BMIDS00935 Start
					//SYS4752 - If SQL Server and SQLNOLOCK is specified in the schema then set the NOLOCK SQL hint.
					//This will stop SQL-Server issuing shared locks on the table/page/row/key/etc.
					if ((genumDbProvider == DBPROVIDER.omiga4DBPROVIDERSQLServer) && (xmlAssistEx.xmlGetAttributeText(vxmlSchemaNode, "SQLNOLOCK") == "TRUE"))
					{
						strSQLNoLock = " WITH (NOLOCK)";
					}
					//RF BMIDS00935 End
					cmd = new SqlCommand();
					foreach (XmlNode xmlNode2 in vxmlSchemaParentNode.ChildNodes)
					{
						
						if (xmlNode2.Attributes.GetNamedItem("KEYTYPE") !=  null  && xmlNode2.Attributes.GetNamedItem("KEYSOURCE") ==  null  && vxmlDataNode.Attributes.GetNamedItem(xmlNode2.Name) !=  null )
						{
							
							
							if (strSQLWhere.Length != 0)
							{
								strSQLWhere = strSQLWhere + " AND ";
							}
							strSQLWhere = strSQLWhere + xmlNode2.Name + "=?";
							param = getParam(xmlNode2, (XmlAttribute) vxmlDataNode.Attributes.GetNamedItem(xmlNode2.Name));
							cmd.Parameters.Add(param);
						}
					}
					xmlNode =  null ;
					//RF BMIDS00935 Start
					//SYS4752 - Allow schema to specify the SQL-Server (NOLOCK) hint.
					strSQL = "SELECT MAX(" + strSequenceFieldName + ") FROM " + strDataSource + strSQLNoLock + " WHERE (" + strSQLWhere + ")";
					//RF BMIDS00935 End
					Debug.WriteLine("adoAssist.GetNextKeySequence strSQL: " + strSQL);
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = strSQL;
					rst = executeGetRecordSet(cmd);
					if (rst !=  null )
					{
						//UPGRADE_ISSUE:ADODB.Recordset method rst.MoveFirst was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
						rst.MoveFirst();
						//UPGRADE_WARNING:Change the default 0 index in the Rows property with the correct one. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="00000000-0000-0000-0000-000000000000"'
						if (! rst.Tables[0].Rows[0].IsNull(0))
						{
							//UPGRADE_WARNING:Change the default 0 index in the Rows property with the correct one. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="00000000-0000-0000-0000-000000000000"'
							intThisSequence = (int) rst.Tables[0].Rows[0][0];
						}
					}
					result = intThisSequence + 1;
					Information.Err().Clear();
				}
			catch 
			{
			}
			
			rst =  null ;
			cmd =  null ;
			xmlNode =  null ;
			param =  null ;
			if (Information.Err().Number != 0)
			{
				throw new System.Exception(Information.Err().Number.ToString() + ", " + Information.Err().Source + ", " + Information.Err().Description + ", " +  null  + ", " +  null );
			}
			return result;
		}
		static public string adoGuidToString( byte[] bytArray)
		{
			StringBuilder strGuid = new StringBuilder();
			for (int i = 0; i <= 15; i++ )
			{
				strGuid.Append(Strings.Right((bytArray[i] + 0x100f).ToString("X"), 2));
			}
			return strGuid.ToString();
		}
		static private string adoDateToString( System.DateTime vvarDate)
		{
			
			return Strings.Right((DateAndTime.DatePart("d", vvarDate, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1) + 100).ToString(), 2) + "/" + Strings.Right((DateAndTime.DatePart("m", vvarDate, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1) + 100).ToString(), 2) + "/" + Strings.Right(DateAndTime.DatePart("yyyy", vvarDate, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1).ToString(), 4);
		}
		static private string adoDateTimeToString( System.DateTime vvarDate)
		{
			
			return adoDateToString(vvarDate) + " " + Strings.Right((DateAndTime.DatePart("h", vvarDate, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1) + 100).ToString(), 2) + ":" + Strings.Right((DateAndTime.DatePart("n", vvarDate, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1) + 100).ToString(), 2) + ":" + Strings.Right((DateAndTime.DatePart("s", vvarDate, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1) + 100).ToString(), 2);
		}
		static private void  FieldToXml( ADODB.Field vfld,  XmlElement vxmlOutElem,  XmlNode vxmlSchemaNode,  bool vblnDoComboLookUp)
		{
			//Dim xmlAttrib As IXMLDOMAttribute
			string strFormatMask, strComboGroup, strElementValue, strComboValue, strFormatted = String.Empty;
			
			switch(vxmlSchemaNode.Attributes.GetNamedItem("DATATYPE").InnerText)
			{
				case "GUID" : 
					vxmlOutElem.SetAttribute(vxmlSchemaNode.Name, adoGuidToString((byte[]) vfld)); 
					break;
				case "CURRENCY" : 
					 
					strFormatted = VB6.Format(vfld, "0.0000000", FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1); 
					strFormatted = strFormatted.Substring(0, Math.Min(strFormatted.Length, (strFormatted.IndexOf('.') + 1) + 2)); 
					vxmlOutElem.SetAttribute(vxmlSchemaNode.Name, strFormatted); 
					break;
				case "DOUBLE" : 
					 
					strFormatMask = String.Empty; 
					if (vxmlSchemaNode.Attributes.GetNamedItem("FORMATMASK") !=  null )
					{
						strFormatMask = vxmlSchemaNode.Attributes.GetNamedItem("FORMATMASK").InnerText;
					} 
					if (strFormatMask.Length != 0)
					{
						
						vxmlOutElem.SetAttribute(vxmlSchemaNode.Name + "_RAW", vfld);
						vxmlOutElem.SetAttribute(vxmlSchemaNode.Name, VB6.Format(vfld, strFormatMask, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1));
					} else
					{
						
						vxmlOutElem.SetAttribute(vxmlSchemaNode.Name, vfld);
					} 
					break;
				case "COMBO" : 
					vxmlOutElem.SetAttribute(vxmlSchemaNode.Name, vfld); 
					if (vblnDoComboLookUp && vxmlSchemaNode.Attributes.GetNamedItem("COMBOGROUP") !=  null )
					{
						strComboGroup = vxmlSchemaNode.Attributes.GetNamedItem("COMBOGROUP").InnerText;
						strComboValue = comboAssistEx.GetComboText(strComboGroup, (int) vfld);
						vxmlOutElem.SetAttribute(vxmlSchemaNode.Name + "_TEXT", strComboValue);
					} 
					break;
				case "DATE" : 
					vxmlOutElem.SetAttribute(vxmlSchemaNode.Name, adoDateToString((System.DateTime) vfld)); 
					break;
				case "DATETIME" : 
					vxmlOutElem.SetAttribute(vxmlSchemaNode.Name, adoDateTimeToString((System.DateTime) vfld)); 
					break;
				default:
					vxmlOutElem.SetAttribute(vxmlSchemaNode.Name, vfld); 
					break;
			}
		}
		static public long adoDeleteFromNode( XmlNode vxmlRequestNode,  string vstrSchemaName,  bool blnOnlySingleRecord)
		{
			long result = 0;
			string strFunctionName = "adoDeleteFromNode";
			XmlNode xmlSchemaNode =  null ;
			try
			{
					
					const ;
					long lngRecordsAffected = 0;
					;
					xmlSchemaNode = adoGetSchema(vstrSchemaName);
					lngRecordsAffected = adoDelete(vxmlRequestNode, xmlSchemaNode, blnOnlySingleRecord);
					result = lngRecordsAffected;
				}
			catch 
			{
			}
			
			
			xmlSchemaNode =  null ;
			errAssistEx.errCheckError(strFunctionName);
			return result;
		}
		
		static public long adoDeleteFromNode( XmlNode vxmlRequestNode,  string vstrSchemaName)
		{
			return adoDeleteFromNode(vxmlRequestNode, vstrSchemaName, true);
		}
		static public long adoDelete( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode,  bool blnOnlySingleRecord)
		{
			long result = 0;
			string strFunctionName = "adoDelete";
			XmlNode xmlSchemaNode =  null ;
			XmlAttribute xmlDataAttrib =  null ;
			SqlCommand cmd =  null ;
			SqlParameter param =  null ;
			try
			{
					
					const ;
					string strDataSource = String.Empty;
					string strSQL = String.Empty;
					string strSQLWhere = String.Empty;
					;
					XmlNodeList xmlSchemaNodeList =  null ;
					;
					;
					;
					long lngRecordsAffected = 0;
					bool blnDbCmdOk = false;
					int intRetryMax = 0;
					int intRetryCount = 0;
					cmd = new SqlCommand();
					//Get the table name from the schema
					strDataSource = xmlAssistEx.xmlGetAttributeText(vxmlSchemaNode, "DATASRCE");
					if (strDataSource.Trim().Length == 0)
					{
						errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeXMLMissingAttribute, "DATASRCE");
					}
					//If specified that only a single record may be deleted, ensure that
					//the whole primary key has been provided. Otherwise raise an error.
					if (blnOnlySingleRecord)
					{
						xmlSchemaNodeList = vxmlSchemaNode.SelectNodes("*[@KEYTYPE='PRIMARY']");
						foreach (xmlSchemaNode in xmlSchemaNodeList)
						{
							xmlDataAttrib = (XmlAttribute) vxmlDataNode.Attributes.GetNamedItem(xmlSchemaNode.Name);
							if (xmlDataAttrib !=  null )
							{
								if (((string) xmlDataAttrib.Value) == "")
								{
									errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeXMLInvalidAttributeValue, xmlSchemaNode.Name);
								}
							} else
							{
								errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeXMLMissingAttribute, xmlSchemaNode.Name);
							}
						}
					}
					//Get each condition in the WHERE clause
					foreach (XmlNode xmlSchemaNode2 in vxmlSchemaNode.ChildNodes)
					{
						xmlDataAttrib = (XmlAttribute) vxmlDataNode.Attributes.GetNamedItem(xmlSchemaNode2.Name);
						if (xmlDataAttrib !=  null  && ((string) xmlDataAttrib.Value) != "")
						{
							if (strSQLWhere.Length != 0)
							{
								strSQLWhere = strSQLWhere + " AND ";
							}
							strSQLWhere = strSQLWhere + xmlSchemaNode2.Name + "=?";
							param = getParam(xmlSchemaNode2, xmlDataAttrib);
							cmd.Parameters.Add(param);
						}
					}
					xmlSchemaNode =  null ;
					//Run the SQL command
					if (strSQLWhere.Length > 0)
					{
						strSQL = "DELETE FROM " + strDataSource + " WHERE " + strSQLWhere;
						Debug.WriteLine("adoDelete strSQL: " + strSQL);
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = strSQL;
						//        intRetryMax = adoGetDbRetries
						//        On Error Resume Next
						//        Do While blnDbCmdOk = False
						lngRecordsAffected = executeSQLCommand(cmd);
						//            If Err.Number = 0 Then
						//                blnDbCmdOk = True
						//            Else
						//                If IsRetryError() = False Then
						//                    On Error GoTo adoDeleteExit
						//                Else
						//                    intRetryCount = intRetryCount + 1
						//                    ' DEBUG
						//                    App.LogEvent "adoDelete - retry [" & intRetryCount & "]: " & strSQL
						//                    If (intRetryCount = intRetryMax) Then
						//                        On Error GoTo adoDeleteExit
						//                    End If
						//                End If
						//            End If
						//        Loop
					}
					Debug.WriteLine("adoDelete records deleted: " + lngRecordsAffected.ToString());
					result = lngRecordsAffected;
				}
			catch 
			{
			}
			
			cmd =  null ;
			param =  null ;
			xmlSchemaNode =  null ;
			xmlDataAttrib =  null ;
			param =  null ;
			errAssistEx.errCheckError(strFunctionName);
			return result;
		}
		
		static public long adoDelete( XmlNode vxmlDataNode,  XmlNode vxmlSchemaNode)
		{
			return adoDelete(vxmlDataNode, vxmlSchemaNode, true);
		}
		static public void  adoPopulateChildKeys( XmlNode vxmlSrceNode,  XmlNode vxmlDestNode)
		{
			const string strFunctionName = "adoPopulateChildKeys";
			XmlNode xmlSrceSchemaNode =  null ;
			XmlNode xmlDestSchemaNode =  null ;
			XmlNodeList xmlPrimaryKeyNodeList =  null ;
			try
			{
					;
					;
					;
					xmlSrceSchemaNode = adoGetSchema(vxmlSrceNode.Name);
					if (xmlSrceSchemaNode ==  null )
					{
						return;
					}
					xmlDestSchemaNode = adoGetSchema(vxmlDestNode.Name);
					if (xmlDestSchemaNode ==  null )
					{
						xmlSrceSchemaNode =  null ;
						return;
					}
					xmlPrimaryKeyNodeList = xmlDestSchemaNode.SelectNodes("*[@KEYTYPE='PRIMARY']");
					foreach (XmlNode xmlSrceSchemaNode2 in xmlPrimaryKeyNodeList)
					{
						xmlAssistEx.xmlCopyAttribute(vxmlSrceNode, vxmlDestNode, xmlSrceSchemaNode2.Name);
					}
				}
			catch 
			{
			}
			
			
			xmlSrceSchemaNode =  null ;
			xmlDestSchemaNode =  null ;
			xmlPrimaryKeyNodeList =  null ;
			errAssistEx.errCheckError(strFunctionName);
		}
		static public void  adoBuildDbConnectionString()
		{
			On Error GoTo BuildDbConnectionStringVbErr;
			IWshRuntimeLibrary.WshShell objWshShell =  null ;
			string strRegSection, strConnection, strProvider, strRetries = String.Empty;
			string strUserId = String.Empty;
			string strPassword = String.Empty;
			long lngErrNo = 0;
			string strSource = String.Empty;
			string strDescription = String.Empty;
			objWshShell = (WshShell) Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
			strRegSection = "HKLM\\SOFTWARE\\" + gstrAppName + "\\" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + "\\" + gstrREGISTRY_SECTION + "\\";
			//UPGRADE_TODO:Try / Catch is not supported with On Error GoTo statements in the same method. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="vbup1064"'
			try
			{
					
					//UPGRADE_WARNING:Couldn't resolve default property of object objWshShell.RegRead. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					strProvider = (string) objWshShell.RegRead(strRegSection + gstrPROVIDER_KEY);
				}
			catch 
			{
			}
			On Error GoTo BuildDbConnectionStringVbErr;
			
			if (strProvider.Length == 0)
			{
				strRegSection = "HKLM\\SOFTWARE\\" + gstrAppName + "\\" + gstrREGISTRY_SECTION + "\\";
				//UPGRADE_WARNING:Couldn't resolve default property of object objWshShell.RegRead. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				strProvider = (string) objWshShell.RegRead(strRegSection + gstrPROVIDER_KEY);
			}
			genumDbProvider = DBPROVIDER.omiga4DBPROVIDERUnknown;
			//If strProvider = "MSDAORA" Then
			//SDS LIVE00009659  22/01/2004 STARTS
			//Support for both MS and Oracle OLEDB Drivers
			if (strProvider == "MSDAORA" || strProvider == "ORAOLEDB.ORACLE")
			{
				switch(strProvider)
				{
					case "MSDAORA" : 
						genumDbProvider = DBPROVIDER.omiga4DBPROVIDERMSOracle; 
						break;
					case "ORAOLEDB.ORACLE" : 
						genumDbProvider = DBPROVIDER.omiga4DBPROVIDEROracle; 
						break;
				}
				//genumDbProvider = omiga4DBPROVIDEROracle
				//UPGRADE_WARNING:Couldn't resolve default property of object objWshShell.RegRead. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				strConnection = "Provider=" + strProvider + ";Data Source=" + (string) objWshShell.RegRead(strRegSection + gstrDATA_SOURCE_KEY) + ";" + "User ID=" + (string) objWshShell.RegRead(strRegSection + gstrUID_KEY) + ";" + "Password=" + (string) objWshShell.RegRead(strRegSection + gstrPASSWORD_KEY) + ";";
				//SDS LIVE00009659  22/01/2004 ENDS
			} else if (strProvider == "SQLOLEDB") { 
				genumDbProvider = DBPROVIDER.omiga4DBPROVIDERSQLServer;
				// PSC 17/10/01 SYS2815 - Start
				strUserId = "";
				strPassword = "";
				On Error Resume Next;
				
				//UPGRADE_WARNING:Couldn't resolve default property of object objWshShell.RegRead. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				strUserId = (string) objWshShell.RegRead(strRegSection + gstrUID_KEY);
				lngErrNo = Information.Err().Number;
				strSource = Information.Err().Source;
				strDescription = Information.Err().Description;
				
				On Error GoTo BuildDbConnectionStringVbErr;
				if (Information.Err().Number != glngENTRYNOTFOUND && Information.Err().Number != 0)
				{
					throw new System.Exception(lngErrNo.ToString() + ", " + strSource + ", " + strDescription + ", " +  null  + ", " +  null );
				}
				On Error Resume Next;
				
				//UPGRADE_WARNING:Couldn't resolve default property of object objWshShell.RegRead. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				strPassword = (string) objWshShell.RegRead(strRegSection + gstrPASSWORD_KEY);
				lngErrNo = Information.Err().Number;
				strSource = Information.Err().Source;
				strDescription = Information.Err().Description;
				
				On Error GoTo BuildDbConnectionStringVbErr;
				if (Information.Err().Number != glngENTRYNOTFOUND && Information.Err().Number != 0)
				{
					throw new System.Exception(lngErrNo.ToString() + ", " + strSource + ", " + strDescription + ", " +  null  + ", " +  null );
				}
				//UPGRADE_WARNING:Couldn't resolve default property of object objWshShell.RegRead. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				strConnection = "Provider=SQLOLEDB;Server=" + objWshShell.RegRead(strRegSection + gstrSERVER_KEY) + ";" + "database=" + (string) objWshShell.RegRead(strRegSection + gstrDATABASE_KEY) + ";";
				// If User Id is present use SQL Server Authentication else
				// use integrated security
				if (strUserId.Length > 0)
				{
					strConnection = strConnection + "UID=" + strUserId + ";" + "pwd=" + strPassword + ";";
				} else
				{
					strConnection = strConnection + "Integrated Security=SSPI;Persist Security Info=False";
				}
				// PSC 17/10/01 SYS2815 - End
			}
			
			gstrDbConnectionString = strConnection;
			//UPGRADE_WARNING:Couldn't resolve default property of object objWshShell.RegRead. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			strRetries = (string) objWshShell.RegRead(strRegSection + gstrRETRIES_KEY);
			if (strRetries.Length > 0)
			{
				gintDbRetries = Int32.Parse(strRetries);
			}
			objWshShell =  null ;
			Debug.WriteLine(strConnection);
			return;
BuildDbConnectionStringVbErr: 
			
			objWshShell =  null ;
			throw new System.Exception(Information.Err().Number.ToString() + ", " + Information.Err().Source + ", " + Information.Err().Description + ", " +  null  + ", " +  null );
		}
		static public string adoGetDbConnectString()
		{
			return gstrDbConnectionString;
		}
		static public int adoGetDbRetries()
		{
			return gintDbRetries;
		}
		static public DBPROVIDER adoGetDbProvider()
		{
			return genumDbProvider;
		}
		static public void  adoLoadSchema()
		{
			
			// pick up XML map from "...\Omiga 4\XML" directory
			// Only do the subsitution once to change DLL -> XML
			string strFileSpec = Path.GetDirectoryName(Application.ExecutablePath) + "\\" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ".xml";
			strFileSpec = Strings.Replace(strFileSpec, "DLL", "XML", 1, 1, CompareMethod.Text);
			gxmldocSchemas = new MSXML2.FreeThreadedDOMDocument40();
			gxmldocSchemas.async = false;
			gxmldocSchemas.setProperty("NewParser", true);
			gxmldocSchemas.validateOnParse = false;
			gxmldocSchemas.load(strFileSpec);
		}
		static public XmlNode adoGetSchema( string vstrSchemaName)
		{
			
			string strPattern = "//" + vstrSchemaName + "[@DATASRCE]";
			return gxmldocSchemas.selectSingleNode(strPattern);
		}
		static private long GetErrorNumber( string strErrDesc)
		{
			const string cstrFunctionName = "GetErrorNumber";
			try
			{
					string strErr = String.Empty;
					if (genumDbProvider == DBPROVIDER.omiga4DBPROVIDEROracle || genumDbProvider == DBPROVIDER.omiga4DBPROVIDERMSOracle)
					{
						// oracle errors have format "ORA-nnnnn"
						if (strErrDesc.Length > 10)
						{
							strErr = strErrDesc.Substring(4, 5);
						} else
						{
							// "Cannot interpret database error"
							errAssistEx.errThrowError(cstrFunctionName, 108);
						}
					} else if (genumDbProvider == DBPROVIDER.omiga4DBPROVIDERSQLServer) {  // SQL Server
						errAssistEx.errThrowError(cstrFunctionName, (int) OMIGAERROR.oeNotImplemented);
						
					} else if (genumDbProvider == DBPROVIDER.omiga4DBPROVIDERUnknown) { 
						errAssistEx.errThrowError(cstrFunctionName, (int) OMIGAERROR.oeNotImplemented);
					}
					return Int64.Parse(strErr);
				}
			catch (System.Exception excep)
			{
				
				throw new System.Exception(Information.Err().Number.ToString() + ", " + cstrFunctionName + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return 0;
		}
		static public OMIGAERROR adoGetOmigaNumberForDatabaseError( string strErrDesc)
		{
			//-----------------------------------------------------------------------------------
			//Description : Find the omiga equivalent number for a database error. This is used
			//              to trap specific errors. Add to the list below, if you want trap a
			//              a new error
			//Pass        : strErrDesc : Description of the Error Message (from database )
			//------------------------------------------------------------------------------------
			const string cstrFunctioName = "adoGetOmigaNumberForDatabaseError";
			try
			{
					OMIGAERROR lngOmigaErrorNo;
					long lngErrNo = 0;
					lngErrNo = GetErrorNumber(strErrDesc);
					//'SDS LIVE00009659  22/01/2004 Support for both MS and Oracle OLEDB Drivers
					if (genumDbProvider == DBPROVIDER.omiga4DBPROVIDEROracle || genumDbProvider == DBPROVIDER.omiga4DBPROVIDERMSOracle)
					{
						switch(lngErrNo)
						{
							case 1 : 
								lngOmigaErrorNo = OMIGAERROR.oeDuplicateKey; 
								break;
							case 2292 : 
								lngOmigaErrorNo = OMIGAERROR.oeChildRecordsFound; 
								break;
							default:
								lngOmigaErrorNo = OMIGAERROR.oeUnspecifiedError; 
								break;
						}
					} else
					{
						errAssistEx.errThrowError(cstrFunctioName, (int) OMIGAERROR.oeNotImplemented, "Error trapping for this database engine");
					}
					return lngOmigaErrorNo;
				}
			catch (System.Exception excep)
			{
				
				
				throw new System.Exception(Information.Err().Number.ToString() + ", " + cstrFunctioName + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return  null ;
		}
		static public bool adoGetValidRecordset(ref  DataSet vrstRecordSet,  int nRecordSet)
		{
			const string cstrFunctionName = "adoGetValidRecordset";
			try
			{
					bool bSuccess = false;
					bSuccess = false;
					//UPGRADE_ISSUE:ADODB.Recordset property vrstRecordSet.BOF was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
					//UPGRADE_ISSUE:ADODB.Recordset property vrstRecordSet.State was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
					if (genumDbProvider == DBPROVIDER.omiga4DBPROVIDERSQLServer)
					{
						do 
						{
							//UPGRADE_ISSUE:ADODB.Recordset property vrstRecordSet.BOF was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
							//UPGRADE_ISSUE:ADODB.Recordset property vrstRecordSet.State was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
							if (vrstRecordSet.State != ConnectionState.Closed && ! (vrstRecordSet.BOF && vrstRecordSet.Tables[0].Rows.Count == 0))
							{
								if (nRecordSet > 0)
								{nRecordSet-- ;
								}
								bSuccess = true;
								if (nRecordSet == 0)
								{
									continue;
								}
							}
							//UPGRADE_ISSUE:ADODB.Recordset method vrstRecordSet.NextRecordset was not upgraded. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
							vrstRecordSet = (DataSet) vrstRecordSet.NextRecordset;
						}
						while(vrstRecordSet !=  null );
					} else if (vrstRecordSet !=  null  && vrstRecordSet.State != ConnectionState.Closed && ! (vrstRecordSet.BOF && vrstRecordSet.Tables[0].Rows.Count == 0)) { 
						// Found an open recordset with records.
						bSuccess = true;
					}
					return bSuccess;
				}
			catch (System.Exception excep)
			{
				
				throw new System.Exception(Information.Err().Number.ToString() + ", " + cstrFunctionName + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return false;
		}
		
		static public bool adoGetValidRecordset(ref  DataSet vrstRecordSet)
		{
			return adoGetValidRecordset(vrstRecordSet, 1);
		}
		static private bool IsComboLookUpRequired( XmlNode vxmlRequestNode)
		{
			if (vxmlRequestNode.Attributes.GetNamedItem("_COMBOLOOKUP_") !=  null )
			{
				return xmlAssistEx.xmlGetAttributeAsBoolean(vxmlRequestNode, "_COMBOLOOKUP_");
			} else
			{
				if (vxmlRequestNode.OwnerDocument.FirstChild !=  null )
				{
					return xmlAssistEx.xmlGetAttributeAsBoolean(vxmlRequestNode.OwnerDocument.FirstChild, "_COMBOLOOKUP_");
				} else
				{
					return false;
				}
			}
		}
		static private string FormatGuid( string strSrcGuid,  GUIDSTYLE eGuidStyle)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Converts a guid string from one format to another.
			// pass:
			//   strSrcGuid  The guid string to be converted.
			//   eGuidStyle  The style of the return string.
			//               guidHyphen converts from "DA6DA163412311D4B5FA00105ABB1680" to
			//               "{63A16DDA-2341-D411-B5FA-00105ABB1680}" format.
			//               guidBinary converts from "{63A16DDA-2341-D411-B5FA-00105ABB1680}" to
			//               "DA6DA163412311D4B5FA00105ABB1680" format.
			//               guidLiteral converts from either guidBinary or guidHyphen format to
			//               a format that can be used as a literal input parameter for the
			//               database. This is the default to maintain backwards compatibility with
			//               Omiga 4 Phase 2.
			// return:       The converted guid string.
			// AS            05/03/01    First version
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					StringBuilder strTgtGuid = new StringBuilder();
					strTgtGuid.Append(String.Empty);
					int intIndex2 = 0;
					strFunctionName = "FormatGuid";
					// By default return string unchanged, i.e., if style is guidHyphen but the source string
					// is currently not in binary format, then it will be returned unchanged (perhaps it is
					// already in hyphenated format?).
					strTgtGuid = new StringBuilder(strSrcGuid);
					int intOffset = 0;
					switch(eGuidStyle)
					{
						case adoAssistEx.GUIDSTYLE.guidHyphen : 
							// Convert from "DA6DA163412311D4B5FA00105ABB1680" to "{63A16DDA-2341-D411-B5FA-00105ABB1680}" 
							Debug.Assert(strSrcGuid.Length == 32, ""); 
							if (strSrcGuid.Length == 32)
							{
								strTgtGuid = new StringBuilder("{");
								for (int intIndex1 = 0; intIndex1 <= 15; intIndex1++ )
								{
									intIndex2 = ConvertGuidIndex(intIndex1);
									strTgtGuid.Append(strSrcGuid.Substring((intIndex2 * 2) + 1 - 1, 2));
									if (intIndex1 == 3 || intIndex1 == 5 || intIndex1 == 7 || intIndex1 == 9)
									{
										strTgtGuid.Append("-");
									}
								}
								strTgtGuid.Append("}");
							} else
							{
								errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeInvalidParameter, "strSrcGuid length must be 32");
							} 
							break;
						case adoAssistEx.GUIDSTYLE.guidBinary : 
							// Convert from "{63A16DDA-2341-D411-B5FA-00105ABB1680}" to "DA6DA163412311D4B5FA00105ABB1680" 
							Debug.Assert(strSrcGuid.Length == 38, ""); 
							if (strSrcGuid.Length == 38)
							{
								strTgtGuid = new StringBuilder("");
								intOffset = 2;
								for (int intIndex1 = 0; intIndex1 <= 15; intIndex1++ )
								{
									intIndex2 = ConvertGuidIndex(intIndex1);
									strTgtGuid.Append(strSrcGuid.Substring((intIndex2 * 2) + intOffset - 1, 2));
									if (intIndex1 == 3 || intIndex1 == 5 || intIndex1 == 7 || intIndex1 == 9)
									{intOffset++ ;
									}
								}
							} else
							{
								errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeInvalidParameter, "strSrcGuid length must be 38");
							} 
							break;
						case adoAssistEx.GUIDSTYLE.guidLiteral : 
							// Convert guid into a format that can be used as a literal input parameter to the database. 
							// This assumes that the database type is raw for Oracle, or binary/varbinary for SQL Server. 
							if (strSrcGuid.Length == 38)
							{
								// Guid is in hyphenated format, e.g., "{63A16DDA-2341-D411-B5FA-00105ABB1680}",
								// so convert to binary format, e.g., "DA6DA163412311D4B5FA00105ABB1680".
								strSrcGuid = FormatGuid(strSrcGuid, GUIDSTYLE.guidBinary);
							} 
							Debug.Assert(strSrcGuid.Length == 32, ""); 
							if (strSrcGuid.Length == 32)
							{
								if (adoGetDbProvider() == DBPROVIDER.omiga4DBPROVIDERSQLServer)
								{
									// e.g., "0xDA6DA163412311D4B5FA00105ABB1680"
									strTgtGuid = new StringBuilder("0x" + strSrcGuid);
								} else if (adoGetDbProvider() == DBPROVIDER.omiga4DBPROVIDEROracle || adoGetDbProvider() == DBPROVIDER.omiga4DBPROVIDERMSOracle) {  // SDS LIVE00009659  22/01/2004 Support for both MS and Oracle OLEDB Drivers
									// e.g., "HEXTORAW('DA6DA163412311D4B5FA00105ABB1680')"
									strTgtGuid = new StringBuilder("HEXTORAW('" + strSrcGuid + "')");
								}
							} 
							break;
						default:
							Debug.Assert(0, ""); 
							errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeInvalidParameter, "strGuid length must be 32"); 
							break;
					}
					return strTgtGuid.ToString();
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return String.Empty;
		}
		
		static private string FormatGuid( string strSrcGuid)
		{
			return FormatGuid(strSrcGuid, GUIDSTYLE.guidLiteral);
		}
		static public byte[] GuidStringToByteArray( string strGuid)
		{
			// header ----------------------------------------------------------------------------------
			// description:      Converts a guid string into a byte array.
			// pass:
			//   strGuid         The guid string to be converted.
			//                   Can be in either binary format, e.g., "DA6DA163412311D4B5FA00105ABB1680",
			//                   or hyphenated format, e.g., "{63A16DDA-2341-D411-B5FA-00105ABB1680}".
			// return:           The byte array.
			// AS                05/03/01    First version
			//------------------------------------------------------------------------------------------
			try
			{
					string strFunctionName = String.Empty;
					strFunctionName = "GuidStringToByteArray";
					byte[] rbytGuid = new byte[16];
					if (strGuid.Length == 38)
					{
						// Convert from "{63A16DDA-2341-D411-B5FA-00105ABB1680}" to "DA6DA163412311D4B5FA00105ABB1680"
						strGuid = FormatGuid(strGuid, GUIDSTYLE.guidBinary);
					}
					if (strGuid.Length == 32)
					{
						// Convert from "DA6DA163412311D4B5FA00105ABB1680" to byte array.
						for (int intIndex = 0; intIndex <= rbytGuid.GetUpperBound(0); intIndex++ )
						{
							rbytGuid[intIndex] = Byte.Parse("&H" + strGuid.Substring((intIndex * 2) + 1 - 1, 2));
						}
					} else
					{
						Debug.Assert(0, "");
						errAssistEx.errThrowError(strFunctionName, (int) OMIGAERROR.oeInvalidParameter, "strGuid length must be 32");
					}
					return rbytGuid;
				}
			catch (System.Exception excep)
			{
				
				//   re-raise error for business object to interpret as appropriate
				throw new System.Exception(Information.Err().Number.ToString() + ", " + excep.Source + ", " + excep.Message + ", " +  null  + ", " +  null );
			}
			return  null ;
		}
		static private int ConvertGuidIndex( int intIndex1)
		{
			// header ----------------------------------------------------------------------------------
			// description:  Helper function for ByteArrayToGuidString and FormatGuid.
			// pass:
			// return:
			// AS            31/01/01    First version
			//------------------------------------------------------------------------------------------
			int intIndex2 = 0;
			switch(intIndex1)
			{
				case 0 : 
					intIndex2 = 3; 
					break;
				case 1 : 
					intIndex2 = 2; 
					break;
				case 2 : 
					intIndex2 = 1; 
					break;
				case 3 : 
					intIndex2 = 0; 
					break;
				case 4 : 
					intIndex2 = 5; 
					break;
				case 5 : 
					intIndex2 = 4; 
					break;
				case 6 : 
					intIndex2 = 7; 
					break;
				case 7 : 
					intIndex2 = 6; 
					break;
				default:
					intIndex2 = intIndex1; 
					break;
			}
			return intIndex2;
		}
	}
}