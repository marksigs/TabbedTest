using System.Xml; 

using System; 

using VB6 = Microsoft.VisualBasic.Compatibility.VB6.Support; 

namespace omToMSMQ
{
	class globalAssist
	{
	
		// DM    SYS3185 7/01/02 Added method to get a boolean value from a global parameter
		//SR     BBGRb74 25/01/2006 New method GetAllGlobalBandedParamValuesAsXml
		private enum GLOBALPARAMTYPE
		 {
			oegptString ,
			oegptAmount ,
			oegptMaximumAmount ,
			oegptPercentage ,
			oegptBoolean
		}
		private const string gstrMODULEPREFIX = "globalAssist.";
		// DM    SYS3185 7/01/02 Added method to get a boolean value from a global parameter
		static public bool GetGlobalParamBoolean( string vstrParamName)
		{
			bool result = false;
			bool varParamValue = false;
			if (GetGlobalParam(vstrParamName, globalAssist.GLOBALPARAMTYPE.oegptBoolean, (ref varParamValue).ToString()))
			{
				result = varParamValue;
			}
			return result;
		}
		// DM    SYS3185 7/01/02 Added method to get a boolean value from a global parameter
		static public bool GetMandatoryGlobalParamBoolean( string vstrParamName)
		{
			bool result = false;
			
			const string cstrFunctionName = "GetMandatoryGlobalParamBoolean";
			string varParamValue = String.Empty;
			if (GetGlobalParam(vstrParamName, globalAssist.GLOBALPARAMTYPE.oegptBoolean, ref varParamValue))
			{
				
				result = (varParamValue.ToLower().Equals("true")) ? true: ((varParamValue.ToLower().Equals("false")) ? false: Convert.ToBoolean(Double.Parse(varParamValue)));
			} else
			{
				
				errAssistEx.errThrowError(gstrMODULEPREFIX + cstrFunctionName, (int) OMIGAERROR.oeMissingParameter, vstrParamName);
			}
			return result;
		}
		static public string GetMandatoryGlobalParamString( string vstrParamName)
		{
			string result = String.Empty;
			
			const string cstrFunctionName = "GetMandatoryGlobalParamString";
			string varParamValue = String.Empty;
			if (GetGlobalParam(vstrParamName, globalAssist.GLOBALPARAMTYPE.oegptString, ref varParamValue))
			{
				
				result = varParamValue;
			} else
			{
				
				errAssistEx.errThrowError(gstrMODULEPREFIX + cstrFunctionName, (int) OMIGAERROR.oeMissingParameter, vstrParamName);
			}
			return result;
		}
		// APS SYS1920 Added new method
		static public long GetMandatoryGlobalParamAmount( string vstrParamName)
		{
			long result = 0;
			
			const string cstrFunctionName = "GetMandatoryGlobalParamAmount";
			string varParamValue = String.Empty;
			if (GetGlobalParam(vstrParamName, globalAssist.GLOBALPARAMTYPE.oegptAmount, ref varParamValue))
			{
				
				result = Int64.Parse(varParamValue);
			} else
			{
				
				errAssistEx.errThrowError(gstrMODULEPREFIX + cstrFunctionName, (int) OMIGAERROR.oeMissingParameter, vstrParamName);
			}
			return result;
		}
		static public string GetGlobalParamString( string vstrParamName)
		{
			string result = String.Empty;
			string varParamValue = String.Empty;
			if (GetGlobalParam(vstrParamName, globalAssist.GLOBALPARAMTYPE.oegptString, ref varParamValue))
			{
				result = varParamValue;
			}
			return result;
		}
		// APS SYS1920 Added new method
		static public long GetGlobalParamAmount( string vstrParamName)
		{
			long result = 0;
			string varParamValue = String.Empty;
			if (GetGlobalParam(vstrParamName, globalAssist.GLOBALPARAMTYPE.oegptAmount, ref varParamValue))
			{
				result = Int64.Parse(varParamValue);
			}
			return result;
		}
		static private bool GetGlobalParam( string vstrParamName,  GLOBALPARAMTYPE enumParamType, ref  string vvarParamValue)
		{
			bool result = false;
			const string cstrFunctionName = "GetGlobalParam";
			// create one FreeThreadedDOMDocument40 to contain schema, request & response
			MSXML2.FreeThreadedDOMDocument40 xmlDoc = new MSXML2.FreeThreadedDOMDocument40();
			// create BOGUS root node
			XmlElement xmlElem = xmlDoc.createElement("BOGUS");
			XmlNode xmlRootNode = xmlDoc.appendChild((XmlNode) xmlElem);
			// create schema for OM_GLOBALPARAM view
			xmlElem = xmlDoc.createElement("GLOBALPARAM");
			xmlElem.SetAttribute("ENTITYTYPE", "LOGICAL");
			xmlElem.SetAttribute("DATASRCE", "OM_GLOBALPARAM");
			XmlNode xmlSchemaNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("NAME");
			xmlElem.SetAttribute("DATATYPE", "STRING");
			xmlElem.SetAttribute("LENGTH", "30");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("GLOBALPARAMETERSTARTDATE");
			xmlElem.SetAttribute("DATATYPE", "DATE");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("STRING");
			xmlElem.SetAttribute("DATATYPE", "STRING");
			xmlElem.SetAttribute("LENGTH", "30");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("DESCRIPTION");
			xmlElem.SetAttribute("DATATYPE", "STRING");
			xmlElem.SetAttribute("LENGTH", "255");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("AMOUNT");
			xmlElem.SetAttribute("DATATYPE", "DOUBLE");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("AMOUNT");
			xmlElem.SetAttribute("DATATYPE", "DOUBLE");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("MAXIMUMAMOUNT");
			xmlElem.SetAttribute("DATATYPE", "DOUBLE");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("PERCENTAGE");
			xmlElem.SetAttribute("DATATYPE", "DOUBLE");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("BOOLEAN");
			xmlElem.SetAttribute("DATATYPE", "BOOLEAN");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			
			// create REQUEST details
			xmlElem = xmlDoc.createElement("GLOBALPARAM");
			xmlElem.SetAttribute("NAME", vstrParamName);
			XmlNode xmlRequestNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
			
			// create RESPONSE node
			xmlElem = xmlDoc.createElement("RESPONSE");
			XmlNode xmlResponseNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
			adoAssistEx.adoGetRecordSetAsXML(xmlRequestNode, xmlSchemaNode, xmlResponseNode);
			xmlResponseNode = xmlAssistEx.xmlGetNode(xmlResponseNode, "GLOBALPARAM");
			if (xmlResponseNode !=  null )
			{
				if (enumParamType == GLOBALPARAMTYPE.oegptString)
				{
					if (xmlAssistEx.xmlAttributeValueExists(xmlResponseNode, "STRING"))
					{
						vvarParamValue = xmlAssistEx.xmlGetAttributeText(xmlResponseNode, "STRING");
						result = true;
					}
				} else if (enumParamType == GLOBALPARAMTYPE.oegptAmount) { 
					if (xmlAssistEx.xmlAttributeValueExists(xmlResponseNode, "AMOUNT"))
					{
						vvarParamValue = xmlAssistEx.xmlGetAttributeAsDouble(xmlResponseNode, "AMOUNT").ToString();
						result = true;
					}
				} else if (enumParamType == GLOBALPARAMTYPE.oegptMaximumAmount) { 
					if (xmlAssistEx.xmlAttributeValueExists(xmlResponseNode, "MAXIMUMAMOUNT"))
					{
						vvarParamValue = xmlAssistEx.xmlGetAttributeAsDouble(xmlResponseNode, "MAXIMUMAMOUNT").ToString();
						result = true;
					}
				} else if (enumParamType == GLOBALPARAMTYPE.oegptPercentage) { 
					if (xmlAssistEx.xmlAttributeValueExists(xmlResponseNode, "PERCENTAGE"))
					{
						vvarParamValue = xmlAssistEx.xmlGetAttributeAsDouble(xmlResponseNode, "PERCENTAGE").ToString();
						result = true;
					}
					// DM    SYS3185 7/01/02 Added method to get a boolean value from a global parameter
				} else if (enumParamType == GLOBALPARAMTYPE.oegptBoolean) { 
					if (xmlAssistEx.xmlAttributeValueExists(xmlResponseNode, "BOOLEAN"))
					{
						// SYS3185 Changed this to call the xmlGetAttributeAsBoolean method
						vvarParamValue = xmlAssistEx.xmlGetAttributeAsBoolean(xmlResponseNode, "BOOLEAN").ToString();
						result = true;
					}
				}
			}
			return result;
		}
		//SR 25/01/2006 : BBGRb74 - New method 'GetAllGlobalBandedParamValuesAsXml'
		static public void  GetAllGlobalBandedParamValuesAsXml( string vstrParamName,  string strValueType, ref  XmlNode vxmlResponse)
		{
			
			const string cstrFunctionName = "GetAllGlobalBandedParamValuesAsXml";
			
			
			MSXML2.FreeThreadedDOMDocument40 xmlDoc = new MSXML2.FreeThreadedDOMDocument40();
			// create BOGUS root node
			XmlElement xmlElem = xmlDoc.createElement("BOGUS");
			XmlNode xmlRootNode = xmlDoc.appendChild((XmlNode) xmlElem);
			xmlElem = xmlDoc.createElement("GLOBALBANDEDPARAM");
			xmlElem.SetAttribute("ENTITYTYPE", "LOGICAL");
			xmlElem.SetAttribute("DATASRCE", "OM_GLOBALBANDEDPARAM");
			XmlNode xmlSchemaNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
			
			xmlElem = xmlDoc.createElement("NAME");
			xmlElem.SetAttribute("DATATYPE", "STRING");
			xmlElem.SetAttribute("LENGTH", "30");
			xmlSchemaNode.AppendChild((XmlNode) xmlElem);
			
			switch(strValueType.ToUpper())
			{
				case "STRING" : 
					xmlElem = xmlDoc.createElement("STRING"); 
					xmlElem.SetAttribute("DATATYPE", "STRING"); 
					xmlElem.SetAttribute("LENGTH", "30"); 
					xmlSchemaNode.AppendChild((XmlNode) xmlElem); 
					break;
				case "AMOUNT" : 
					xmlElem = xmlDoc.createElement("AMOUNT"); 
					xmlElem.SetAttribute("DATATYPE", "DOUBLE"); 
					xmlSchemaNode.AppendChild((XmlNode) xmlElem); 
					break;
				case "PERCENTAGE" : 
					xmlElem = xmlDoc.createElement("PERCENTAGE"); 
					xmlElem.SetAttribute("DATATYPE", "DOUBLE"); 
					xmlSchemaNode.AppendChild((XmlNode) xmlElem); 
					break;
				case "MAXIMUM" : 
					xmlElem = xmlDoc.createElement("MAXIMUM"); 
					xmlElem.SetAttribute("DATATYPE", "DOUBLE"); 
					xmlSchemaNode.AppendChild((XmlNode) xmlElem); 
					break;
				case "BOOLEAN" : 
					xmlElem = xmlDoc.createElement("BOOLEAN"); 
					xmlElem.SetAttribute("DATATYPE", "BOOLEAN"); 
					xmlSchemaNode.AppendChild((XmlNode) xmlElem); 
					break;
			}
			
			// create REQUEST details
			xmlElem = xmlDoc.createElement("GLOBALPARAM");
			xmlElem.SetAttribute("NAME", vstrParamName);
			XmlNode xmlRequestNode = xmlRootNode.AppendChild((XmlNode) xmlElem);
			if (vxmlResponse ==  null )
			{
				vxmlResponse = (XmlNode) xmlDoc.createElement("RESPONSE");
			}
			adoAssistEx.adoGetRecordSetAsXML(xmlRequestNode, xmlSchemaNode, vxmlResponse);
			
		}
	}
}