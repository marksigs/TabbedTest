using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Runtime.Serialization;
using System.Xml.Serialization.Configuration;


namespace MSC.IntegrationService.ConfigService
{
    [Serializable]
    public class MessageConfig : ConfigurationSection, ISerializable
    {
        #region constructor
        /// <summary>
        /// Predefines valida properties and prepares property colelction
        /// </summary>
        public MessageConfig()
        {

            sDescription = new ConfigurationProperty("description", typeof(string), null, ConfigurationPropertyOptions.None);
            sSource = new ConfigurationProperty("source", typeof(string), null, ConfigurationPropertyOptions.None);
            sDirection = new ConfigurationProperty("direction", typeof(string), null, ConfigurationPropertyOptions.None);
            sMessageType = new ConfigurationProperty("messageType", typeof(string), null, ConfigurationPropertyOptions.None);
            sAggregateResponse = new ConfigurationProperty("aggregateResponse", typeof(string), null, ConfigurationPropertyOptions.None);
            
           /* ConfigurationPropertyCollection messageConfigProperties = new ConfigurationPropertyCollection();
            messageConfigProperties.Add(sDescription);
            messageConfigProperties.Add(sSource);
            messageConfigProperties.Add(sDirection);
            messageConfigProperties.Add(sMessageType);
            messageConfigProperties.Add(sAggregateResponse);
            */
        }
        
        //Deserialization constructor.
        protected MessageConfig(SerializationInfo info, StreamingContext context) 
        {
            /*
            sDescription = (ConfigurationProperty)info.GetValue("sDescription", typeof(ConfigurationProperty));
            sSource = (ConfigurationProperty)info.GetValue("sSource", typeof(ConfigurationProperty));
            sDirection = (ConfigurationProperty)info.GetValue("sDirection", typeof(ConfigurationProperty));
            sMessageType = (ConfigurationProperty)info.GetValue("sMessageType", typeof(ConfigurationProperty));
            sAggregateResponse = (ConfigurationProperty)info.GetValue("sAggregateResponse", typeof(ConfigurationProperty));
            */
        }
        //Serialization function.
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context) 
        {
            /*
            info.AddValue("sDescription", sDescription);
            info.AddValue("sSource", sSource);
            info.AddValue("sDirection", sDirection);
            info.AddValue("sMessageType", sMessageType);
            info.AddValue("sAggregateResponse", sAggregateResponse);
              */
        }
         
        #endregion
        #region static fields
        private static ConfigurationProperty sDescription;
        private static ConfigurationProperty sSource;
        private static ConfigurationProperty sDirection;
        private static ConfigurationProperty sMessageType;
        private static ConfigurationProperty sAggregateResponse;
        #endregion
        
        #region Properties
        
        [ConfigurationProperty ("description")]
        public string Description
        {
            get 
            {
                return (string) base[sDescription]; 
            }
        }
        [ConfigurationProperty("source")]
        public string Source
        {
            get 
            {
                return (string)base[sSource]; 
            }
        }
        [ConfigurationProperty("direction")]
        public string Direction
        {
            get 
            {
                return (string)base[sDirection]; 
            }
        }
        [ConfigurationProperty("messageType")]
        public string MessageType
        {
            get 
            {
                return (string)base[sMessageType]; 
            }
        }
        [ConfigurationProperty("aggregateResponse")]
        public string AggregateResponse
        {
            get 
            {
                return (string)base[sAggregateResponse]; 
            }
        }
        #endregion
    }
    
    
}
